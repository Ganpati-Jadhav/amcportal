<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Vehicle extends CI_Model{
	
	function __construct() {
parent::__construct();
}
function vehicle_insert($data){
// Inserting in Table(students) of Database(college)
$this->db->insert('vehicle_details', $data);
}
	
// Fetch data from database
public function fetchVehicleDetails()  
      {  
         //data is retrive from this query  
         $query = $this->db->get('vehicle_details');  
         return $query;  
      } 

 public function getvehicleDetail($postData){
 
    $response = array();
 
    if($postData['chassis_number'] && $postData['chassis_number'] !=''){
 
      // Select record
      $this->db->select('*');
      $this->db->where('chassis_number', $postData['chassis_number']);
      $q = $this->db->get('vehicle_details');
      $response = $q->result_array();
 
    }
	if($postData['registration_number'] && $postData['registration_number'] !='')
	{
		// Select record
      $this->db->select('*');
      $this->db->where('registration_number', $postData['registration_number']);
      $q = $this->db->get('vehicle_details');
      $response = $q->result_array();
	}
 
    return $response;
  }
  
  public function particularvehicleDetails($vehicleId){
	  $response = array();
	  
	  $this->db->select('*');
      $this->db->where('id', $vehicleId);
      /* $q = $this->db->get('vehicle_details');
      $response = $q->result_array(); */
	  
	  
	   $query = $this->db->get('vehicle_details');  
	  // echo $query;
        return $query;  
	  
	   //return $response;
  }	  
	
	
}