<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Amcdetails extends CI_Model{
	
	function __construct() {
parent::__construct();
}

// Fetch data from database
public function fetchAMCDetails()  
      {  
         //data is retrive from this query  
         $query = $this->db->get('enquiry_details');  
         return $query;  
      } 
}