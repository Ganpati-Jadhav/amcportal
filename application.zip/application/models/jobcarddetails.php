<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Jobcarddetails extends CI_Model{
	
	function __construct() {
parent::__construct();
}

// Fetch data from database
public function fetchJobCardDetails()  
      {  
         //data is retrive from this query  
         $query = $this->db->get('job_card_details');  
         return $query;  
      } 

public function particularJobCardDetails($jobcardID){
	  $response = array();
	  
	  $this->db->select('*');
      $this->db->where('id', $jobcardID);
      /* $q = $this->db->get('vehicle_details');
      $response = $q->result_array(); */
	  
	  
	   $query = $this->db->get('job_card_details');  
	  // echo $query;
        return $query;  
	  
	   //return $response;
  }	  
}
?>