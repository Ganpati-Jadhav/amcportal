<?php
defined('BASEPATH')or die('external files not allowed');
class Inactiveamc extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('vehicle');
		
	}
	public function index(){
		$this->load->model('vehicle');
		 $data['allvehicles']=$this->vehicle->fetchVehicleDetails();  
         //return the data in view  
         
		 
		$this->load->view('users/header');
		//$this->load->view('vehiclelist');
		$this->load->view('inactiveamc', $data);  
		$this->load->view('users/footer');
	}
	
	
}
?>