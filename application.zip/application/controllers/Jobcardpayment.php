<?php
defined('BASEPATH')or die('Dont have external file permissions');
class Jobcardpayment extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('jobcarddetails');
	}
	public function index(){
		
		$this->load->model('jobcarddetails');
		$data['alljobcardpymt']=$this->jobcarddetails->fetchJobCardDetails();  
		$this->load->view('users/header');
		$this->load->view('job-card-payment',$data);
		$this->load->view('users/footer');
	}
	public function ajaxCalldt(){
		
		$this->load->model('vehicle');
		$allvehicles=$this->vehicle->fetchVehicleDetails();  
		
		foreach ($allvehicles->result_array() as $vehicledetails) { 
			$data1[] = $vehicledetails;
		}

//print_r($data1);
		$results = ["aaData" => $data1 ];


		echo json_encode($results);
		
		
		$this->load->view('users/header');
		$this->load->view('job-card-payment');
		$this->load->view('users/footer');
	}
	
	
}
?>