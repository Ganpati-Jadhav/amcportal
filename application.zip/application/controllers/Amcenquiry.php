<?php
defined('BASEPATH')or die('external files not allowed');
class Amcenquiry extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('Amcdetails');
		
	}
	public function index(){
		$this->load->model('Amcdetails');
		 $data['allAMCdetails']=$this->Amcdetails->fetchAMCDetails();  
         //return the data in view  
         
		 
		$this->load->view('users/header');
		//$this->load->view('vehiclelist');
		$this->load->view('amc-enquiry', $data);  
		$this->load->view('users/footer');
	}
	
	
}
?>