<?php
defined('BASEPATH')or die('Dont have external file permissions');
class Addvehicle extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('vehicle');
	}
	public function index(){
		$this->load->view('users/header');
		$this->load->view('addvehicle');
		$this->load->view('users/footer');
	}
	
	public function insertvehicle(){
		$this->load->library('form_validation');

		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');

		//Validating Name Field
		$this->form_validation->set_rules('chassis_number', 'Username', 'required|min_length[5]');

		//Validating Email Field
		$this->form_validation->set_rules('registration_number', 'Registration Number', 'required');

		//Validating Mobile no. Field
		$this->form_validation->set_rules('engine_number', 'Engine Number', 'required');

		//Validating Address Field
		$this->form_validation->set_rules('fuelType', 'Fuel type', 'required');

		if ($this->form_validation->run() == FALSE) {
		$this->load->view('users/header');
		$this->load->view('add-vehicle');
		$this->load->view('users/footer');
		} else {
		//Setting values for tabel columns
		$data = array(
		'chassis_number' => $this->input->post('chassis_number'),
		'registration_number' => $this->input->post('registration_number'),
		'engine_number' => $this->input->post('engine_number'),
		'fuel_type' => $this->input->post('fuelType'),
		'model' => $this->input->post('model_number'),
		'variant' => $this->input->post('variant'),
		);
		//Transfering data to Model
		$this->vehicle->vehicle_insert($data);
		$data['message'] = 'Data Inserted Successfully';
		//Loading View
		/* $this->load->view('users/header');
		$this->load->view('vehicle', $data);
		$this->load->view('users/footer'); */
		redirect('index.php/vehiclelist','refresh');
		}
}


public function getVehicleDetails(){
	
	$postData = $this->input->post();
	$data = $this->vehicle->getvehicleDetail($postData);

  echo json_encode($data);
	
}

	
}