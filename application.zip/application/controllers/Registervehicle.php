<?php
defined('BASEPATH')or die('Dont have external file permissions');
class Registervehicle extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('vehicle');
	}
	public function index(){
		$this->load->view('users/header');
		$this->load->view('registervehicle');
		$this->load->view('users/footer');
	}
	
	
}