<?php
defined('BASEPATH') or die("External Files not Allowed");
class Chassisdetailspage extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('vehicle');
	}
	
	public function chassisdetailsfunc(){
	$vehicleId = $this->input->post('vehicleid');
	
	$data['particularvehicleDetails']=$this->vehicle->particularvehicleDetails($vehicleId);
	
	//echo json_encode($data);
		
		$this->load->view('chassis-details', $data);  

	
	}
}