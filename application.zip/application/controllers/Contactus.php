<?php
defined('BASEPATH')or die('external files not allowed');
class Contactus extends CI_Controller{
	public function __construct(){
		parent::__construct();
	}
	public function index(){
		$this->load->view('users/header');
		$this->load->view('contact-us');
		$this->load->view('users/footer');
	}
}
?>