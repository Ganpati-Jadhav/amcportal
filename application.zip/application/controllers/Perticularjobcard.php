<?php
defined('BASEPATH') or die("External Files not Allowed");
class Perticularjobcard extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('jobcarddetails');
	}
	
	public function jobcarddetailsfunc(){
	$jobcardid = $this->input->post('jobcardid');
	
	$data['particularjobcard']=$this->jobcarddetails->particularJobCardDetails($jobcardid);
	
	//echo json_encode($data);
		
		$this->load->view('jobcard-details', $data);  

	
	}
}