<!DOCTYPE html>
<html lang="en">
<head>
 <title>Tata Motors Customer Care and Service networks</title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>

.nav-fill .nav-item {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    text-align: center;
    border: 1px solid;
    margin-left: 12px;
}


  /* Make the image fully responsive */
  .carousel-inner img {
      width: 100%;
      height: 100%;
  }
  .fullwidthOffsetoutr{
	  padding-left:0px !important;
	  padding-right:0px !important;
  }
  
  .story-area-2 {
    padding: 90px 0;
    position: relative;
    position: relative;
}
.story-area-2 .story-box {
    padding: 60px 90px;
    background: #fff;
    border-radius: 3px;
    position: relative;
    z-index: 2;
}
.story-area-2 .story-box h6 {
    margin-bottom: 15px;
}
.story-area-2 .primary-btn {
    border: 1px solid #eee;
}
.story-area-2 .primary-btn .lnr {
    color: #49e3ce;
    -webkit-transition: all 0.3s ease 0s;
    -moz-transition: all 0.3s ease 0s;
    -o-transition: all 0.3s ease 0s;
    transition: all 0.3s ease 0s;
}
.story-area-2 .primary-btn span {
    color: #3c408f;
    -webkit-transition: all 0.3s ease 0s;
    -moz-transition: all 0.3s ease 0s;
    -o-transition: all 0.3s ease 0s;
    transition: all 0.3s ease 0s;
}
.lnr-arrow-right:before {
    content: "\e87a";
}
.story-area-2:after {
    position: absolute;
    content: "";
    top: 0;
    left: 0;
    width: 50%;
    height: 100%;
    background: url(/img/story-bg.jpg) no-repeat center center/cover;
    z-index: 1;
}
.p1-gradient-bg, body:after, .primary-btn:after, .banner-area, .active-banner-slider .item:before, .single-feature .icon:after, .single-generic-feature .icon:after, .story-area, .story-area-2, .footer-widget-area, .single-widget .icon:after, .footer-social a:after {
    background-image: -moz-linear-gradient(135deg, #49e3ce 0%, #9920ed 100%);
    background-image: -webkit-linear-gradient(135deg, #49e3ce 0%, #9920ed 100%);
    background-image: -ms-linear-gradient(135deg, #49e3ce 0%, #9920ed 100%);
}
 
.carousel-caption {
    color: white;
    xright: 58%;
    text-align: center;
    max-width: 300px;
    right: 0;
    xtransform: translateY(-50%);
    xbottom: initial;
    background: #1889cb;
    padding: 10px;
    height: 100%;
	right:0%;
	left:none !important;
	top:0px;
}
.carousel-caption h1{
	padding-top:20px;
}
.lead {
    font-size: 15px;
    font-weight: 300;
    line-height: 20px;
}
.removeBorderBtmTab{
	border:none !important;
}
.img-hldr-wall {
    width: 100%;
    max-height: 230px!important;
    display: flex;
    flex-wrap: wrap;
    min-height: 230px!important;
}
.insprng-detl {
    padding: 2%;
}
.img-container-is {
    background-color: #f1f1f1;
}
.inspr-stry-img-hldr {
    display: flex;
    flex-wrap: wrap;
}
.inspr-stry-img-hldr a img {
    width: 100%;
    height: 100%;
}
.insprng-detl h5 {
    font-size: 16px;
    font-family: Lato,sans-serif;
    color: #000;
    font-weight: 400!important;
}
.explr-btn {
    width: 120px;
    padding-top: 8px;
    padding-bottom: 8px;
    background-color: transparent!important;
    border: 1px solid #000!important;
    color: #000!important;
    margin-top: 2%;
    font-weight: 400;
    font-size: 14px;
}
img.storyIMG.img-responsive.rounded {
    height: auto;
    width: 100%;
}
.help-hm {
    width: 100%;
    background-color: #f1f1f1;
    padding-top: 4%;
    padding-bottom: 4%;
    padding-left: 8%;
    padding-right: 8%;
}
section#inspiringstories {
    padding-left: 6%;
    padding-right: 6%;
}
.nav-tabs .nav-item.show .nav-link, .nav-tabs .nav-link.active {
     background-color: #007DC6;
    color: #fff;
    text-decoration: none;
}
.marginbottomComnOffset{
	margin-bottom:20px;
}
.btn-group-lg>.btn, .btn-lg {
    padding: .5rem 1rem;
    font-size: 16px;
    line-height: 1.5;
    border-radius: .3rem;
}

.outer-say-hello {
    background-color: #f1f1f1!important;
    padding: 4%;
}
.cum-say-h {
    padding-top: 5%;
    padding-bottom: 5%;
    padding-left: 2%;
    padding-right: 2%;
    background-color: #fff;
}

@media(max-width:320px){
    .carousel-caption{
	display:none;
}
}
@media only screen and (min-width : 320px) {
     .carousel-caption{
	display:none;
}
}
/* Extra Small Devices, Phones */ 
@media only screen and (min-width : 480px) {
     .carousel-caption{
	display:none;
}
}
/* Small Devices, Tablets */
@media only screen and (min-width : 768px) {
     .carousel-caption{
	display:block;
}
}
/* Medium Devices, Desktops */
@media only screen and (min-width : 992px) {
    .carousel-caption{
	display:block;
}
}
/* Large Devices, Wide Screens */
@media only screen and (min-width : 1200px) {
    .carousel-caption{
	display:block;
}
}
.bootCols{
    margin:0;
    box-sizing:border-box;
    padding:10px;
    border:2px solid auto;
}
</style>
</head>
<body>

<div class="container-fluid fullwidthOffsetoutr">
<section id="sliderCrContainer" class="marginbottomComnOffset">

<div id="demo" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="/img/slider_images/extendedwarranty.jpg" alt="Los Angeles" width="1100" height="500">
	   <div class="carousel-caption">
	   <div class="my-5">
		<h3>Extended Warranty</h3>
		<p class="lead">Secure your car for a longer period with our extended warranty program.</p>
		
		<a href="#" class="btn btn-lg btn-primary">Learn More</a>
		</div>
        </div><!-- end carousel-caption -->
    </div>
    <div class="carousel-item">
       <img src="/img/slider_images/online_booking.jpg" alt="Los Angeles" width="1100" height="500">
	    <div class="carousel-caption">
		 <div class="my-5">
			<h3>Customer Diary</h3>
			<p class="lead">Share your experiences with us and browse through what others have to say.</p>
			<a href="#" class="btn btn-lg btn-primary">Learn More</a>
		</div>
		</div>
		<!-- end carousel-caption -->
    </div>
    <div class="carousel-item">
<img src="/img/slider_images/Custom_dairy.jpg" alt="Los Angeles" width="1100" height="500">
 <div class="carousel-caption">
  <div class="my-5">
	<h3>Online Booking</h3>
	<p class="lead">Time for your vehicle’s scheduled service? Get an appointment online, right now!</p>
	<a href="#" class="btn btn-lg btn-primary">Learn More</a>
</div>
</div>
<!-- end carousel-caption -->
</div>
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

</section>
</div>
<div class="container-fluid">
<section id="tabs" class="marginbottomComnOffset">
	<div class="container">
		<h3 class="section-title">OUR OFFERINGS</h3>
		<div class="row">
			<div class="col-xs-12 tabWrapper container">
				<nav>
					<div class="nav nav-tabs nav-fill removeBorderBtmTab" id="nav-tab" role="tablist">
						<a style="margin-left:0px;" class="nav-item nav-link active btn btn-default btn-lg" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Responsive Service</a>
						<a class="nav-item nav-link btn btn-default btn-lg" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Reliable Service</a>
						<a class="nav-item nav-link btn btn-default btn-lg" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Best Value Service</a>
					</div>
				</nav>
				<div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
					<div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
					<div class="row d-flex justify-content-between">
					<div class="col-md-2 col-lg-2 col-xl-2 bootCols col-sm-6 text-align">
					<p><img src="/img/icons/speedo_service.png"></p>
					<a class="text-primary text-center">Speed-O-Service</a>
					</div>
					<div class="col-md-2 col-lg-2 col-xl-2 bootCols col-sm-6 text-align">
					<p><img src="/img/icons/online_at_click.png"></p>
					<a class="text-primary text-center">Online Service</a>
					</div>
					<div class="col-md-2 col-lg-2 col-xl-2 bootCols col-sm-6 text-align">
					<p><img src="/img/icons/doorstep_services.png"></p>
					<a class="text-primary text-center">Doorstep Service</a>
					</div>
					<div class="col-md-2 col-lg-2 col-xl-2 bootCols col-sm-6 text-align">
					<p><img src="/img/icons/24x7.png"></p>
					<a class="text-primary text-center">24 X 7 Road Side Assistance</a>
					</div>
					<div class="col-md-2 col-lg-2 col-xl-2 bootCols col-sm-6 text-align">
					<p><img src="/img/icons/quick_repair.png"></p>
					<a class="text-primary text-center">Quick Repair</a>
					</div>
				
					</div>
					
					</div>
					<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
					
				<div class="row d-flex justify-content-center">
					<div class="col-md-3 col-lg-3 col-xl-3 bootCols col-sm-6 text-center">
					<p><img src="/img/icons/quaity_services_0.png"></p>
					<a class="text-primary text-center">Quality Service</a>
					</div>
					<div class="col-md-3 col-lg-3 col-xl-3 bootCols col-sm-6 text-center">
					<p><img src="/img/icons/assestment_training_certification.png"></p>
					<a class="text-primary text-center">Assessment, Training And Certification</a>
					</div>
					<div class="col-md-3 col-lg-3 col-xl-3 bootCols col-sm-6 text-center">
					<p><img src="/img/icons/diagnostic_expert.png"></p>
					<a class="text-primary text-center">Diagnostic Expert</a>
					</div>
					
					
				</div>
					
					</div>
					<div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
					<div class="row d-flex justify-content-center">
						<div class="col-md-3 col-lg-3 col-xl-3 bootCols col-sm-6 text-center">
							<p><img src="/img/icons/value_care.png"></p>
							<a class="text-primary text-center">Value Care</a>
						</div>
						<div class="col-md-3 col-lg-3 col-xl-3 bootCols col-sm-6 text-center">
							<p><img src="/img/icons/rapid_repair.png"></p>
							<a class="text-primary text-center">Rapid Repair</a>
						</div>
						<div class="col-md-3 col-lg-3 col-xl-3 bootCols col-sm-6 text-center">
							<p><img src="/img/icons/extended_warrenty.png"></p>
							<a class="text-primary text-center">Extended Warranty</a>
						</div>
						<div class="col-md-3 col-lg-3 col-xl-3 bootCols col-sm-6 text-center">
							<p><img src="/img/icons/original_parts.png"></p>
							<a class="text-primary text-center">Original Parts</a>
						</div>
					</div>					
					</div>
				
				</div>
			
			</div>
		</div>
	</div>
</section>
</div>
<!--<section class="story-area-2">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-lg-3">
							<div class="story-title sm-show text-center">
								<h3 class="text-white">Our Untold Story</h3>
								<span class="text-uppercase text-white">Re-imagining the way</span>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="story-box">
								<h6 class="text-uppercase">Subhajit Roy <br/>
Head Customer Care(Service & Spare Parts)</h6><br/>
<p> Dear Customers,</p>
								<p>On behalf of the entire Tata Motor’s Customer Care Team in Passenger Vehicle Business Unit, I would like to extend a warm welcome to you...</p>
								<a href="https://service.tatamotors.com/content/head-customer-care" class="primary-btn d-inline-flex align-items-center"><span class="mr-10">Read More...</span><i class="fas fa-long-arrow-alt-right"></i></a>
							</div>
						</div>
						<div class="col-lg-3">
							<div class="story-title sm-hide text-right">
								<h3 class="text-white">Customer Diary</h3>
								<span class="text-uppercase text-white">Share your experiences with us</span>
								<p style="padding-top:10px;"><a href="https://service.tatamotors.com/customer-diaries#add-form" class="btn btn-primary btn-lg">Enter</a></p>
							</div>
						</div>
					</div>
				</div>
			</section>-->
			
<div class="container-fluid" style="padding-left:0px!important;padding-right:0px!important;">			
<section id="stroryCont" class="marginbottomComnOffset">
<div class="help-hm">
<div class="row">
<div class="col-md-8 col-sm-7 col-lg-8 col-xl-8 bootCols inner-help-hm text-center">
<h2>Need Help?</h2>
<p>Hey, how can we help you today? This is the quickest way to get answers. If you don't find specific information here then write to us.</p>
<a href="#">
<button class="brn btn-primary explr-btn">Help Center</button></a> </div>
<div class="col-md-4 col-sm-5 col-lg-4 col-xl-4 col-xs-4 help-img">
<img class="storyIMG img-responsive rounded" src="/img/clem-onojeghuo.jpg" style="display: block;">
</div>
</div>

</div>
</section>
</div>

<div class="container-fluid">			
<section id="inspiringstories" class="marginbottomComnOffset">
<div class="insprng-stry">
<h4>Inspiring Stories</h4>
<div class="row insprng-img1">
<div class="col-md-4 col-sm-4 col-lg-4 col-xl-4 bootCols col-sm-12">
<div class="img-container-is">
<div class="inspr-stry-img-hldr">
<a href="#">
<img class="lazy" alt="product" src="/img/inspiring-story2.jpg" style="display: block;">
</a>
</div>
<div class="insprng-detl">
<h3><a href="https://www.showflipper.com/blog/Works-of-Hara-Hiroshi-turned-into-sublime-artwork">Lorem lipsome Lorem...</a></h3>
<p>Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome... </p>
<div class="row insprng-detl-sub">
<div class="col-md-9 col-sm-7 col-lg-9 col-xl-9 col-xs-12">
</div>
<div class="col-md-3 col-sm-5 col-lg-3 col-xl-3 col-xs-12">
</div>
</div>
</div>
</div>
</div>

<div class="col-md-4 col-sm-12 col-lg-4 col-xl-4 bootCols">
<div class="img-container-is">
<div class="inspr-stry-img-hldr">
<a href="#">
<img class="lazy" alt="product" src="/img/instagramfeed/42003265_1007496242755342_5779449987443250994_n.jpg" style="display: block;">
</a>
</div>
<div class="insprng-detl">
<h3><a href="https://www.showflipper.com/blog/Works-of-Hara-Hiroshi-turned-into-sublime-artwork">Lorem lipsome Lorem...</a></h3>
<p>Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome... </p>
<div class="row insprng-detl-sub">
<div class="col-md-9 col-sm-7 col-lg-9 col-xl-9 col-xs-12">
</div>
<div class="col-md-3 col-sm-5 col-lg-3 col-xl-3 col-xs-12">
</div>
</div>
</div>
</div>
</div>

<div class="col-md-4 col-sm-12 col-lg-4 col-xl-4 bootCols">
<div class="img-container-is">
<div class="inspr-stry-img-hldr">
<a href="#">
<img class="lazy" alt="product" src="/img/inspiring-strory1.jpg" style="display: block;">
</a>
</div>
<div class="insprng-detl">
<h3><a href="#">Lorem lipsome Lorem...</a></h3>
<p>Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome Lorem lipsome... </p>
<div class="row insprng-detl-sub">
<div class="col-md-9 col-sm-7 col-lg-9 col-xl-9 col-xs-12">
</div>
<div class="col-md-3 col-sm-5 col-lg-3 col-xl-3 col-xs-12">
</div>
</div>
</div>
</div>
</div>
</div>
<div class="text-center">
<a href="#"><button class="brn btn-primary explr-btn">SHOW MORE</button></a>
</div>
</div>
</section>
</div>

<div class="container-fluid">
<section class="story-area-2">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-lg-3">
							<!--<div class="story-title sm-show text-center">
								<h3 class="text-white">Our Untold Story</h3>
								<span class="text-uppercase text-white">Re-imagining the way</span>
							</div>-->
						</div>
						<div class="col-lg-6 bootCols">
							<div class="story-box">
								<h6 class="text-uppercase">Subhajit Roy <br/>
Head Customer Care(Service & Spare Parts)</h6><br/>
<p> Dear Customers,</p>
								<p>On behalf of the entire Tata Motor’s Customer Care Team in Passenger Vehicle Business Unit, I would like to extend a warm welcome to you...</p>
								<a href="https://service.tatamotors.com/content/head-customer-care" class="primary-btn d-inline-flex align-items-center"><span class="mr-10">Read More...</span><i class="fas fa-long-arrow-alt-right"></i></a>
							</div>
						</div>
						<div class="col-lg-3" style="z-index:900;">
							<div class="story-title sm-hide text-right">
								<h3 class="text-white">Customer Diary</h3>
								<span class="text-uppercase text-white">Share your experiences with us</span>
								<p style="padding-top:10px;"><a href="https://service.tatamotors.com/customer-diaries#add-form" class="btn btn-primary btn-lg">Enter</a></p>
							</div>
						</div>
					</div>
				</div>
			</section>
</div>

<div class="container-fluid">

<div class="row cum-say-h">
<div class="col-md-4 col-sm-12 bootCols">
<h2 class="say-h1">SURAKSHA (AMC)</h2><br>
<p>
The AMC Service from Tata Motors Limited is known as Suraksha and it ensures that the customer can focus entirely on his core business while leaving work related to vehicle maintenance to the experts at Tata Motors.
</p>
<p>
AMC or Annual Maintenance Contract is a facility provided to a Commercial Vehicle buyer wherein TML provides maintenance and repair services to the customer at the specified National Highways through the Service outlets of its authorized dealers or Tata Authorized Service Stations (TASS). Under the AMC scheme the customer has the option to choose from various AMC packages. The coverage specified in each of the AMC packages may vary from a comprehensive AMC package to coverage of only scheduled services or only labour.</p>

</p>
</div>
<div class="col-md-8 bootCols">
<div class="row">
<div class="col-md-4 col-xs-4 col-sm-12 bootCols">
<div class="img1-cnt">
<img src="/img/instagramfeed/38469919_254155885216736_5447024773445976064_n.jpg" class="img-responsive img-rounded" width="100%">
</div>
<br>
<div class="img2-cnt">
<img src="/img/instagramfeed/feed2.jpg" class="img-responsive img-rounded" width="100%">
</div>
</div>
<div class="col-md-8 bootCols col-sm-12 bootCols" >
<div class="img3-cnt">
<img src="/img/instagramfeed/34479650_187199978648063_8062361377957740544_n.jpg" class="img-responsive img-rounded" width="100%">
</div>
</div>
</div>
</div>
</div>

</div>

<!-- ./Tabs -->

<script type="text/javascript">
$(document).ready(function(){
//
});
</script>
</body>
</html>
