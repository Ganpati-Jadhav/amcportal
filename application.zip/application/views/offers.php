<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<title>AMC-Products</title>
 <link href='https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' rel='stylesheet'>

<style type="text/css">
.accordion .card-header:after {
    font-family: 'FontAwesome';  
    content: "\f068";
    float: right; 
	color:#007bff!important;
}
.accordion .card-header.collapsed:after {
    /* symbol for "collapsed" panels */
    content: "\f067"; 
	color:#007bff!important;
}
#msform{
	background: white;
	border: 0 none;
	border-radius: 0px;
	box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
	padding: 20px 30px;
	box-sizing: border-box;
	width: 100%;
	position: relative;
	margin-top:30px;
	margin-bottom:30px;
}
.shape{	
	border-style: solid; border-width: 0 70px 40px 0; float:right; height: 0px; width: 0px;
	-ms-transform:rotate(360deg); /* IE 9 */
	-o-transform: rotate(360deg);  /* Opera 10.5 */
	-webkit-transform:rotate(360deg); /* Safari and Chrome */
	transform:rotate(360deg);
}
.offer{
	background:#fff; border:1px solid #ddd; box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2); margin: 15px 0; overflow:hidden;
}
.offer-radius{
	border-radius:7px;
}
.offer-danger {	border-color: #d9534f; }
.offer-danger .shape{
	border-color: transparent #d9534f transparent transparent;
	border-color: rgba(255,255,255,0) #d9534f rgba(255,255,255,0) rgba(255,255,255,0);
}
.offer-success {	border-color: #5cb85c; }
.offer-success .shape{
	border-color: transparent #5cb85c transparent transparent;
	border-color: rgba(255,255,255,0) #5cb85c rgba(255,255,255,0) rgba(255,255,255,0);
}
.offer-default {	border-color: #999999; }
.offer-default .shape{
	border-color: transparent #999999 transparent transparent;
	border-color: rgba(255,255,255,0) #999999 rgba(255,255,255,0) rgba(255,255,255,0);
}
.offer-primary {	border-color: #428bca; }
.offer-primary .shape{
	border-color: transparent #428bca transparent transparent;
	border-color: rgba(255,255,255,0) #428bca rgba(255,255,255,0) rgba(255,255,255,0);
}
.offer-info {	border-color: #5bc0de; }
.offer-info .shape{
	border-color: transparent #5bc0de transparent transparent;
	border-color: rgba(255,255,255,0) #5bc0de rgba(255,255,255,0) rgba(255,255,255,0);
}
.offer-warning {	border-color: #f0ad4e; }
.offer-warning .shape{
	border-color: transparent #f0ad4e transparent transparent;
	border-color: rgba(255,255,255,0) #f0ad4e rgba(255,255,255,0) rgba(255,255,255,0);
}

.shape-text{
	color:#fff; font-size:12px; font-weight:bold; position:relative; right:-40px; top:2px; white-space: nowrap;
	-ms-transform:rotate(30deg); /* IE 9 */
	-o-transform: rotate(360deg);  /* Opera 10.5 */
	-webkit-transform:rotate(30deg); /* Safari and Chrome */
	transform:rotate(30deg);
}	
.offer-content{
	padding:0 20px 10px;
}

</style>
</head>
<body>
<!-- Page Content -->
<div class="container-fluid">
<section id="msform">
    <div class="row">
	 <div id="carouselExampleIndicators" class="carousel slide my-4" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner" role="listbox">
              <div class="carousel-item active">
                <img class="d-block img-fluid" src="/img/slider_images/online_booking.jpg" alt="First slide">
              </div>
              <div class="carousel-item">
                <img class="d-block img-fluid" src="/img/slider_images/extendedwarranty.jpg" alt="Second slide">
              </div>
              <div class="carousel-item">
                <img class="d-block img-fluid" src="/img/slider_images/extendedwarranty.jpg" alt="Third slide">
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
	
	</div>
		<div class="row">
			<div class="col-lg-3 col-xl-3 col-sm-6 col-md-3">
				<div class="offer offer-default">
					<div class="shape">
						<div class="shape-text">
						<i class="glyphicon glyphicon-pencil text-primary"></i>							
						</div>
					</div>
					<div class="offer-content">
						<h3 class="lead">
							A default offer
						</h3>
						<p>
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.
							3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
							Food truck quinoa nesciunt laborum eiusmod. 
						</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-xl-3 col-sm-6 col-md-3">
				<div class="offer offer-success">
					<div class="shape">
						<div class="shape-text">
							top								
						</div>
					</div>
					<div class="offer-content">
						<h3 class="lead">
							A success offer
						</h3>						
						<p>
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.
							3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
							Food truck quinoa nesciunt laborum eiusmod. 
						</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-xl-3 col-sm-6 col-md-3">
				<div class="offer offer-radius offer-primary">
					<div class="shape">
						<div class="shape-text">
							top								
						</div>
					</div>
					<div class="offer-content">
						<h3 class="lead">
							A primary-radius
						</h3>						
						<p>
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.
							3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
							Food truck quinoa nesciunt laborum eiusmod. 
						</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-xl-3 col-sm-6 col-md-3">
				<div class="offer offer-info">
					<div class="shape">
						<div class="shape-text">
							top							
						</div>
					</div>
					<div class="offer-content">
						<h3 class="lead">
							An info offer
						</h3>						
						<p>
						Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.
							3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
							Food truck quinoa nesciunt laborum eiusmod. 
						</p>
					</div>
				</div>
			</div>
        </div>
        <div class="row">
			<div class="col-lg-3 col-xl-3 col-sm-6 col-md-3">
				<div class="offer offer-warning">
					<div class="shape">
						<div class="shape-text">
							top							
						</div>
					</div>
					<div class="offer-content">
						<h3 class="lead">
							A warning offer
						</h3>						
						<p>
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.
							3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
							Food truck quinoa nesciunt laborum eiusmod. 
						</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-xl-3 col-sm-6 col-md-3">
				<div class="offer offer-radius offer-primary">
					<div class="shape">
						<div class="shape-text">
							top							
						</div>
					</div>
					<div class="offer-content">
						<h3 class="lead">
							A danger-radius
						</h3>						
						<p>
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.
							3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
							Food truck quinoa nesciunt laborum eiusmod. 
						</p>
					</div>
				</div>
			</div>	
			
			<div class="col-lg-3 col-xl-3 col-sm-6 col-md-3">
				<div class="offer offer-radius offer-danger">
					<div class="shape">
						<div class="shape-text">
							top							
						</div>
					</div>
					<div class="offer-content">
						<h3 class="lead">
							A danger-radius
						</h3>						
						<p>
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.
							3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
							Food truck quinoa nesciunt laborum eiusmod. 
						</p>
					</div>
				</div>
			</div>
			
			<div class="col-lg-3 col-xl-3 col-sm-6 col-md-3">
				<div class="offer offer-radius offer-success">
					<div class="shape">
						<div class="shape-text">
							top							
						</div>
					</div>
					<div class="offer-content">
						<h3 class="lead">
							A danger-radius
						</h3>						
						<p>
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.
							3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
							Food truck quinoa nesciunt laborum eiusmod. 
						</p>
					</div>
				</div>
			</div>
		</div>

	
</section>
</div>
</body>
</html>
