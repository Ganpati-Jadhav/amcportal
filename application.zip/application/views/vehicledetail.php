<style>
.modal-dialog{
	min-width:900px;
	margin-top:3px;
}
fieldset.for-panel {
    background-color: #fcfcfc;
	border: 1px solid #999;
	border-radius: 4px;	
	padding:15px 10px;
	background-color: #d9edf7;
    border-color: #bce8f1;
	background-color: #f9fdfd;
	margin-bottom:12px;
}
fieldset.for-panel legend {
    background-color: #fafafa;
    border: 1px solid #ddd;
    border-radius: 5px;
    color: #4381ba;
    font-size: 14px;
    font-weight: bold;
    line-height: 10px;
    margin: inherit;
    padding: 7px;
    width: auto;
	background-color: #d9edf7;
	margin-bottom: 0;
}
</style>
<div class="container">

    <div class="row">
        <fieldset class="for-panel" style="width:100%">
     
		  <?php  
	//print_r($particularvehicleDetails->result());
	foreach ($particularvehicleDetails->result() as $vehicledetails)  
	{
		?>
		     <legend>AMC Details: <?php echo $vehicledetails->chassis_number; ?></legend>
          <div class="row">
            <div class="col-sm-6">
              <div class="form-inline" style="display: inherit;">   
<div class="row">			  
  <label class="col-md-6 control-label d-flex justify-content-start"><strong>Chassis Name:</strong></label>
  <p class="form-control-static col-md-6 d-flex justify-content-start"><?php echo $vehicledetails->chassis_number; ?></p> 
</div>	
<div class="row">			  
<label class="col-md-6 control-label d-flex justify-content-start"><strong>Application of Vehicle:</strong> </label>
<p class="col-md-6 form-control-static d-flex justify-content-start">Demo 988</p>
</div> 
<div class="row">              
<label class="col-md-6 control-label d-flex justify-content-start"><strong>Contact Description:</strong> </label>
<p class="col-md-6 form-control-static d-flex justify-content-start">Demo lorem lipsome Discription.</p>
</div>
<div class="row">
<label class="col-md-6 control-label d-flex justify-content-start"><strong>Contact Start Date:</strong> </label>
<p class="col-md-6 form-control-static d-flex justify-content-start">Demo lorem lipsome Discription.</p>   	
</div>
<div class="row">				
<label class="col-md-6 control-label d-flex justify-content-start"><strong>Contract Start Km/Hr: </strong></label>
<p class="col-md-6 form-control-static d-flex justify-content-start">Demo lorem lipsome Discription.</p>
</div> 
<div class="row">	
<label class="col-md-6 control-label d-flex justify-content-start"><strong>Last workshop visit day: </strong></label>
<p class="col-md-6 form-control-static d-flex justify-content-start">Demo lorem lipsome Discription.</p>
</div>
<div class="row">
<label class="col-md-6 control-label d-flex justify-content-start"><strong>Next Service KM:</strong></label>
<p class="col-md-6 form-control-static d-flex justify-content-start">Demo lorem lipsome Discription.</p>
</div>
<div class="row"> 
<label class="col-md-6 control-label d-flex justify-content-start"><strong>Number Of Workshop visits:</strong></label>
<p class="col-md-6 form-control-static d-flex justify-content-start">Demo lorem lipsome Discription.</p>
</div>
<div class="row"> 
<label class="col-md-6 control-label d-flex justify-content-start"><strong>PPL:</strong></label>
<p class="col-md-6 form-control-static d-flex justify-content-start">Demo lorem lipsome Discription.</p>
</div>					
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-inline" style="display: inherit;">
<div class="row">			  
<label class="col-md-6 control-label d-flex justify-content-start"><strong>Registration Number:</strong> </label>
<p class="col-md-6 form-control-static d-flex justify-content-start">reg no. 1234567890</p>
</div>
<div class="row">             
<label class="col-md-6 control-label d-flex justify-content-start"><strong>AMC Number:</strong></label>
<p class="col-md-6 form-control-static d-flex justify-content-start">Demo lorem lipsome Discription.</p>
</div> 
<div class="row">            
<label class="col-md-6 control-label d-flex justify-content-start"><strong>AMC Item Code:</strong></label>
<p class="col-md-6 form-control-static d-flex justify-content-start">CA-1234567890</p> 
</div> 
<div class="row">           
<label class="col-md-6 control-label d-flex justify-content-start"><strong>Contract End Date:</strong></label>
<p class="col-md-6 form-control-static d-flex justify-content-start">2019-02-02</p> 
</div>
<div class="row">            
<label class="col-md-6 control-label d-flex justify-content-start"><strong>Contract End Km/Hr:</strong></label>
<p class="col-md-6 form-control-static d-flex justify-content-start">92432</p>
</div>
<div class="row">
<label class="col-md-6 control-label d-flex justify-content-start"><strong>Km/Hr At Last Workshop Visit:</strong></label>
<p class="col-md-6 form-control-static d-flex justify-content-start">92432</p>
</div>
<div class="row">
<label class="col-md-6 control-label d-flex justify-content-start"><strong>Status Of The Contract:</strong></label>
<p class="col-md-6 form-control-static d-flex justify-content-start">Active</p>
</div>
<div class="row">
<label class="col-md-6 control-label d-flex justify-content-start"><strong>Next Service Tentative Date:</strong></label>
<p class="col-md-6 form-control-static d-flex justify-content-start">2019-02-19</p>
</div>
				  
              </div>
            </div>
          </div>
	<?php
		}
	?>	
        </fieldset>
    </div>
</div>