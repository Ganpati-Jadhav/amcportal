<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
	
	
	 <link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/b-1.5.4/b-colvis-1.5.4/b-html5-1.5.4/r-2.2.2/sc-1.5.0/sl-1.2.6/datatables.min.css"/>
 
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/b-1.5.4/b-colvis-1.5.4/b-html5-1.5.4/r-2.2.2/sc-1.5.0/sl-1.2.6/datatables.min.js"></script>

<script type="text/javascript" language="javascript" >
			$(document).ready(function() {
				var dataTable = $('#employee-grid').DataTable( {
					"processing": true,
					"serverSide": true,
					"ajax":{
						//url :"employee-grid-data.php", // json datasource
						 url: "/ajaxcalls/job-card-details.php",
						type: "post",  // method  , by default get
						error: function(){  // error handling
							$(".employee-grid-error").html("");
							$("#employee-grid").append('<tbody class="employee-grid-error"><tr><th colspan="7">No data found in the server</th></tr></tbody>');
							$("#employee-grid_processing").css("display","none");
							
						}
					}
				} );
			} );
		</script>
	 
	
	
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
 <link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
 
    <title>Online AMC - Add / Register / Vehicle</title>
	<style>
	div#nav-tabContent {
    border: 1px solid #d6d6d6;
	margin-top:20px;
	margin-bottom:20px;
}
.nav-tabs {
   border-bottom: none;
}
section#tabs {
    margin-top: 25px;
}
.paddingrlOffset{
	padding-left:20%;
	padding-right:20%;
}


.card {
    margin-top: 1em;
}
label{margin-left: 20px;}
#datepicker{margin: 0 20px 20px 20px;}
#datepicker > span:hover{cursor: pointer;}

/* IMG displaying */
.person-card {
    margin-top: 3em;
    padding-top: 2em;
}
.card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 23px;
    padding-bottom: 0px;
}
.person-card .card-title{
    text-align: center;
}

.margin_bottom_30pxOffset{
	margin-bottom:30px;
}
.card-title{
	border-bottom: 2px solid #5ea4f3;
}
.shopping-cart.dark {
    background-color: #f6f6f6;
    padding-top: 19px;
    padding-bottom: 30px;
}
.form-group{
	margin-bottom: 10px;
}
label.form-group {
  display: block;
  max-width: none;
}
label.col-form-label {
    max-width: 108px;
    margin: 0px;
    /* min-width: 80px; */
    text-align: left;
}
.datepicker{
	padding:0px;!important;
}

.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
}
.icon {
    padding: 6px;
    background: dodgerblue;
    color: white;
    text-align: center;
    padding-top: 10px;
}
.input-field{
	border-radius:0px !important;
}
.form-control{
	border-radius:0px !important;
}

/* The customcheck */
.customcheck {
    display: block;
    position: relative;
    padding-left: 35px;
    margin-bottom: 12px;
    cursor: pointer;
    font-size: 22px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* Hide the browser's default checkbox */
.customcheck input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
}

/* Create a custom checkbox */



.checkmark {
    left: 0;
   position: absolute;
     /* top: 0; */
    height: 25px;
    width: 25px;
    border: 1px solid #d6d6d6;
}

/* On mouse-over, add a grey background color */
.customcheck:hover input ~ .checkmark {
    background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.customcheck input:checked ~ .checkmark {
    background-color: #02cf32;
    border-radius: 5px;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
    content: "";
    position: absolute;
    display: none;
}

/* Show the checkmark when checked */
.customcheck input:checked ~ .checkmark:after {
    display: block;
}

/* Style the checkmark/indicator */
.customcheck .checkmark:after {
    left: 9px;
    top: 5px;
    width: 5px;
    height: 10px;
    border: solid white;
    border-width: 0 3px 3px 0;
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg);
}
.card.person-card{
	margin-bottom:10px;
}
.card {
	border:0px !important;
}
label{margin-left: 20px;}
#datepicker{margin: 0 20px 20px 20px;}
#datepicker > span:hover{cursor: pointer;}

/* IMG displaying */

.card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 23px;
    padding-bottom: 0px;
}
.person-card .card-title{
    text-align: center;
}
.table-responsive {
    display: table;
}
.person-card .person-img {
    width: 6em;
    position: absolute;
    top: -3em;
    left: 50%;
    margin-left: -5em;
    border-radius: 100%;
    overflow: hidden;
    background-color: white;
}

.margin_bottom_30pxOffset{
	margin-bottom:30px;
}
.card-title{
	border-bottom: 2px solid #5ea4f3;
	padding-bottom:10px;
}
.shopping-cart.dark {
    background-color: #f6f6f6;
	padding:10px;
}
.datepicker{
	padding:0px;!important;
}

.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width:100%;
}
.icon {
    padding: 6px;
    background: dodgerblue;
    color: white;
    text-align: center;
    padding-top: 9px;
    height: 38px;
}
.input-field{
	border-radius:0px !important;
}
.form-control{
	border-radius:0px !important;
}
main.page {
	background: white;
    border: 0 none;
    border-radius: 0px;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    box-sizing: border-box;
    width: 100%;
    position: relative;
    margin-top: 20px;
    margin-bottom: 20px;
    margin-left: 0px;
}
</style>


	</head>
	<body>
	<div class="container-fluid">
<section id="tabs" class="marginbottomComnOffset">
	<div class="container-fluid">
		<h3 class="section-title">Online AMC - Add / Register / Vehicle</h3>
		<div class="row">
			<div class="col-xs-12 tabWrapper container-fluid">
				<nav>
					<div class="nav nav-tabs nav-fill removeBorderBtmTab" id="nav-tab" role="tablist">
                        <a style="margin-left: 0px;" class="nav-item active nav-link btn btn-primary btn-lg" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Vehicle Registration</a>
						<a style="margin-left: 5px;" class="nav-item nav-link btn btn-primary btn-lg" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Add Vehicle</a>
						
					</div>
				</nav>
				<div class="tab-content py-3 px-3 px-sm-0 justify-content-center text-center" id="nav-tabContent">
				
					<div class="tab-pane fade show active" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
						
								<main class="page">
	 	<section class="shopping-cart dark">

    <!-- Sign up form -->
    <form id="enquiryForm" name="enquiryForm" method="POST" action="">
        <!-- Sign up card -->
        <div class="card person-card">
            <div class="card-body">
                <!-- Sex image -->
                <h5 id="who_message" class="d-flex justify-content-start">Job Card Payment</h5>
                <!-- First row (on medium screen) -->
                <div class="row">
				<div class="form-group col-md-2">
                        <input id="chassis_number" type="text" class="form-control" placeholder="Job Card Number">
                </div>
				
				<div class="form-group col-md-2">
					<input id="registration_number" type="text" class="form-control" placeholder="Registration Number">
				</div>
				<div class="form-group col-md-2">
					<input id="dealer_name" type="text" class="form-control" placeholder="Dealer Name">
				</div>
				
				
				
				<div class="form-group form-inline d-flex justify-content-between col-md-2">
			<div class="input-container col-md-12">
			<input class="input-field col-md-12 form-control datepicker" type="text" id="creation_date" name="creation_date"><i class="fa fa-calendar icon"></i>
			</div>
			</div>
			<div class="form-group form-inline d-flex justify-content-between col-md-2">
			<div class="input-container col-md-12">
			<input class="input-field col-md-12 form-control datepicker" type="text" id="closure_date" name="closure_date"><i class="fa fa-calendar icon"></i>
			</div>
			</div>
				<div class="form-group col-md-2 d-flex justify-content-center">
				 <button name="Go" class="btn btn-primary">Go</button>
				</div>
					
                </div>
            </div>
        </div>
          <div class="card person-card">
            <div class="card-body">
                <!-- Sex image -->
                <h5 id="who_message" class="d-flex justify-content-start">Job Card Payment</h5>
                <!-- First row (on medium screen) -->
                <div class="col-md-12 col-xl-12 col-lg-12 col-sm-12 ">
				  <table id="employee-grid" class="table table-responsive w-100 d-block d-md-table"  cellspacing="0" width="100%">
					<thead>
					  <tr>
						  <th>Job Card number</th>
						  <th>Status</th>
						  <th>Invoice</th>
						  <th>Chassis Number</th>
						  <th>Registration Number</th>
						  <th>Dealer Name</th>
						  <th>Location</th>
					  </tr>
					</thead>
				  </table>
        </div>
        </div>
        </div>
		
        </form>
		</div>

</section>
</main>
					
					</div>
				
<!-- Add Vehicle Tab Start Here -->				
<div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
				
					
	<div class="container-fluid" >
    <!-- Sign up form -->
    <form id="enquiryForm" name="enquiryForm" method="POST" action="">
     
        <div class="margin_bottom_30pxOffset">
        <div class="row">
            <div class="col-md-4" style="padding=0.5em;">
               
                    <div class="card-body">
                        <h2 class="card-title">Vehicle Information</h2>
                        <div class="form-group form-inline d-flex justify-content-between required">
                            <label for="chassis_number" class="col-form-label"> Chassis No:</label>
                            <input type="chassis_number" class="form-control" id="chassis_number" placeholder="#1234556">
                           
                        </div>
                        <div class="form-group form-inline d-flex justify-content-between">
                            <label for="product_name" class="col-form-label">Product Name:<i class="fas fa-asterisk" style="color:red;font-size: 9px;"></i></label>
                            <input type="text" class="form-control" id="product_name" name="product_name" >
                            
                        </div>
						
						 <div class="form-group form-inline d-flex justify-content-between">
                            <label for="vehicle_make" class="col-form-label">Make:</label>
                           <input name="vehicle_make" class="form-control" id="vehicle_make" >
						   
                        </div>
						
					    <div class="form-group form-inline d-flex justify-content-between">
                            <label for="vehicle_model" class="col-form-label">Model:</label>
                            <input type="text" class="form-control" id="vehicle_model" name="vehicle_model" >
                          
                        </div>
					   
						
						<div class="form-group form-inline d-flex justify-content-between">
						  <label for="vehicle_warranty_exp_date" class="col-form-label"> Warranty Expiry Date:</label>
						<div class="input-container">
						<input class="input-field form-control datepicker" type="text"  id="vehicle_warranty_exp_date" name="vehicle_warranty_exp_date"><i class="fa fa-calendar icon"></i>
						</div>
                        </div>
						
						
					    <div class="form-group form-inline d-flex justify-content-between">
                            <label for="vehicle_warranty_exp_hr" class="col-form-label">Warranty Expiry Hours:</label>
                            <input type="text" class="form-control" id="vehicle_warranty_exp_hr" name="vehicle_warranty_exp_hr" >
                            
                        </div>
					   
						
	
				<div class="form-group form-inline d-flex justify-content-between">
				<label style="margin-left:0px;">PDI Submitted:  </label>
				<div class="form-inline d-flex justify-content-between ">
				<label class="customcheck"><input  type="checkbox" name="pdi" id="pdi" />
				<span class="checkmark"></span></label>
				</div>
				</div>			
						
						<div class="form-group form-inline d-flex justify-content-between">
						  <label for="remarks" class="col-form-label"> PDI Done Date:</label>
						<div class="input-container">
						<input class="input-field form-control datepicker" type="text"  id="pdi_done_date" name="pdi_done_date"><i class="fa fa-calendar icon"></i>
						</div>
                        </div>
						
						
						
<div class="form-group form-inline d-flex justify-content-between">
<label style="margin-left:0px;">Fleet Flag:  </label>
<div class="form-inline d-flex justify-content-between ">
<label class="customcheck"><input  type="checkbox" name="fleet_flag" id="fleet_flag" />
<span class="checkmark"></span></label>
</div>
</div>	
						
						<div class="form-group form-inline d-flex justify-content-between">
						  <label for="reading_date" class="col-form-label"> Reading Date:</label>
						<div class="input-container">
						<input class="input-field form-control datepicker" type="text"  id="reading_date" name="reading_date"><i class="fa fa-calendar icon"></i>
						</div>
                        </div>
					
						
						 
				<div class="form-group form-inline d-flex justify-content-between">
                            <label for="pdi_kms" class="col-form-label">PDI KMS:</label>
                            <input type="text" class="form-control" id="pdi_kms" name="pdi_kms" >
                            
                        </div>
						
						
<div class="form-group form-inline d-flex justify-content-between">
<label style="margin-left:0px;">Total Loss Vehicle:  </label>
<div class="form-inline d-flex justify-content-between ">
<label class="customcheck"><input  type="checkbox" name="totallossvehicle" id="totallossvehicle" />
<span class="checkmark"></span></label>
</div>
</div>	
						
						
<div class="form-group form-inline d-flex justify-content-between">
<label style="margin-left:0px;">JD Power Survey Customer:</label>
<div class="form-inline d-flex justify-content-between ">
<label class="customcheck"><input  type="checkbox" name="jd_pw_customer" id="jd_pw_customer" />
<span class="checkmark"></span></label>
</div>
</div>		

<div class="form-group form-inline d-flex justify-content-between">
<label style="margin-left:0px;">IQS:</label>
<div class="form-inline d-flex justify-content-between ">
<label class="customcheck"><input  type="checkbox" name="iqs" id="iqs" />
<span class="checkmark"></span></label>
</div>
</div>	

<div class="form-group form-inline d-flex justify-content-between">
<label style="margin-left:0px;">SSI:</label>
<div class="form-inline d-flex justify-content-between ">
<label class="customcheck"><input  type="checkbox" name="ssi" id="ssi" />
<span class="checkmark"></span></label>
</div>
</div>						
						
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="selling_dealer" class="col-form-label">  Selling Dealer:</label>
                             <input type="text" class="form-control" id="selling_dealer" name="selling_dealer" >
                        </div>
						
						 
						<div class="form-group form-inline d-flex justify-content-between">
						  <label for="osaledate" class="col-form-label"> Original Sale Date:</label>
						<div class="input-container">
						<input class="input-field form-control datepicker" type="text"  id="osaledate" name="osaledate"><i class="fa fa-calendar icon"></i>
						</div>
                        </div>
						 
						 
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="selling_dealer" class="col-form-label">  Selling Dealer:</label>
                             <input type="text" class="form-control" id="selling_dealer" name="selling_dealer" >
                        </div>
						
                    </div>
              
            </div>
			
			
			
			 <div class="col-md-4">
			   <div class="card-body">
                         <div class="form-group form-inline d-flex justify-content-between">
                            <label for="vehicle_registration_number" class="col-form-label"> Vehicle Registration Number:</label>
                            <input type="text" class="form-control" id="vehicle_registration_number" name="vehicle_registration_number" >
                           
                        </div>
						
					    <div class="form-group form-inline d-flex justify-content-between">
                            <label for="dealer_invoice_number" class="col-form-label">  Dealer Invoice Number:</label>
                            <input type="text" class="form-control" id="dealer_invoice_number" name="dealer_invoice_number" >
                          
                        </div>
					    <div class="form-group form-inline d-flex justify-content-between">
                            <label for="commercial_invoice" class="col-form-label"> Commercial Invoice#:</label>
                            <input type="text" class="form-control" id="commercial_invoice" name="commercial_invoice" >
                           
                        </div>
						
						
						<div class="form-group form-inline d-flex justify-content-between">
						  <label for="tm_invoice_date" class="col-form-label"> TM Invoice Date:</label>
						<div class="input-container">
						<input class="input-field form-control datepicker" type="text"  id="tm_invoice_date" name="tm_invoice_date"><i class="fa fa-calendar icon"></i>
						</div>
                        </div>
						
						<div class="form-group form-inline d-flex justify-content-between">
						  <label for="resale_date" class="col-form-label"> Resale Date:</label>
						<div class="input-container">
						<input class="input-field form-control datepicker" type="text"  id="resale_date" name="resale_date"><i class="fa fa-calendar icon"></i>
						</div>
                        </div>
						
					
						
					    <div class="form-group form-inline d-flex justify-content-between">
                            <label for="resale_odometer_reading" class="col-form-label"> Resale Odometer Reading:</label>
                            <input type="text" class="form-control" id="resale_odometer_reading" name="resale_odometer_reading" >
                           
                        </div>
						 <div class="form-group form-inline d-flex justify-content-between">
                            <label for="vehicle_type" class="col-form-label"> Vehicle Type:</label>
                            <input type="text" class="form-control" id="vehicle_type" name="vehicle_type" >
                           
                        </div>
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="vehicle_category" class="col-form-label"> Vehicle Category:</label>
                            <input type="text" class="form-control" id="vehicle_category" name="vehicle_category" >
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="account" class="col-form-label">Account:</label>
                            <input type="text" class="form-control" id="account" name="account" >
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="account_site" class="col-form-label"> Account Site:</label>
                            <input type="text" class="form-control" id="account_site" name="account_site" >
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="status" class="col-form-label"> Status</label>
                            <input type="text" class="form-control" id="status" name="status" >
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_123_0" class="col-form-label">  Physical Status:</label>
                            <input type="text" class="form-control" id="s_2_1_123_0" name="s_2_1_123_0" >
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_27_0" class="col-form-label">  Parent Product Line:</label>
                            <input type="text" class="form-control" id="s_2_1_27_0" name="s_2_1_27_0" >
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_29_0" class="col-form-label">  Product Line:</label>
                            <input type="text" class="form-control" id="s_2_1_29_0" name="s_2_1_29_0" >
                        </div>
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_13_0" class="col-form-label">  Chassis Color:</label>
                            <input type="text" class="form-control" id="s_2_1_13_0" name="s_2_1_13_0" >
                        </div>
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_109_0" class="col-form-label">Cowl Cab No:</label>
                            <input type="text" class="form-control" id="s_2_1_109_0" name="s_2_1_109_0" >
                        </div>
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_150_0" class="col-form-label">Access Team:</label>
                            <input type="text" class="form-control" id="s_2_1_150_0" name="s_2_1_150_0" >
                        </div>
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_148_0" class="col-form-label"> Organization:</label>
                            <input type="text" class="form-control" id="s_2_1_148_0" name="s_2_1_148_0" >
                        </div>
						
						
                    </div>
              
            </div>
			
			
			<div class="col-md-4">
			
				<div class="row">
            
			 <div class="card-body">
                        <h2 class="card-title">Service Information</h2>
                       
                        <div class="form-group form-inline d-flex justify-content-between">
                            <label for="ppl" class="col-form-label">  Last Service Km:</label>
                           <input class="form-control" type="text" name="s_2_1_121_0" id="s_2_1_121_0">
                        </div> 
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="ppl" class="col-form-label">  Last Service Dealer:</label>
                           <input class="form-control" type="text" name="s_2_1_120_0" id="s_2_1_120_0">
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="ppl" class="col-form-label">  Last Service Division:</label>
                           <input class="form-control" type="text" name="s_2_1_71_0" id="s_2_1_71_0">
                        </div>
						
						
						<div class="form-group form-inline d-flex justify-content-between">
						  <label for="s_2_1_119_0" class="col-form-label">Last Service Date:</label>
						<div class="input-container">
						<input class="input-field form-control datepicker" type="text"  id="s_2_1_119_0" name="s_2_1_119_0"><i class="fa fa-calendar icon"></i>
						</div>
                        </div>

						<div class="form-group form-inline d-flex justify-content-between">
						  <label for="s_2_1_58_0" class="col-form-label"> Next Service Date:</label>
						<div class="input-container">
						<input class="input-field form-control datepicker" type="text"  id="s_2_1_58_0" name="s_2_1_58_0"><i class="fa fa-calendar icon"></i>
						</div>
                        </div>
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="ppl" class="col-form-label">Next Service Type:</label>
                           <input class="form-control" type="text" name="s_2_1_25_0" id="s_2_1_25_0">
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="ppl" class="col-form-label">Lost Customer Reason</label>
                           <input class="form-control" type="text" name="s_2_1_3_0" id="s_2_1_3_0">
                        </div>
					
                    </div>
               
                   
              
		</div>
		<div class="row">
		
		 <div class="col-md-6">
          <div class="margin_bottom_30pxOffset d-flex justify-content-center">
            <button type="button" class="btn btn-success btn-lg mr-2">Get Price</button>
            <button type="button" class="btn btn-primary btn-lg">Buy Now</button>
        </div>
                   
        </div>
		</div>
			
			</div>
                
           
        </div>
		
	
             </form>
		</div>
</div>				
					
					
					
</div>
<!-- Add Vehicle Tab End Here -->

		</div>
		</div>
	</div>
</section>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 
 <script type='text/javascript'>
  $(document).ready(function(){
 
   $('#getVehicleD').click(function(){
    var chassis_number = $("#chassis_number_getD").val();
    var registration_number = $("#registration_numbergetD").val();
	//alert(chassis_number);
    $.ajax({
     url:'<?=base_url()?>index.php/addvehicle/getVehicleDetails',
     method: 'post',
     data: {
		 chassis_number: chassis_number,
		 registration_number: registration_number
		 
	 },
     dataType: 'json',
     success: function(response){
      var len = response.length;

      if(len > 0){
       // Read values
       var ResMobileNumber = response[0].phone;
       //alert(ResMobileNumber);
	   var lastFourDigitsMob = ResMobileNumber.substr(ResMobileNumber.length - 4); // => "Tabs1"
 
       $('#ResMobileNumber').text(lastFourDigitsMob);
       
 
      }else{
       $('#ResMobileNumber').text('');
       
      }
 
     }
   });
  });
 });
 </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
        $(document).on('focus', '.datepicker',function(){
            $(this).datepicker({
                todayHighlight:true,
                format:'yyyy-mm-dd',
                autoclose:true
            })
        });
    </script>

	</body>
	</html>