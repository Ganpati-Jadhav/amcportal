<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title> AMC - Transactions</title>
<link rel="stylesheet" href="/css/shopping-cart.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
h5.invoiceTitle {
    padding-left: 30px;
}
</style>
</head>
<body>
<!-- Form Container start Here -->
	<main class="page">
	 	<section class="shopping-cart dark">
	 		<div class="container">
		        <div class="block-heading">
		          <h2>Transaction Details</h2>
		          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc quam urna, dignissim nec auctor in, mattis vitae leo.</p>
		        </div>
		        <div class="content">
	 				<div class="row">
	 					<div class="col-md-12 col-lg-12 col-lx-12 col-xs-12">
						
	 						<div class="items">
							
				 				<div class="product">
								<div class="row">
								<div class="col-md-12">
									<h5 class="invoiceTitle">Invioce Number: # 1364672 (current debit:: 356.61)</h5>
									</div>
									</div>
				 					<div class="row">
									
					 					<div class="col-md-3">
					 						<img class="img-fluid mx-auto d-block image" src="/img/Tata-Nexon-Right-Front-Three-Quarter-107996.jpg">
					 					</div>
					 					<div class="col-md-8">
					 						<div class="info">
						 						<div class="row">
							 						<div class="col-md-5 product-name">
							 							<div class="product-name">
								 							<a href="#">Lorem Ipsum dolor</a>
								 							<div class="product-info">
															<div>Chassis Number: <span class="value">32GB</span></div>
									 							<div>AMC Type: <span class="value">Gold</span></div>
									 							<div>Sale date: <span class="value">25/12/2018</span></div>
									 							
									 						</div>
									 					</div>
							 						</div>
							 						<div class="col-md-4 quantity">
							 							<div class="col-md-12 col-lg-12 col-xl-12 col-sm-12"><label for="quantity">AMC Status:</label></div>
							 							<div class="col-md-12 col-lg-12 col-xl-12 col-sm-12"><label for="quantityst"><strong>Active</strong></label></div>
							 						</div>
							 						<div class="col-md-12 col-lg-12 col-xl-12 col-sm-12 price">
							 							<span><i class="fa fa-inr" aria-hidden="true"></i> 120</span>
							 						</div>
							 					</div>
							 				</div>
					 					</div>
					 				</div>
				 				</div>
				 				<div class="product">
								<div class="row">
								<div class="col-md-12">
									<h5 class="invoiceTitle">Invioce Number: # 1364672 (current debit:: 356.61)</h5>
									</div>
								</div>
				 					<div class="row">
									
					 					<div class="col-md-3">
					 						<img class="img-fluid mx-auto d-block image" src="/img/Tata-Tiago-Exterior-120831.jpg">
					 					</div>
					 					<div class="col-md-8">
					 						<div class="info">
						 						<div class="row">
							 						<div class="col-md-5 product-name">
							 							<div class="product-name">
								 							<a href="#">Lorem Ipsum dolor</a>
								 							<div class="product-info">
															<div>Chassis Number: <span class="value">32123444</span></div>
									 							<div>AMC Type: <span class="value">Gold</span></div>
									 							<div>Sale date: <span class="value">25/12/2018</span></div>
									 							
									 						</div>
									 					</div>
							 						</div>
							 						<div class="col-md-4 quantity">
							 							<div class="col-md-12 col-lg-12 col-xl-12 col-sm-12"><label for="quantity">AMC Status:</label></div>
							 							<div class="col-md-12 col-lg-12 col-xl-12 col-sm-12"><label for="quantityst"><strong>Active</strong></label></div>
							 						</div>
							 						<div class="col-md-3 price">
							 							<span><i class="fa fa-inr"></i> 120</span>
							 						</div>
							 					</div>
							 				</div>
					 					</div>
					 				</div>
				 				</div>
				 				<div class="product">
								<div class="row">
								<div class="col-md-12">
									<h5 class="invoiceTitle">Invioce Number: # 1364672 (current debit:: 356.61)</h5>
									</div>
									</div>
				 					<div class="row">
									
					 					<div class="col-md-3">
					 						<img class="img-fluid mx-auto d-block image" src="/img/Tata-Nexon-Right-Front-Three-Quarter-107996.jpg">
					 					</div>
					 					<div class="col-md-8">
					 						<div class="info">
						 						<div class="row">
							 						<div class="col-md-5 product-name">
							 							<div class="product-name">
								 							<a href="#">Lorem Ipsum dolor</a>
								 							<div class="product-info">
															<div>Chassis Number: <span class="value">32GB</span></div>
									 							<div>AMC Type: <span class="value">Gold</span></div>
									 							<div>Sale date: <span class="value">25/12/2018</span></div>
									 							
									 						</div>
									 					</div>
							 						</div>
							 						<div class="col-md-4 quantity">
							 							<div class="col-md-12 col-lg-12 col-xl-12 col-sm-12"><label for="quantity">AMC Status:</label></div>
							 							<div class="col-md-12 col-lg-12 col-xl-12 col-sm-12"><label for="quantityst"><strong>Active</strong></label></div>
							 						</div>
							 						<div class="col-md-3 price">
							 							<span><i class="fa fa-inr"></i>120</span>
							 						</div>
							 					</div>
							 				</div>
					 					</div>
					 				</div>
				 				</div>
				 			</div>
			 			</div>
			 			<!--<div class="col-md-12 col-lg-4">
			 				<div class="summary">
			 					<h3>Summary</h3>
			 					<div class="summary-item"><span class="text">Subtotal</span><span class="price">$360</span></div>
			 					<div class="summary-item"><span class="text">Discount</span><span class="price">$0</span></div>
			 					<div class="summary-item"><span class="text">Shipping</span><span class="price">$0</span></div>
			 					<div class="summary-item"><span class="text">Total</span><span class="price">$360</span></div>
			 					<button type="button" class="btn btn-primary btn-lg btn-block">Checkout</button>
				 			</div>
			 			</div>-->
		 			</div> 
		 		</div>
	 		</div>
		</section>
	</main>
   
</body>
</html>