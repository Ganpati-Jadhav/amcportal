<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/b-1.5.4/b-colvis-1.5.4/b-html5-1.5.4/r-2.2.2/sc-1.5.0/sl-1.2.6/datatables.min.css"/>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/b-1.5.4/b-colvis-1.5.4/b-html5-1.5.4/r-2.2.2/sc-1.5.0/sl-1.2.6/datatables.min.js"></script>
<!--<script type="text/javascript" language="javascript" >
	$(document).ready(function() {
		var dataTable = $('#employee-grid').DataTable( {
			"processing": true,
			"serverSide": true,
			"ajax":{
				//url :"employee-grid-data.php", // json datasource
				 url: "/ajaxcalls/job-card-details.php",
				type: "post",  // method  , by default get
				error: function(){  // error handling
					$(".employee-grid-error").html("");
					$("#employee-grid").append('<tbody class="employee-grid-error"><tr><th colspan="7">No data found in the server</th></tr></tbody>');
					$("#employee-grid_processing").css("display","none");
					
				}
			}
		} );
	} );
</script> -->
<script>
$(document).ready(function(){
$('#example2').DataTable();
//$('#example4').DataTable();
$('#example3').DataTable();
});

$(document).ready( function () {
  var table = $('#example4').DataTable({
    //scrollY : "800px",
	//scrollCollapse: true,
	dom: 'Blfrtip',
	buttons: ['copy', 'csv', 'pdf'],
    colReorder: true,
    select: true
});
 
} );


</script>

<section id="tabsinner">
  <div class="row">
	<div class="col-md-12 ">
	<nav >
		<div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
			<a  class="nav-item nav-link active btn btn-primary" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Performed Jobs</a>
			<a style="margin-left:5px;" class="nav-item nav-link btn btn-primary" id="nav-jobcardParts-tab" data-toggle="tab" href="#nav-jobcardParts" role="tab" aria-controls="nav-jobcardParts" aria-selected="false">Jobcard Parts</a>
			<a style="margin-left:5px;" class="nav-item nav-link btn btn-primary" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Invoice</a>
		</div>
	</nav>

	  <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
		<div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
		<table id="example2" class="table  table-responsive-sm  table-responsive-md  table-responsive-lg table-responsive-xl w-100"  cellspacing="0" width="100%" style="border-left: 1px solid rgb(222, 226, 230);border-right: 1px solid rgb(222, 226, 230);">
		<thead>
		<tr>
          <th>Rate Type</th>
          <th>Billing Type</th>
          <th>Complaint Cd</th>
          <th>Job Code</th>
          <th>No. Of Jobs</th>
          <th>Extra Charge</th>
          <th>Billing Hrs</th>
          <th>Sts Labour Hrs</th>
		  <th>Concession</th>
		  <th>Job Value</th>
		  <th>Net Job Price</th>
		  <th>Rate List</th>
		  <th>Subcontract</th>
        </tr>
      </thead>
      <tbody>
	  <tr> 
         <?php  
		 $i=0;
         for ($j=0; $j<13; $j++)  
         {  ?>
		<td>Rate Type <?php echo $i;?></td>
		<td>Billing Type  <?php echo $i;?></td>
		<td>Complaint Cd  <?php echo $i;?></td>
		<td>Job Code  <?php echo $i;?></td>
		<td>No. Of Jobs  <?php echo $i;?></td>
		<td>Extra Charge  <?php echo $i;?></td>
		<td>Billing Hrs  <?php echo $i;?></td>
		<td>Sts Labour Hrs  <?php echo $i;?></td>
		<td>Concession <?php echo $i;?></td>
		<td>Job Value  <?php echo $i;?></td>
		<td>Net Job Price  <?php echo $i;?></td>
		<td>Rate List  <?php echo $i;?></td>
		<td>Subcontract  <?php echo $i;?></td>
           
            </tr> 
		 <?php
		$i++;
		 }?>			

	<!-- <thead>
        <tr>
          <th>Select</th>
          <th>Job Card Number</th>
          <th>Status</th>
          <th>Invoice</th>
          <th>Chassis Number</th>
          <th>Registration Number</th>
          <th>Dealer Name</th>
          <th>Location</th>
		  <th> Vehicle Sale Date</th>
        </tr>
      </thead>
      <tbody>
	  <tr> 
         <?php  
         foreach ($particularjobcard->result() as $jobcardDetails)  
         {  ?>
  <td>		 
		 <div class="radio">
                     <label><input data-id="<?php echo $jobcardDetails->id; ?>" type="radio" class="openDetailPage" name="optradio"></label>
                 </div>
				   </td>
            <td>
			<a href="javascript:void(0);" data-id="<?php echo $jobcardDetails->id; ?>" class="openPopup"><?php echo $jobcardDetails->job_card_number;?></a>
			</td>  
            <td><?php echo $jobcardDetails->status;?></td>  
            <td><?php echo $jobcardDetails->invoice;?></td>  
            <td><?php echo $jobcardDetails->chassis_number;?></td>  
            <td><?php echo $jobcardDetails->registration_number;?></td>  
            <td><?php echo $jobcardDetails->dealer_name;?></td>  
            <td><?php echo $jobcardDetails->location;?></td>  
            <td>
			<?php echo $jobcardDetails->sale_date;?> 
			</td>  
           
            </tr>   
<script>
 $('.openPopup').click(function(){
   var vehicleid = $(this).attr("data-id");
   // AJAX request
   $.ajax({
    url: '<?php echo base_url();?>index.php/allmodelspop/vehicledetailspopup',
    type: 'post',
    data: {vehicleid: vehicleid},
    success: function(response){ 
      // Add response in Modal body
      $('.modal-body').html(response);

      // Display Modal
      $('#myModal').modal('show'); 
    }
  });
 });
 $(".openDetailPage").click(function(){
	  var vehicleid1 = $(this).attr("data-id");
	  $.ajax({
    url: '<?php echo base_url();?>index.php/chassisdetailspage/chassisdetailsfunc',
    type: 'post',
    data: {vehicleid: vehicleid1},
    success: function(response){ 
      $("#AjaxChassisDetails").html('');
      $("#AjaxChassisDetails").html(response);
	  
    }
  });
 });
</script>
			
         <?php }  
         ?>  -->
    </tbody>
    </table>
</div>


<div class="tab-pane fade" id="nav-jobcardParts" role="tabpanel" aria-labelledby="nav-jobcardParts-tab">
  <table id="example3" class="table table-responsive-sm  table-responsive-md  table-responsive-lg table-responsive-xl w-100"  cellspacing="0" width="100%" style="border-left: 1px solid rgb(222, 226, 230);border-right: 1px solid rgb(222, 226, 230);">
      <thead>
   <tr>
          <th>Line #</th>
          <th>Qty</th>
          <th>Part No</th>
          <th>Type</th>
          <th>Status</th>
          <th>Rate</th>
          <th>Line Total</th>
          <th>Description</th>
		  <th>Descount/Item</th>
        </tr>
      </thead>
      <tbody>
	  <tr> 
         <?php  
         foreach ($particularjobcard->result() as $jobcardDetails)  
         {  ?>
  <td>		 
		 <div class="radio">
                     <label><input data-id="<?php echo $jobcardDetails->id; ?>" type="radio" class="openDetailPage" name="optradio"></label>
                 </div>
				   </td>
            <td>
			<a href="javascript:void(0);" data-id="<?php echo $jobcardDetails->id; ?>" class="openPopup"><?php echo $jobcardDetails->job_card_number;?></a>
			</td>  
            <td><?php echo $jobcardDetails->status;?></td>  
            <td><?php echo $jobcardDetails->invoice;?></td>  
            <td><?php echo $jobcardDetails->chassis_number;?></td>  
            <td><?php echo $jobcardDetails->registration_number;?></td>  
            <td><?php echo $jobcardDetails->dealer_name;?></td>  
            <td><?php echo $jobcardDetails->location;?></td>  
            <td>
			<?php echo $jobcardDetails->sale_date;?> 
			</td>  
           
            </tr>   
<script>
 $('.openPopup').click(function(){
   var vehicleid = $(this).attr("data-id");
   // AJAX request
   $.ajax({
    url: '<?php echo base_url();?>index.php/allmodelspop/vehicledetailspopup',
    type: 'post',
    data: {vehicleid: vehicleid},
    success: function(response){ 
      // Add response in Modal body
      $('.modal-body').html(response);

      // Display Modal
      $('#myModal').modal('show'); 
    }
  });
 });
 $(".openDetailPage").click(function(){
	  var vehicleid1 = $(this).attr("data-id");
	  $.ajax({
    url: '<?php echo base_url();?>index.php/chassisdetailspage/chassisdetailsfunc',
    type: 'post',
    data: {vehicleid: vehicleid1},
    success: function(response){ 
      $("#AjaxChassisDetails").html('');
      $("#AjaxChassisDetails").html(response);
	  
    }
  });
 });
</script>
			
         <?php }  
         ?>  
    </tbody>
    </table>
</div>
                    <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                    <table id="example4" class="table table-responsive-sm  table-responsive-md  table-responsive-lg table-responsive-xl w-100"  cellspacing="0" width="100%" style="border-left: 1px solid rgb(222, 226, 230);border-right: 1px solid rgb(222, 226, 230);">
      <thead>
          <tr>
          <th>Select</th>
          <th>Type</th>
          <th>Invoice No.</th>
          <th>Invoice Date</th>
          <th>Status</th>
          <th>Invoice Amount</th>
          <th>Settled Amount</th>
          <th>Invoice Balanced Amt</th>
		  <th>Dealer</th>
		  <th>SR No</th>
		  <th>Job Card Number</th>
		  <th>Pay</th>
        </tr>
      </thead>
      <tbody>
	  <tr> 
         <?php  
         foreach ($particularjobcard->result() as $jobcardDetails)  
         {  ?>
  <td>		 
<div class="radio">
 <label><input  type="radio" class="openDetailPage" name="optradio"></label>
</div>
</td>
<td>Type</td>
          <td>SR-ShreeS/SE</td>
          <td>01/21/2018</td>
          <td>New</td>
          <td>564.345</td>
          <td>655</td>
          <td>0</td>
		  <td>289609</td>
		  <td>SR-ShreeS/SE</td>
		  <td>JC-ShreeS/SE</td>
		  <td><a class="btn btn-primary" href="<?php echo base_url();?>index.php/orderconfirmation" >Make Payment</a></td>

            </tr>   
			
         <?php }  
         ?>  
    </tbody>
    </table>               
	
</div>
                    
                  </div>
                
                </div>
              </div>
        </section>
