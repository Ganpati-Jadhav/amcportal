<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
	
	
	 <link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/b-1.5.4/b-colvis-1.5.4/b-html5-1.5.4/r-2.2.2/sc-1.5.0/sl-1.2.6/datatables.min.css"/>
 
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/b-1.5.4/b-colvis-1.5.4/b-html5-1.5.4/r-2.2.2/sc-1.5.0/sl-1.2.6/datatables.min.js"></script>
<script>
$(document).ready(function(){
 $('#example').DataTable();
 $('#examplePayment').DataTable();
 
});

</script>
<!--
Ajax call DataTable
<script type="text/javascript" language="javascript" >
			$(document).ready(function() {
				var dataTable = $('#employee-grid').DataTable( {
					"processing": true,
					"serverSide": true,
					"ajax":{
						//url :"employee-grid-data.php", // json datasource
						 url: "/ajaxcalls/job-card-details.php",
						type: "post",  // method  , by default get
						error: function(){  // error handling
							$(".employee-grid-error").html("");
							$("#employee-grid").append('<tbody class="employee-grid-error"><tr><th colspan="7">No data found in the server</th></tr></tbody>');
							$("#employee-grid_processing").css("display","none");
							
						}
					}
				} );
			} );
		</script>
	 
	-->
	
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
 <link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
 
    <title>Online AMC - Add / Register / Vehicle</title>
	<style>
	
.nav-tabs {
   border-bottom: none;
}
section#tabs {
    margin-top: 25px;
}
.paddingrlOffset{
	padding-left:20%;
	padding-right:20%;
}


.card {
    margin-top: 1em;
}
label{margin-left: 20px;}
#datepicker{margin: 0 20px 20px 20px;}
#datepicker > span:hover{cursor: pointer;}

/* IMG displaying */
.person-card {
    margin-top: 3em;
    padding-top: 2em;
}
.card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 23px;
    padding-bottom: 0px;
}
.person-card .card-title{
    text-align: center;
}

.margin_bottom_30pxOffset{
	margin-bottom:30px;
}
.card-title{
	border-bottom: 2px solid #5ea4f3;
}
.shopping-cart.dark {
    background-color: #f6f6f6;
    padding-top: 19px;
    padding-bottom: 30px;
}
.form-group{
	margin-bottom: 10px;
}
label.form-group {
  display: block;
  max-width: none;
}
label.col-form-label {
    max-width: 108px;
    margin: 0px;
    /* min-width: 80px; */
    text-align: left;
}
.datepicker{
	padding:0px;!important;
}

.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
}
.icon {
    padding: 6px;
    background: dodgerblue;
    color: white;
    text-align: center;
    padding-top: 10px;
}
.input-field{
	border-radius:0px !important;
}
.form-control{
	border-radius:0px !important;
}

/* The customcheck */
.customcheck {
    display: block;
    position: relative;
    padding-left: 35px;
    margin-bottom: 12px;
    cursor: pointer;
    font-size: 22px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* Hide the browser's default checkbox */
.customcheck input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
}

/* Create a custom checkbox */



.checkmark {
    left: 0;
   position: absolute;
     /* top: 0; */
    height: 25px;
    width: 25px;
    border: 1px solid #d6d6d6;
}

/* On mouse-over, add a grey background color */
.customcheck:hover input ~ .checkmark {
    background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.customcheck input:checked ~ .checkmark {
    background-color: #02cf32;
    border-radius: 5px;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
    content: "";
    position: absolute;
    display: none;
}

/* Show the checkmark when checked */
.customcheck input:checked ~ .checkmark:after {
    display: block;
}

/* Style the checkmark/indicator */
.customcheck .checkmark:after {
    left: 9px;
    top: 5px;
    width: 5px;
    height: 10px;
    border: solid white;
    border-width: 0 3px 3px 0;
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg);
}
.card.person-card{
	margin-bottom:10px;
}
.card {
	border:0px !important;
}
label{margin-left: 20px;}
#datepicker{margin: 0 20px 20px 20px;}
#datepicker > span:hover{cursor: pointer;}

/* IMG displaying */

.card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 23px;
    padding-bottom: 0px;
}
.person-card .card-title{
    text-align: center;
}
.table-responsive {
    display: table;
}
.person-card .person-img {
    width: 6em;
    position: absolute;
    top: -3em;
    left: 50%;
    margin-left: -5em;
    border-radius: 100%;
    overflow: hidden;
    background-color: white;
}

.margin_bottom_30pxOffset{
	margin-bottom:30px;
}
.card-title{
	border-bottom: 2px solid #5ea4f3;
	padding-bottom:10px;
}
.shopping-cart.dark {
    background-color: #f6f6f6;
	padding:10px;
}
.datepicker{
	padding:0px;!important;
}

.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width:100%;
}
.icon {
    padding: 6px;
    background: dodgerblue;
    color: white;
    text-align: center;
    padding-top: 9px;
    height: 38px;
}
.input-field{
	border-radius:0px !important;
}
.form-control{
	border-radius:0px !important;
}
main.page {
	background: white;
    border: 0 none;
    border-radius: 0px;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    box-sizing: border-box;
    width: 100%;
    position: relative;
    margin-top: 20px;
    margin-bottom: 20px;
    margin-left: 0px;
}
.marginbottomComnOffset {
    background: white;
    border: 0 none;
    border-radius: 0px;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    box-sizing: border-box;
    width: 100%;
	padding-top:20px;
	margin-bottom:20px;
    position: relative;
}
</style>


	</head>
	<body>
	<div class="container-fluid">
<section id="tabs" class="marginbottomComnOffset">
	<div class="container-fluid">
		
		<div class="row">
			<div class="col-xs-12 tabWrapper container-fluid">
				<nav>
					<div class="nav nav-tabs nav-fill removeBorderBtmTab" id="nav-tab" role="tablist">
                        <a style="margin-left: 0px;" class="nav-item active nav-link btn btn-primary btn-lg" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Job Card Payment</a>
						<a style="margin-left: 5px;" class="nav-item nav-link btn btn-primary btn-lg" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Payment History</a>
						
					</div>
				</nav>
				<div class="tab-content py-3 px-3 px-sm-0 justify-content-center text-center" id="nav-tabContent">
				
					<div class="tab-pane fade show active" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
						
							
		
		
		<nav class="navbar navbar-light bg-light justify-content-center" style="padding-left: 15px !important;padding-right: 15px !important;">
  <form class="form-inline">
    <div class="row">
				<div class="form-group col-md-2">
                        <input id="chassis_number" type="text" class="form-control" placeholder="Job Card Number">
                </div>
				
				<div class="form-group col-md-2">
					<input id="registration_number" type="text" class="form-control" placeholder="Registration Number">
				</div>
				<div class="form-group col-md-2">
					<input id="dealer_name" type="text" class="form-control" placeholder="Dealer Name">
				</div>
				
				
				
				<div class="form-group form-inline d-flex justify-content-between col-md-2">
			<div class="input-container col-md-12">
			<input class="input-field col-md-12 form-control datepicker" type="text" id="creation_date" name="creation_date"><i class="fa fa-calendar icon"></i>
			</div>
			</div>
			<div class="form-group form-inline d-flex justify-content-between col-md-2">
			<div class="input-container col-md-12">
			<input class="input-field col-md-12 form-control datepicker" type="text" id="closure_date" name="closure_date"><i class="fa fa-calendar icon"></i>
			</div>
			</div>
				<div class="form-group col-md-2 d-flex justify-content-center">
				 <button name="Go" class="btn btn-primary">Go</button>
				</div>
					
                </div>
  </form>
</nav>
		
		
    
                <!-- Sex image -->
                
                <!-- First row (on medium screen) -->
	<div class="col-md-12 col-xl-12 col-lg-12 col-sm-12 container-fluid" style="margin-top:10px;">
	 <!-- 
	 Ajax Call Table
	 
	 <table id="employee-grid" class="table table-responsive w-100 d-block d-md-table"  cellspacing="0" width="100%" style="border-left: 1px solid #dee2e6;border-right: 1px solid #dee2e6;">
		<thead>
		  <tr>
			  <th>Job Card number</th>
			  <th>Status</th>
			  <th>Invoice</th>
			  <th>Chassis Number</th>
			  <th>Registration Number</th>
			  <th>Dealer Name</th>
			  <th>Location</th>
		  </tr>
		</thead>
	  </table>-->
	  
	   <table id="example" class="table table-responsive-sm  table-responsive-md  table-responsive-lg table-responsive-xl w-100"  cellspacing="0" width="100%" style="border-left: 1px solid rgb(222, 226, 230);border-right: 1px solid rgb(222, 226, 230);">
      <thead>
        <tr>
          <th>Select</th>
          <th>Job Card Number</th>
          <th>Status</th>
          <th>Invoice</th>
          <th>Chassis Number</th>
          <th>Registration Number</th>
          <th>Dealer Name</th>
          <th>Location</th>
		  <th> Vehicle Sale Date</th>
        </tr>
      </thead>
      <tbody>
	  <tr> 
         <?php  
         foreach ($alljobcardpymt->result() as $jobcardDetails)  
         {  ?>
  <td>		 
		 <div class="radio">
                     <label><input data-id="<?php echo $jobcardDetails->id; ?>" type="radio" class="openDetailPage" name="optradio"></label>
                 </div>
				   </td>
            <td>
			<a href="javascript:void(0);" data-id="<?php echo $jobcardDetails->id; ?>" class="openPopup"><?php echo $jobcardDetails->job_card_number;?></a>
			</td>  
            <td><?php echo $jobcardDetails->status;?></td>  
            <td><?php echo $jobcardDetails->invoice;?></td>  
            <td><?php echo $jobcardDetails->chassis_number;?></td>  
            <td><?php echo $jobcardDetails->registration_number;?></td>  
            <td><?php echo $jobcardDetails->dealer_name;?></td>  
            <td><?php echo $jobcardDetails->location;?></td>  
            <td>
			<?php echo $jobcardDetails->sale_date;?> 
			</td>  
           
            </tr>  
<script>
 $(".openDetailPage").click(function(){
	  var jobcardid = $(this).attr("data-id");
	 //alert(vehicleid1);
	  $.ajax({
    url: '<?php echo base_url();?>index.php/perticularjobcard/jobcarddetailsfunc',
    type: 'post',
    data: {jobcardid: jobcardid},
    success: function(response){ 
      $("#AjaxChassisDetails").html('');
      $("#AjaxChassisDetails").html(response);
	  
    }
  });
 });
</script>
			
         <?php }  
         ?>  
    </tbody>
    </table>
	  
    </div>
	
	<div id="AjaxChassisDetails" class="col-md-12 col-xl-12 col-lg-12 col-sm-12" style="margin-top:10px;">
	
	</div>
	
</div>
				
<!-- Add Vehicle Tab Start Here -->				
<div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
	<div class="container-fluid" >
    <!-- Sign up form -->
	
	                    <table id="examplePayment" class="table table-responsive-sm  table-responsive-md  table-responsive-lg table-responsive-xl w-100"  cellspacing="0" width="100%" style="border-left: 1px solid rgb(222, 226, 230);border-right: 1px solid rgb(222, 226, 230);">
      <thead>
          <tr>
          <th>Select</th>
          <th>Type</th>
          <th>Invoice No.</th>
          <th>Invoice Date</th>
          <th>Status</th>
          <th>Invoice Amount</th>
          <th>Settled Amount</th>
          <th>Invoice Balanced Amt</th>
		  <th>Dealer</th>
		  <th>SR No</th>
		  <th>Job Card Number</th>
		  <th>Pay</th>
        </tr>
      </thead>
      <tbody>
	  <tr> 
        
  <td>		 
<div class="radio">
 <label><input  type="radio" class="openDetailPage" name="optradio"></label>
</div>
</td>
<td>Gold AMC </td>
          <td>SR-ShreeS/SE</td>
          <td>01/21/2018</td>
          <td>New</td>
          <td>564.345</td>
          <td>655</td>
          <td>0</td>
		  <td>289609</td>
		  <td>SR-ShreeS/SE</td>
		  <td>JC-ShreeS/SE</td>
		  <td><a class="btn btn-primary" href="<?php echo base_url();?>index.php/orderconfirmation" >Make Payment</a></td>

            </tr>
<tr> 
  <td>		 
<div class="radio">
 <label><input  type="radio" class="openDetailPage" name="optradio"></label>
</div>
</td>
<td>Silver AMC </td>
          <td>SR-Dem0/SE</td>
          <td>01/21/2018</td>
          <td>New</td>
          <td>804.345</td>
          <td>655</td>
          <td>0</td>
		  <td>289609</td>
		  <td>SR-ShreeS/SE</td>
		  <td>JC-ShreeS/SE</td>
		  <td><a class="btn btn-primary" href="<?php echo base_url();?>index.php/orderconfirmation" >Make Payment</a></td>

            </tr>   
			
<tr> 
  <td>		 
<div class="radio">
 <label><input  type="radio" class="openDetailPage" name="optradio"></label>
</div>
</td>
<td>P2P AMC </td>
<td>SR-Dem0/SE</td>
<td>01/21/2018</td>
<td>New</td>
<td>804.345</td>
<td>655</td>
<td>0</td>
<td>289609</td>
<td>SR-ShreeS/SE</td>
<td>JC-ShreeS/SE</td>
<td><a class="btn btn-primary" href="<?php echo base_url();?>index.php/orderconfirmation" >Make Payment</a></td>
</tr>  
			
<tr> 
  <td>		 
<div class="radio">
 <label><input  type="radio" class="openDetailPage" name="optradio"></label>
</div>
</td>
<td>Protect plus AMC </td>
<td>SR-Dem0/SE</td>
<td>01/21/2018</td>
<td>New</td>
<td>804.345</td>
<td>655</td>
<td>0</td>
<td>289609</td>
<td>SR-ShreeS/SE</td>
<td>JC-ShreeS/SE</td>
<td><a class="btn btn-primary" href="<?php echo base_url();?>index.php/orderconfirmation" >Make Payment</a></td>
</tr>  
			
        
    </tbody>
    </table>               
	
    
	</div>
</div>				
					
					
					
</div>
<!-- Add Vehicle Tab End Here -->

		</div>
		</div>
	</div>
	</div>
</section>

</div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
        $(document).on('focus', '.datepicker',function(){
            $(this).datepicker({
                todayHighlight:true,
                format:'yyyy-mm-dd',
                autoclose:true
            })
        });
    </script>

	</body>
	</html>