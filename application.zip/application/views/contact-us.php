<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title> Contact Us </title>
<style>
.contact-form{
    background: #fff;
    margin-bottom: 5%;
	margin-top:5%;
    width: 100%;
}
.contact-form .form-control{
    border-radius:1rem;
}
.contact-image{
    text-align: center;
}
.contact-image img{
    border-radius: 6rem;
    width: 11%;
    margin-top: -3%;
    transform: rotate(29deg);
}
.contact-form form{
    padding: 8.3%;
}
.contact-form form .row{
    margin-bottom: -7%;
}
.contact-form h3{
    margin-bottom: 8%;
    margin-top: -10%;
    text-align: center;
    color: #0062cc;
}


.contactFormbgOffset{
	margin-top:30px;
}
main.page {
	background: white;
    border: 0 none;
    border-radius: 0px;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    box-sizing: border-box;
    width: 100%;
    position: relative;
    margin-top: 20px;
    margin-bottom: 20px;
    margin-left: 0px;
}
.outercontContfrm{
   background-image: url(/img/contact_inform_bg.jpg);
}
.maps {
    padding-top: 33px;
}
</style>
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">
</head>
<body>

<div class="container-fluid" >
<main class="page">
<section class="shopping-cart dark outercontContfrm">
    <div class="row">
      <div class="col-md-6 col-lg-6 colxl-6 maps" >
         <div style="overflow:hidden;width: 100%;position: relative;"><iframe width="100%" height="520" src="https://maps.google.com/maps?width=700&amp;height=500&amp;hl=en&amp;q=Tata%20Motros%20Pimpri-Chinchwad%2C%20Maharashtra+(Tata%20Motors)&amp;ie=UTF8&amp;t=&amp;z=10&amp;iwloc=B&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><div style="position: absolute;width: 80%;bottom: 20px;left: 0;right: 0;margin-left: auto;margin-right: auto;color: #000;"><small style="line-height: 1.8;font-size: 8px;background: #fff;">Powered by <a href="https://embedgooglemaps.com/">Embedgooglemaps EN</a> & <a href="http://fbaddlikebutton.com/">w://fbaddlikebutton.com/</a></small></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div><br />	  </div>
      <div class="col-md-6 col-lg-6 col-xl-6 col-sm-12 col-xs-12 ">
        
		<div class="container contact-form">
            <div class="contact-image">
                <img src="/img/rocket_contact.png" alt="rocket_contact"/>
            </div>
            <form method="post">
                <h3>Drop Us a Message</h3>
               <div class="row">
                    <div class="col-md-12 col-lg-12 col-xl-12 col-xs-12 col-sm-12">
                        <div class="form-group">
                            <input type="text" name="txtName" class="form-control" placeholder="Your Name *" value="" />
                        </div>
                        <div class="form-group">
                            <input type="text" name="txtEmail" class="form-control" placeholder="Your Email *" value="" />
                        </div>
                        <div class="form-group">
                            <input type="text" name="txtPhone" class="form-control" placeholder="Your Phone Number *" value="" />
                        </div>
                       
                    </div>
                    <div class="col-md-12 col-lg-12 col-xl-12 col-xs-12 col-sm-12">
                        <div class="form-group">
                            <textarea name="txtMsg" class="form-control" placeholder="Your Message *" style="width: 100%; height: 150px;"></textarea>
                        </div>
						 <div class="form-group">
                            <input type="submit" name="btnSubmit" class="btn btn-primary" value="Send Message" />
                        </div>
                    </div>
                </div>
            </form>
</div>
		
      </div>
	</section>
</main>
    </div>

</div>



</body>

