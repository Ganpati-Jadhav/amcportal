<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>AMC Enquiry</title>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
	 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/b-1.5.4/b-colvis-1.5.4/b-html5-1.5.4/r-2.2.2/sc-1.5.0/sl-1.2.6/datatables.min.css"/>
 
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/b-1.5.4/b-colvis-1.5.4/b-html5-1.5.4/r-2.2.2/sc-1.5.0/sl-1.2.6/datatables.min.js"></script>

<!--<script type="text/javascript" language="javascript" >
			$(document).ready(function() {
				var dataTable = $('#employee-grid').DataTable( {
					"processing": true,
					"serverSide": true,
					"ajax":{
						//url :"employee-grid-data.php", // json datasource
						 url: "/ajaxcalls/job-card-details.php",
						type: "post",  // method  , by default get
						error: function(){  // error handling
							$(".employee-grid-error").html("");
							$("#employee-grid").append('<tbody class="employee-grid-error"><tr><th colspan="7">No data found in the server</th></tr></tbody>');
							$("#employee-grid_processing").css("display","none");
							
						}
					}
				} );
			} );
		</script> -->
<script>
$(document).ready(function(){
 $('#example').DataTable();
});

</script>
<style type="text/css">
.card.person-card{
	margin-bottom:10px;
}
.card {
	border:0px !important;
}
label{margin-left: 20px;}
#datepicker{margin: 0 20px 20px 20px;}
#datepicker > span:hover{cursor: pointer;}

/* IMG displaying */

.card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 23px;
    padding-bottom: 0px;
}
.person-card .card-title{
    text-align: center;
}
.person-card .person-img {
    width: 6em;
    position: absolute;
    top: -3em;
    left: 50%;
    margin-left: -5em;
    border-radius: 100%;
    overflow: hidden;
    background-color: white;
}

.margin_bottom_30pxOffset{
	margin-bottom:30px;
}
.card-title{
	border-bottom: 2px solid #5ea4f3;
	padding-bottom:10px;
}
.shopping-cart.dark {
    /*background-color: #f6f6f6;*/
	padding:10px;
}
.datepicker{
	padding:0px;!important;
}

.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width:100%;
}
.icon {
    padding: 6px;
    background: dodgerblue;
    color: white;
    text-align: center;
    padding-top: 9px;
    height: 38px;
}
.input-field{
	border-radius:0px !important;
}
.form-control{
	border-radius:0px !important;
}
main.page {
	background: white;
    border: 0 none;
    border-radius: 0px;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    box-sizing: border-box;
    width: 100%;
    position: relative;
    margin-top: 20px;
    margin-bottom: 20px;
    margin-left: 0px;
}
.bg-offsetcust{
	 background: url('/img/backgrounds-blank-blue-953214.jpg') no-repeat ; 
 -webkit-background-size: cover;
 -moz-background-size: cover;
 -o-background-size: cover;
 background-size: cover;
}
.rowdivop{
	opacity: 0.9;
}
.bgoffsettocardbody{
	background: #fff;
    margin-top: 30px;
    padding-bottom: 8px;
}
.borderoffset{
	    border-bottom: 2px solid #007bff;
}
</style>

    <link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
 
	 
	 </head>
<body>
<div class="container-fluid" >
<main class="page">
	 	<section class="shopping-cart dark">

    <!-- Sign up form -->
    <form id="enquiryForm" name="enquiryForm" method="POST" action="">
        <!-- Sign up card -->
        <div class="card person-card">
            <div class="card-body">
                <!-- Sex image -->
                <h5 id="who_message" class="d-flex justify-content-start">AMC Enquiry</h5>
                <!-- First row (on medium screen) -->
                <div class="row borderoffset">
				<div class="form-group col-md-2">
                        <input id="chassis_number" type="text" class="form-control" placeholder="Chassis Number">
                </div>
				
				<div class="form-group col-md-2">
                            <select  class="form-control" placeholder="AMC Type" id="amc_price_line" name="amc_price_line" >
							<option value="0"> AMC Type </option>
							<option value="ZAM1"> Free </option>
							<option value="ZAM2"> Gold </option>
							<option value="ZAM3"> P2P  </option>
							<option value="ZAM4"> Silver  </option>
							<option value="ZAM5"> TTC/Bronze  </option>
							<option value="ZAM6"> Protect Plus  </option>
							<option value="ZAM7"> TTC/Bronze  </option>
                           </select>
                </div>
				<div class="form-group col-md-2">
				
					<select  class="form-control" placeholder="AMC Type" id="amc_price_line" name="amc_price_line" style="padding-left:1px;">
						<option value="0"> Contract Period (yrs)</option>
						<option value="A1">1</option>
						<option value="A2">2</option>
						<option value="A3">3</option>
						<option value="A4">4</option>
						<option value="A5">5</option>
					   </select>
				</div>
				
				<div class="form-group col-md-2">
				
					<select  class="form-control" placeholder="AMC Type" id="amc_price_line" name="amc_price_line" >
						<option value="0"> Contract Kms</option>
						<option value="A1">10,000</option>
						<option value="A2">20,000</option>
						<option value="A3">30,000</option>
						<option value="A4">40,000</option>
						<option value="A5">50,000</option>
						<option value="A5">60,000</option>
						<option value="A5">70,000</option>
						<option value="A5">80,000</option>
						<option value="A5">90,000</option>
						<option value="A5">100,000</option>
					   </select>
				</div>
				
				<div class="form-group col-md-2">
					<input id="amc_contract_KM" type="text" class="form-control" placeholder="Contract KM/Year">
				</div>
				<div class="form-group col-md-2 d-flex justify-content-center">
				 <button name="Go" class="btn btn-primary">Go</button>
				</div>
					
                </div>
            </div>
        </div>
		<!-- Table Div Start Here -->
			<div class="col-md-12 col-xl-12 col-lg-12 col-sm-12 margin_bottom_30pxOffset" style="margin-top:10px;">
	 <!-- <table id="employee-grid" class="table table-responsive w-100 d-block d-md-table"  cellspacing="0" width="100%" style="border-left: 1px solid #dee2e6;border-right: 1px solid #dee2e6;">
		<thead>
		  <tr>
			  <th>Job Card number</th>
			  <th>Status</th>
			  <th>Invoice</th>
			  <th>Chassis Number</th>
			  <th>Registration Number</th>
			  <th>Dealer Name</th>
			  <th>Location</th>
		  </tr>
		</thead>
	  </table>-->
	  
	      <table id="example" class="table table-responsive-sm  table-responsive-md  table-responsive-lg table-responsive-xl w-100"  cellspacing="0" width="100%" style="border-left: 1px solid rgb(222, 226, 230);border-right: 1px solid rgb(222, 226, 230);">
      <thead>
        <tr>
          <th>AMC Type</th>
          <th>AMC Material</th>
          <th>AMC Contract Period</th>
          <th>AMC KM</th>
          <th>AMC Price(inclusive of taxes)</th>
          <th>Discount</th>
		  <th> Actions</th>
        </tr>
      </thead>
      <tbody>
	  <tr> 
         <?php  
         foreach ($allAMCdetails->result() as $AMCdetails)  
         {  ?> 
            <td><a href="javascript:void(0);" data-id="<?php echo $AMCdetails->id; ?>" class="openPopup"><?php echo $AMCdetails->amc_type;?></a></td>  
            <td><?php echo $AMCdetails->amc_material;?></td>  
            <td><?php echo $AMCdetails->amc_contract_period;?></td>  
            <td><?php echo $AMCdetails->amc_km;?></td>  
            <td><?php echo $AMCdetails->amc_price;?></td>  
            <td><?php echo $AMCdetails->discount;?></td>   
            
			 <td>
			 <a href="<?php echo base_url();?>index.php/orderconfirmation" class="btn btn-primary btn-sm">Buy | Renew</a> </td>  
            </tr>  
<script>
 $('.openPopup').click(function(){
   var vehicleid = $(this).attr("data-id");
   // AJAX request
   $.ajax({
    url: '<?php echo base_url();?>index.php/allmodelspop/vehicledetailspopup',
    type: 'post',
    data: {vehicleid: vehicleid},
    success: function(response){ 
      // Add response in Modal body
      $('.modal-body').html(response);

      // Display Modal
      $('#myModal').modal('show'); 
    }
  });
 });
 $(".openDetailPage").click(function(){
	  var vehicleid1 = $(this).attr("data-id");
	  $.ajax({
    url: '<?php echo base_url();?>index.php/chassisdetailspage/chassisdetailsfunc',
    type: 'post',
    data: {vehicleid: vehicleid1},
    success: function(response){ 
      $("#AjaxChassisDetails").html('');
      $("#AjaxChassisDetails").html(response);
	  
    }
  });
 });
</script>
			
         <?php }  
         ?>  
    </tbody>
    </table>
</div>
		<!-- Table Div End -->
		
		
        <div id="AjaxChassisDetails" class="card bg-offsetcust">
 
        
		</div>
		
</form>

</section>
</main>
</div>
    
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
        $(document).on('focus', '.datepicker',function(){
            $(this).datepicker({
                todayHighlight:true,
                format:'yyyy-mm-dd',
                autoclose:true
            })
        });
    </script>
</body>
</html>
