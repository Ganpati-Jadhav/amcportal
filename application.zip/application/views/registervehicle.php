<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
 <link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
 
    <title>Online AMC - Add / Register / Vehicle</title>
	<style>
	div#nav-tabContent {
    border: 1px solid #d6d6d6;
	margin-top:20px;
	margin-bottom:20px;
}
.nav-tabs {
   border-bottom: none;
}
section#tabs {
    margin-top: 25px;
}
.paddingrlOffset{
	padding-left:20%;
	padding-right:20%;
}


.card {
    margin-top: 1em;
}
label{margin-left: 20px;}
#datepicker{margin: 0 20px 20px 20px;}
#datepicker > span:hover{cursor: pointer;}

/* IMG displaying */
.person-card {
    margin-top: 3em;
    padding-top: 2em;
}
.card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 23px;
    padding-bottom: 0px;
}
.person-card .card-title{
    text-align: center;
}

.margin_bottom_30pxOffset{
	margin-bottom:30px;
}
.card-title{
	border-bottom: 2px solid #5ea4f3;
}
.shopping-cart.dark {
    background-color: #f6f6f6;
    padding-top: 19px;
    padding-bottom: 30px;
}
.form-group{
	margin-bottom: 10px;
}
label.form-group {
  display: block;
  max-width: none;
}
label.col-form-label {
    max-width: 108px;
    margin: 0px;
    /* min-width: 80px; */
    text-align: left;
}
.datepicker{
	padding:0px;!important;
}

.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
}
.icon {
    padding: 6px;
    background: dodgerblue;
    color: white;
    text-align: center;
    padding-top: 10px;
}
.input-field{
	border-radius:0px !important;
}
.form-control{
	border-radius:0px !important;
}

/* The customcheck */
.customcheck {
    display: block;
    position: relative;
    padding-left: 35px;
    margin-bottom: 12px;
    cursor: pointer;
    font-size: 22px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* Hide the browser's default checkbox */
.customcheck input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
}

/* Create a custom checkbox */



.checkmark {
    left: 0;
   position: absolute;
     /* top: 0; */
    height: 25px;
    width: 25px;
    border: 1px solid #d6d6d6;
}

/* On mouse-over, add a grey background color */
.customcheck:hover input ~ .checkmark {
    background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.customcheck input:checked ~ .checkmark {
    background-color: #02cf32;
    border-radius: 5px;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
    content: "";
    position: absolute;
    display: none;
}

/* Show the checkmark when checked */
.customcheck input:checked ~ .checkmark:after {
    display: block;
}

/* Style the checkmark/indicator */
.customcheck .checkmark:after {
    left: 9px;
    top: 5px;
    width: 5px;
    height: 10px;
    border: solid white;
    border-width: 0 3px 3px 0;
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg);
}
.row.m1-h {
    padding-top: 30px;
    background: white;
    border: 0 none;
    border-radius: 0px;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    padding: 20px 30px;
    box-sizing: border-box;
    width: 100%;
    position: relative;
    margin-top: 20px;
    margin-bottom: 20px;
    margin-left: 0px;
}

div#register_form {
    padding-bottom: 22px;
    padding-top: 20px;
    border: 1px solid #d6d6d6;
}

</style>


	</head>
	<body>
	<div class="container-fluid">
	
	<div class="row m1-h" >
<div class="col-lg-7 col-md-7 col-sm-7 col-xs-12 ">
<div class="subscribe-s-1">
<p style="color: #22536B; font-size: 25px;font-weight: 600;">Vehicle Registration !</p>
</div>
<div class="subscribe-s-1" style="padding-top:40px;">
<div class="row  divde-s-2">
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
<h5 class="subscr-1">STEP 1: Lorem Lipsome</h5>
<p class="para-cnt-all">Lorem Lipsome Lorem Lipsome Lorem Lipsome,
Lorem Lipsome Lorem Lipsome Lorem Lipsome Lorem Lipsome
Lorem Lipsome Lorem Lipsome.Lorem Lipsome Lorem Lipsome Lorem Lipsome,
Lorem Lipsome Lorem Lipsome Lorem Lipsome Lorem Lipsome
Lorem Lipsome Lorem Lipsome.</p>
</div>
<div class="col-lg-1 col-md-1 col-sm-1 col-xs-12 "></div>
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 ">
<div class="imghold1">
<img src="/img/number1.svg" >
</div>
</div>
</div>
<div class="row divde-h-2 divde-s-2">
<div class="col-lg-1 col-md-1 col-sm-1 col-xs-12 ">
</div>
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 ">
<div class="imghold1">
<img src="/img/number2.svg" >
</div>
</div>
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
<h5 class="subscr-1">STEP 2: Lorem Lipsome</h5>
<p class="para-cnt-all">Lorem Lipsome Lorem Lipsome Lorem Lipsome,
Lorem Lipsome Lorem Lipsome Lorem Lipsome Lorem Lipsome
Lorem Lipsome Lorem Lipsome.Lorem Lipsome Lorem Lipsome Lorem Lipsome,
Lorem Lipsome Lorem Lipsome Lorem Lipsome Lorem Lipsome
Lorem Lipsome Lorem Lipsome.</p>
</div>
</div>
<div class="row divde-h-2 divde-s-2 divde-h-3">
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
<h5 class="subscr-1">STEP 3: Lorem Lipsome</h5>
<p class="para-cnt-all">Lorem Lipsome Lorem Lipsome Lorem Lipsome,
Lorem Lipsome Lorem Lipsome Lorem Lipsome Lorem Lipsome
Lorem Lipsome Lorem Lipsome.Lorem Lipsome Lorem Lipsome Lorem Lipsome,
Lorem Lipsome Lorem Lipsome Lorem Lipsome Lorem Lipsome
Lorem Lipsome Lorem Lipsome.</p>
</div>
<div class="col-lg-1 col-md-1 col-sm-1 col-xs-12 ">
</div>
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 ">
<div class="imghold1">
<img src="/img/number3.svg" >
</div>
</div>
</div>
</div>
</div>
<div class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col-xs-12 cmn-frm-resp-med" style="padding-bottom: 22px;" id="register_form">
<div class="row">
			<div class="col-xs-12 tabWrapper container-fluid">
			
						<div class="row justify-content-center align-items-center">
						<form method="POSt" class="col-md-9 col-lg-9 col-xl-9 col-sm-12 offset-md-1">
						<div class="row">
						  <div class="col-md-10 col-lg-10 col-xs-12 col-sm-12">
							<input type="text" class="form-control" id="registration_numbergetD" name="registration_numbergetD" placeholder="Enter Vehicle Registration Number">
						  </div>
						  <div class="col-md-2 col-lg-2 col-xs-12 col-sm-12">
						  </div>
						  </div>
						  
						    <div class="row justify-content-center align-items-center">
							<div class="col-md-10 col-lg-10 col-xs-12 col-sm-12">
							<div class="form-group">
							<label for="formGroupExampleInput2">OR</label>
												  
							</div>
							</div>
							<div class="col-md-2 col-lg-2 col-xs-12 col-sm-12">
						  </div>
						 
						  </div>

							
							<div class="row justify-content-center align-items-center">
							<div class="col-md-10 col-lg-10 col-xl-10 col-xs-12 col-sm-12">
							<div class="form-group">
							<input type="text" class="form-control" name="chassis_number_getD" id="chassis_number_getD" placeholder="Enter Chassis Number">
							</div>
							</div>
							<div class="col-md-2 col-lg-2 col-xl-2 col-xs-12 col-sm-12 d-flex justify-content-start">
							<div class="form-group">
							<button type="button"  id="getVehicleD" class="btn btn-primary">Go</button>
							
							</div>
							</div>
							</div>
						  </div>
						</form>  

						<!-- Vehicle verify Div -->
						<hr>
						<div class="row justify-content-center align-items-center">
						<form class="col-lg-12 col-md-12 col-xl-12 col-sm-12 col-xs-12">
						<div class="row">
						<div class="container text-center justify-content-center">
						<p class="text-success"><strong> Your Vehicle Is Verified </strong></p>
						</div>
						<div class="container">
						<p class="text-center justify-content-center"> Please Enter 10 Digit Mobile Number #(******<span id="ResMobileNumber"> </span>) To Proceed.</p>
						</div>
						<div class="col-md-8 col-lg-8 col-xl-8 col-xs-12 col-sm-12 offset-md-2">
						<div class="form-group">
							<input type="text" class="form-control" name="mobile_number" placeholder="Enter Mobile Number">
							
							</div>
						<div class="form-group text-center">
							<button type="button" class="btn btn-primary">Verify</button>
						</div>
						</div>
						
						</div>
						
						</form>
						</div>  
						
						<!-- Vehicle verify Div END-->
						
						
						
						<!-- Mobile verify Div -->
						<hr>
						<div class="row justify-content-center align-items-center">
						<form class="col-lg-12 col-md-12 col-xl-12 col-sm-12 col-xs-12">
						<div class="row">
						<div class="col-md-12 col-sm-12 col-lg-12 col-xl-12">
						<p class="text-center justify-content-center"> Your Mobile Number Is Verified. We have sent an OPT on your Mobile Number. </p>
						</div>
						<div class="col-md-8 col-lg-8 col-xl-8 offset-md-2 col-sm-12">
						
						
						<div class="form-group">
							<input type="text" class="form-control" name="mobile_number" placeholder="Enter OTP ">
							
							</div>
						<div class="form-group text-center">
							<button type="button" class="btn btn-primary my-2">Submit</button>
							<button type="button" class="btn btn-primary my-5">Re-Send OTP</button>
						</div>
						</div>
						<div class="col-md-2 col-lg-2 col-xl-2 col-xs-12 col-sm-12 ">
						</div>
						</div>
						
						</form>
						</div>  
						
						<!-- Mobile verify Div END-->
						
						</div>  
					
					</div>

</div>

</div>
		
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 
 <script type='text/javascript'>
  $(document).ready(function(){
 
   $('#getVehicleD').click(function(){
    var chassis_number = $("#chassis_number_getD").val();
    var registration_number = $("#registration_numbergetD").val();
	//alert(chassis_number);
    $.ajax({
     url:'<?=base_url()?>index.php/addvehicle/getVehicleDetails',
     method: 'post',
     data: {
		 chassis_number: chassis_number,
		 registration_number: registration_number
		 
	 },
     dataType: 'json',
     success: function(response){
      var len = response.length;

      if(len > 0){
       // Read values
       var ResMobileNumber = response[0].phone;
       //alert(ResMobileNumber);
	   var lastFourDigitsMob = ResMobileNumber.substr(ResMobileNumber.length - 4); // => "Tabs1"
 
       $('#ResMobileNumber').text(lastFourDigitsMob);
       
 
      }else{
       $('#ResMobileNumber').text('');
       
      }
 
     }
   });
  });
 });
 </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
        $(document).on('focus', '.datepicker',function(){
            $(this).datepicker({
                todayHighlight:true,
                format:'yyyy-mm-dd',
                autoclose:true
            })
        });
    </script>

	</body>
	</html>