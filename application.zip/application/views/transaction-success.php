<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
 <link rel="stylesheet" type="text/css" media="screen" href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="/css/shopping-cart.css">
<style type="text/css">

main.page {
  
    border: 0 none;
    border-radius: 0px;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    box-sizing: border-box;
    width: 100%;
    position: relative;
    margin-top: 20px;
    margin-bottom: 20px;
    margin-left: 0px;
}
#successMsg{
	margin-top:20px;
	margin-bottom:20px;
}

</style>
<div class="container-fluid">
<main class="page">
<div class="container">
<h4 class="text-center">CVBU Payment Interface </h4>
</div>


<section class="light" style="  border-top: 2px solid #5ea4f3;
    background-color: #f7fbff;">
	
	
	<section>
<div class="container">

      <div class="row marketing">
      
        <div class="col-lg-12">
        
          <h4><b>SR-Shree-S/SE</b></h4>
<hr />

<div>
<center class="text-success">  
<h4>Transaction Successful - Please note your transaction details!</h4>
<h5>Transaction number: #243735374</h5>
<hr />  
</div>
</center>
</div>
</div>
</div>
</section>
	
<div class="col-md-8 offset-md-2 pt-4 pb-4">
<dl class="d-flex justify-content-between">
<dt>Service Booking Number:<span></span></dt>
<dd>SR-Shree-S/SE</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>Job Card Number:<span></span></dt>
<dd>970000000</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>Pincode:<span></span></dt>
<dd>625014</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>Email:<span></span></dt>
<dd>user@gmail.com</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>Flat / House No. / Floor / Building:<span></span></dt>
<dd>#33/5</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>Colony / Street / Locality:<span></span></dt>
<dd>Roja 1st Street</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>Landmark:<span></span></dt>
<dd>Murugan Temple</dd>
</dl>
</div>
</section>
<section id="successMsg">
<div class="col-md-12 col-lg-12 col-xl-12 col-sm-12 text-center pt-4 pb-4">
<p class="text-success"> <strong>Thank you for the payment.</strong> </p>
</div>
</section> 
</main>

</div> 

       