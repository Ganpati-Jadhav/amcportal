<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<title>AMC-Products</title>
 <link href='https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' rel='stylesheet'>

<style type="text/css">
.accordion .card-header:after {
    font-family: 'FontAwesome';  
    content: "\f068";
    float: right; 
	color:#007bff!important;
}
.accordion .card-header.collapsed:after {
    /* symbol for "collapsed" panels */
    content: "\f067"; 
	color:#007bff!important;
}
#msform{
	background: white;
	border: 0 none;
	border-radius: 0px;
	box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
	padding: 20px 30px;
	box-sizing: border-box;
	width: 100%;
	position: relative;
	margin-top:30px;
	margin-bottom:30px;
}

</style>
</head>
<body>
<!-- Page Content -->
<div class="container-fluid">
<section id="msform">
    <div id="accordion" class="accordion">
        <div class="card mb-0">
            <div class="card-header collapsed" data-toggle="collapse" href="#collapseOne">
                <a class="card-title">
                    Silver AMC
                </a>
            </div>
            <div id="collapseOne" class="card-body collapse show" data-parent="#accordion" >
                <div class="container">
				<div class="row">
					<div class="col-md-4 col-lg-4 col-xl-4 col-sm-12 ">
					<img class="card-img-top" src="/img/Tata-Nexon-Right-Front-Three-Quarter-107996.jpg" alt="">
					</div>
					<div class="col-md-8 col-lg-8 col-xl-8 col-sm-12 ">
					 <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                    aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                    craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
					</p> 
					<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                    aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                    craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
					</p>
					</div>
				</div>
				
				<div class="container">
					<h5 class="text-primary text-center justify-content-center">Service Parts</h5>
					<div class="row">
					<div class="col-md-4 col-lg-4 col-xl-4 col-sm-12 ">
					<img class="card-img-top" src="/img/Tata-Nexon-Right-Front-Three-Quarter-107996.jpg" alt="">
					<p class="text-center"><strong>Oil</strong></p>
					</div>
					<div class="col-md-4 col-lg-4 col-xl-4 col-sm-12 ">
					<img class="card-img-top" src="/img/Tata-Nexon-Right-Front-Three-Quarter-107996.jpg" alt="">
					<p class="text-center"><strong>Fuel Filter</strong></p>
					</div>
					<div class="col-md-4 col-lg-4 col-xl-4 col-sm-12 ">
					<img class="card-img-top" src="/img/Tata-Nexon-Right-Front-Three-Quarter-107996.jpg" alt="">
					<p class="text-center"><strong>Air Filter</strong></p>
					</div>
					</div>
					<div class="row">
					<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                    aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                    craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
					</p>
					</div>
				</div>
				
				</div>
            </div>
            <div class="card-header collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                <a class="card-title">
                 Gold AMC
                </a>
            </div>
            <div id="collapseTwo" class="card-body collapse" data-parent="#accordion" >
                <div class="container">
				<div class="row">
					<div class="col-md-4 col-lg-4 col-xl-4 col-sm-12 ">
					<img class="card-img-top" src="/img/Tata-Tiago-Exterior-120831.jpg" alt="">
					</div>
					<div class="col-md-8 col-lg-8 col-xl-8 col-sm-12 ">
					 <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                    aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                    craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
					</p> 
					<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                    aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                    craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
					</p>
					</div>
				</div>
				
				<div class="container">
					<h5 class="text-primary text-center justify-content-center">Service Parts</h5>
					<div class="row">
					<div class="col-md-4 col-lg-4 col-xl-4 col-sm-12 ">
					<img class="card-img-top" src="/img/Tata-Tiago-Exterior-120831.jpg" alt="">
					<p class="text-center"><strong>Oil</strong></p>
					</div>
					<div class="col-md-4 col-lg-4 col-xl-4 col-sm-12 ">
					<img class="card-img-top" src="/img/Tata-Tiago-Exterior-120831.jpg" alt="">
					<p class="text-center"><strong>Fuel Filter</strong></p>
					</div>
					<div class="col-md-4 col-lg-4 col-xl-4 col-sm-12 ">
					<img class="card-img-top" src="/img/Tata-Tiago-Exterior-120831.jpg" alt="">
					<p class="text-center"><strong>Air Filter</strong></p>
					</div>
					</div>
					<div class="row">
					<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                    aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                    craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
					</p>
					</div>
				</div>
				
				</div>
            </div>
            <div class="card-header collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
                <a class="card-title">
                  Promis To Protect(PTP)
                </a>
            </div>
            <div id="collapseThree" class="collapse" data-parent="#accordion" >
                <div class="container">
				<div class="row">
					<div class="col-md-4 col-lg-4 col-xl-4 col-sm-12 ">
					<img class="card-img-top" src="/img/Tata-Nexon-Right-Front-Three-Quarter-107996.jpg" alt="">
					</div>
					<div class="col-md-8 col-lg-8 col-xl-8 col-sm-12 ">
					 <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                    aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                    craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
					</p> 
					<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                    aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                    craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
					</p>
					</div>
				</div>
				
				<div class="container">
					<h5 class="text-primary text-center justify-content-center">Service Parts</h5>
					<div class="row">
					<div class="col-md-4 col-lg-4 col-xl-4 col-sm-12 ">
					<img class="card-img-top" src="/img/Tata-Nexon-Right-Front-Three-Quarter-107996.jpg" alt="">
					<p class="text-center"><strong>Oil</strong></p>
					</div>
					<div class="col-md-4 col-lg-4 col-xl-4 col-sm-12 ">
					<img class="card-img-top" src="/img/Tata-Nexon-Right-Front-Three-Quarter-107996.jpg" alt="">
					<p class="text-center"><strong>Fuel Filter</strong></p>
					</div>
					<div class="col-md-4 col-lg-4 col-xl-4 col-sm-12 ">
					<img class="card-img-top" src="/img/Tata-Nexon-Right-Front-Three-Quarter-107996.jpg" alt="">
					<p class="text-center"><strong>Air Filter</strong></p>
					</div>
					</div>
					<div class="row">
					<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                    aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                    craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
					</p>
					</div>
				</div>
				
				</div>
            </div>
        </div>
    </div>
	</section>
</div>
</body>
</html>
