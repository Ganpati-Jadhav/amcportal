			<section id="socialWallInsta">
			<div class="social-wall-hm">
<h4>From the social wall</h4>
<div class="wall-img-gallry">

<div class="row">
<div class="col-xl-2 col-lg-2 col-md-2 col-sm-3 col-xs-4 nopadng1">
<a href="https://www.instagram.com/p/BrE4_TthEim/"><div class="img-hldr-wall"><img  src="/img/instagramfeed/feed1.jpg" width="230">
</div></a>
</div>
<div class="col-xl-2 col-lg-2 col-md-2 col-sm-3 col-xs-4 nopadng1">
<a href="https://www.instagram.com/p/BrFRTe2hcSP/"><div class="img-hldr-wall"><img  src="/img/instagramfeed/feed2.jpg" width="230">
</div></a>
</div>
<div class="col-xl-2 col-lg-2 col-md-2 col-sm-3 col-xs-4 nopadng1">
<a href="https://www.instagram.com/p/BprS95zB0-4/"><div class="img-hldr-wall"><img  src="/img/instagramfeed/feed3.jpg" width="230">
</div></a>
</div>
<div class="col-xl-2 col-lg-2 col-md-2 col-sm-3 col-xs-4 nopadng1">
<a href="https://www.instagram.com/p/BprS95zB0-4/"><div class="img-hldr-wall"><img  src="/img/instagramfeed/feed3.jpg" width="230">
</div></a>
</div>
<div class="col-xl-2 col-lg-2 col-md-2 col-sm-3 col-xs-4 nopadng1">
<a href="https://www.instagram.com/p/BprS95zB0-4/"><div class="img-hldr-wall"><img  src="/img/instagramfeed/feed3.jpg" width="230">
</div></a>
</div>
<div class="col-xl-2 col-lg-2 col-md-2 col-sm-3 col-xs-4 nopadng1">
<a href="https://www.instagram.com/p/BprS95zB0-4/"><div class="img-hldr-wall"><img  src="/img/instagramfeed/feed3.jpg" width="230">
</div></a>
</div>
</div>


<div class="row">
<div class="col-xl-2 col-lg-2 col-md-2 col-sm-3 col-xs-4 nopadng1">
<a href="https://www.instagram.com/p/BprS95zB0-4/"><div class="img-hldr-wall"><img  src="/img/instagramfeed/feed3.jpg" width="230">
</div></a>
</div>
<div class="col-xl-2 col-lg-2 col-md-2 col-sm-3 col-xs-4 nopadng1">
<a href="https://www.instagram.com/p/BprS95zB0-4/"><div class="img-hldr-wall"><img  src="/img/instagramfeed/feed3.jpg" width="230">
</div></a>
</div>
<div class="col-xl-2 col-lg-2 col-md-2 col-sm-3 col-xs-4 nopadng1">
<a href="https://www.instagram.com/p/BprS95zB0-4/"><div class="img-hldr-wall"><img  src="/img/instagramfeed/feed3.jpg" width="230">
</div></a>
</div>
<div class="col-xl-2 col-lg-2 col-md-2 col-sm-3 col-xs-4 nopadng1">
<a href="https://www.instagram.com/p/BprS95zB0-4/"><div class="img-hldr-wall"><img  src="/img/instagramfeed/feed3.jpg" width="230">
</div></a>
</div>
<div class="col-xl-2 col-lg-2 col-md-2 col-sm-3 col-xs-4 nopadng1">
<a href="https://www.instagram.com/p/BprS95zB0-4/"><div class="img-hldr-wall"><img  src="/img/instagramfeed/feed3.jpg" width="230">
</div></a>
</div>
<div class="col-xl-2 col-lg-2 col-md-2 col-sm-3 col-xs-4 nopadng1">
<a href="https://www.instagram.com/p/BprS95zB0-4/"><div class="img-hldr-wall"><img  src="/img/instagramfeed/feed3.jpg" width="230">
</div></a>
</div>
</div>

</div>
</div>
			</section>