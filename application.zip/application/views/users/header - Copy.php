<?php
$protocol = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
$base_url = $protocol . "://" . $_SERVER['HTTP_HOST'];
$complete_url =   $base_url . $_SERVER["REQUEST_URI"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
-->
<link rel="stylesheet" href="/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="/js/popper.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.5.0/css/all.css' integrity='sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU' crossorigin='anonymous'>


<style>
#logo {
	vertical-align:middle;
}
.commonFontSizeOffset{
	    font-size: 15px;
}
.navbar-brand span {
	font-size:2rem;
	line-height:1.2;
	font-weight: 200;
	display:inline-block;
	vertical-align:middle;
	padding:0 0 0 15px;
}
.navbar-brand b {
	display:block;
	font-size:50%;
	line-height:1;
}
.navbar-nav {
	margin-left:auto;
}
.bg-dark {
    background-color: #FFF!important;
	color:#000!important;
	-webkit-box-shadow: 0 8px 6px -6px #999;
    -moz-box-shadow: 0 8px 6px -6px #999;
    box-shadow: 0 8px 6px -6px #999;
}
.main-nav {
    margin-top: 10px;
    position: relative;
    background: url(/img/secondNav.png) repeat-x scroll 0 -3px #017DC7;
	background-size:cover;
	color:#fff;
	padding-top: 0px !important;
    padding-bottom: 0px !important;
}
li.nav-item.myclscus a {
    font-size: 14px;
    color: #ffffff;
    padding: 10px 15px;
    display: block;
    font-weight: bold;
}

a.nav-link.text-uppercase1.colorAnchrOffset {
    color: #fff;
	  padding: 10px 15px;
}
li.nav-item.active {
    color: #003D8D;
    background: #ffffff;
}
li.nav-item.myclscus a:hover {
    text-decoration: none;
    background-color: #ffffff !important;
    color: #003D8D;
}
li.nav-item.myclscus {
    border-left: 1px solid #cecece;
    float: left;
}
a {
    text-decoration: none;
}
main-nav ul {
    margin: 0 auto;
    position: relative;
    width: 910px;
}
.main-nav ul li a.active {
    color: #003D8D;
    background: #ffffff;
}
body {
    font-family: Tahoma !important;
    font-size: 15px;
    line-height: 1.166em;
    color: #3a3b3c;
    -webkit-tap-highlight-color: rgba(0,0,0,0);
    -webkit-tap-highlight-color: transparent;
    overflow-x: hidden;
}
input.form-control {
	 font-family: Tahoma !important;
    font-size: 15px;
}


ul.dropdown-cart{
    min-width:250px;
}
ul.dropdown-cart li .item {
    display: block;
    padding: 11px 10px;
    margin: 3px 0;
}
ul.dropdown-cart li .item:hover{
    background-color:#f3f3f3;
}
ul.dropdown-cart li .item:after{
    visibility: hidden;
    display: block;
    font-size: 0;
    content: " ";
    clear: both;
    height: 0;
}
.dropdown-menu{
	left:none !important
}
ul.dropdown-cart li .item-left{
    float:left;
}
ul.dropdown-cart li .item-left img,
ul.dropdown-cart li .item-left span.item-info{
    float:left;
}
ul.dropdown-cart li .item-left span.item-info{
    margin-left:10px;   
}
ul.dropdown-cart li .item-left span.item-info span{
    display:block;
}
ul.dropdown-cart li .item-right{
    float:right;
}

.dropdown-cart li:nth-child(even) {
    background: #f3f3f3 !important;
}
.dropdown-cart li:nth-child(even) {
    background: #fff;
}
.explr-btn1 {
    width: 120px;
    padding-top: 8px;
    padding-bottom: 8px;
    /* background-color: transparent!important; */
    border: 1px solid #007bff!important;
    color: #fff!important;
    margin-top: 2%;
    font-weight: 400;
    font-size: 14px;
    background: #007bff;
}
.cart-subttl-nw {
    border-top: 1px solid #d1d1d1;
    width: 100% !important;
    position: relative;
    left: 15px !important;
    padding-top: 4px;
    padding-bottom: 10px;
    background-color: #f1f1f1;
}
.more-with-triangle.triangle-top-center::before {
    margin-right: -3px;
    right: 50%;
}
.more-with-triangle.triangle-top-center::before {
    right: 48% !important;
}
.more-with-triangle::before {
    position: absolute;
    display: inline-block;
    content: '';
    top: -7px;
    border-right: 7px solid transparent;
    border-left: 7px solid transparent;
    border-bottom: 7px solid #d6d6d6;
    right: 25px;
}
</style>
</head>



<nav class="navbar navbar-expand-md bg-dark navbar-dark"> 
  <!-- Brand --> 
	<a href="http://localhost" title="Home" rel="home" class="header__logo" id="logo">
    <img src="/img/tata_motors_logo.png" alt="Home"  class="header__logo-image">
	</a>
  <!-- Navbar links -->
	<!--<ul class="navbar-nav">
    <a href="http://localhost" title="Home" rel="home" class="header__logo" id="logo">
       <img src="/img/ta_logo.gif" alt="Home" width="110" class="header__logo-image">
    </a>
	</ul> -->
	 <div class="container">
	<ul class="nav navbar-nav navbar-right" style="padding: 20px;">
       <!-- <li class="dropdown">
          <a href="#" class="dropdown-toggle commonFontSizeOffset" data-toggle="dropdown" role="button" aria-expanded="false"> <i class="fas fa-shopping-cart"></i>
</span> 7 - Items<span class="caret"></span></a>
          <ul class="dropdown-menu dropdown-cart more-with-triangle triangle-top-center" role="menu" x-placement="top-start" style="padding-top:0px;padding-bottom:0px;position: absolute; will-change: transform; top: 41px; left: -53px; transform: translate3d(0px, -15px, 0px);">
              <li>
                  <span class="item">
                    <span class="item-left">
						<img src="/img/Tata-Tiago-Exterior-120831.jpg" alt="" width="85">
                        <span class="item-info">
                            <span>Item name</span>
                            <span>23$</span>
                        </span>
                    </span>
                    <span class="item-right">
                        <button class="btn btn-xs btn-danger pull-right"><i class="far fa-trash-alt white-text"></i></button>
                    </span>
                </span>
              </li>
              <li>
                  <span class="item">
                    <span class="item-left">
                        <img src="/img/Tata-Nexon-Right-Front-Three-Quarter-107996.jpg" alt="" width="85">
                        <span class="item-info">
                            <span>Item name</span>
                            <span>23$</span>
                        </span>
                    </span>
                    <span class="item-right">
                        <button class="btn btn-xs btn-danger pull-right"><i class="far fa-trash-alt white-text"></i></button>
                    </span>
                </span>
              </li>
              <li>
                  <span class="item">
                    <span class="item-left">
                        <img src="/img/Tata-Tiago-Exterior-120831.jpg" alt="" width="85">
                        <span class="item-info">
                            <span>Item name</span>
                            <span>23$</span>
                        </span>
                    </span>
                    <span class="item-right">
                        <button class="btn btn-xs btn-danger pull-right"><i class="far fa-trash-alt white-text"></i></button>
                    </span>
                </span>
              </li>
              <li>
                  <span class="item">
                    <span class="item-left">
                        <img src="/img/Tata-Nexon-Right-Front-Three-Quarter-107996.jpg" alt="" width="85">
                        <span class="item-info">
                            <span>Item name</span>
                            <span>23$</span>
                        </span>
                    </span>
                    <span class="item-right">
                        <button class="btn btn-xs btn-danger pull-right"><i class="far fa-trash-alt white-text"></i></button>
                    </span>
                </span>
              </li>
              <li class="divider"></li>
              <li class="justify-content-center text-center">
			  
			  <div class="row cart-subttl-nw vertical-align">
<div class="col-md-12 col-sm-12 col-xl-12 col-lg-12 col-xs-12">

<a href="<?php echo base_url();?>index.php/cart" id="" class="btn btn-primary chkout-btn1 ">View Cart</a>
<a href="<?php echo base_url();?>index.php/cart" id="" class="btn btn-primary chkout-btn1 ">Continue</a>

</div>
</div>
			  
			  </li>
          </ul>
		  

		  
        </li>
	 <li>
		<a  class="btn btn-default text-center" href="http://localhost">Sign In <span class="sr-only">(current)</span></a>
	  </li>
	  <li>
		<a  href="#story" >Log in</a>
	  </li>-->
		
      </ul>
	  <a  class="btn btn-outline-primary my-2 my-sm-0 commonFontSizeOffset" href="http://localhost/index.php/registration">Sign In</a>
	  <a class="commonFontSizeOffset" style="margin-left:25px;" href="http://localhost/index.php/login">Login in</a>
	  </div>
	
	
</nav>


<nav class="navbar navbar-light bg-light justify-content-center" style="padding-left: 15px !important;padding-right: 15px !important;padding: 0px;">
  <form class="form-inline">
    <select class="form-control mr-sm-2 my-2" name="AMCtype" placeholder="AMC Type" aria-label="AMC type">
		<option value="Vehicle Model Family">Vehicle Model Family</option>
		<option value="Chassis Number/Registration number">Chassis Number/Registration number</option>
	</select>
    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
    <button class="brn btn-primary explr-btn1 my-2 my-sm-0" type="submit">Search</button>
  </form>
</nav>


<nav class="navbar navbar-expand-lg navbar-light  text-light py-3 main-nav">
          <div class="container">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>

              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto order-0">
                  <li class="nav-item myclscus <?php if($complete_url =='http://localhost/'){echo 'active';}?>">
                    <a class="nav-link text-uppercase1 colorAnchrOffset" href="http://localhost">Home <span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item myclscus <?php if($complete_url =='http://localhost/index.php/activeamclist'){echo 'active';}?>">
                    <a class="nav-link text-uppercase1 colorAnchrOffset" href="<?php echo base_url(); ?>index.php/amcproducts">AMC Products</a>
                  </li>
				  <li class="nav-item myclscus <?php if($complete_url =='http://localhost/index.php/addvehicle'){echo 'active';}?>">
                    <a class="nav-link text-uppercase1 colorAnchrOffset" href="<?php echo base_url();?>index.php/addvehicle">Add Vehicle</a>
                  </li>
				  <li class="nav-item myclscus <?php if($complete_url =='http://localhost/index.php/registervehicle'){echo 'active';}?>">
                    <a class="nav-link text-uppercase1 colorAnchrOffset" href="<?php echo base_url();?>index.php/registervehicle">Register Vehicle</a>
                  </li>
                 <li class="nav-item myclscus <?php if($complete_url =='http://localhost/index.php/offers'){echo 'active';}?>">
                    <a class="nav-link text-uppercase1 colorAnchrOffset" href="<?php echo  base_url(); ?>index.php/offers">Our Offers</a>
                  </li>
                   <!--<li class="nav-item myclscus">
                    <a class="nav-link text-uppercase1 colorAnchrOffset" href="#team">Purchase AMC</a>
                  </li>-->
                  <li class="nav-item myclscus <?php if($complete_url =='http://localhost/index.php/inactiveamc'){echo 'active';}?>">
                    <a class="nav-link text-uppercase1 colorAnchrOffset" href="<?php echo  base_url(); ?>index.php/inactiveamc">Renew AMC</a>
                  </li>
                  <li class="nav-item myclscus <?php if($complete_url =='http://localhost/index.php/jobcardpayment'){echo 'active';}?>">
                    <a class="nav-link text-uppercase1 colorAnchrOffset" href="<?php echo  base_url(); ?>index.php/jobcardpayment">Job Card Payment</a>
                  </li>
				  <li class="nav-item myclscus">
                    <a class="nav-link text-uppercase1 colorAnchrOffset" href="#people-say">Dealers Network</a>
                  </li>
                  <li class="nav-item myclscus <?php if($complete_url =='http://localhost/index.php/contactus'){echo 'active';}?>">
                    <a class="nav-link  text-uppercase1 colorAnchrOffset" href="<?php echo  base_url(); ?>index.php/contactus">Contact Us</a>
                  </li>
                </ul>
              </div>
          </div>
        </nav>