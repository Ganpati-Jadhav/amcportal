<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
 <link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
 
<style>
/*custom font*/
@import url(https://fonts.googleapis.com/css?family=Montserrat);

/*basic reset*/
* {
    margin: 0;
    padding: 0;
}



body {
    font-family: montserrat, arial, verdana;
    background: transparent;
}

/*form styles*/
#msform {
    text-align: center;
    position: relative;
    margin-top: 15px;
}

#msform fieldset {
    background: white;
    border: 0 none;
    border-radius: 0px;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    padding: 20px 30px;
    box-sizing: border-box;
    width: 100%;
    /*stacking fieldsets above each other*/
    position: relative;
}

/*Hide all except first fieldset*/
#msform fieldset:not(:first-of-type) {
    display: none;
}

/*inputs*/
#msform input, #msform textarea {
    padding: 15px;
    border: 1px solid #ccc;
    border-radius: 0px;
    margin-bottom: 0px;
    width: 100%;
    box-sizing: border-box;
    font-family: montserrat;
    color: #2C3E50;
    font-size: 13px;
}

#msform input:focus, #msform textarea:focus {
    -moz-box-shadow: none !important;
    -webkit-box-shadow: none !important;
    box-shadow: none !important;
    border: 1px solid #28a745;
    outline-width: 0;
    transition: All 0.5s ease-in;
    -webkit-transition: All 0.5s ease-in;
    -moz-transition: All 0.5s ease-in;
    -o-transition: All 0.5s ease-in;
}

/*buttons*/
#msform .action-button {
    width: 100px;
    background: #007bff;
    font-weight: bold;
    color: white;
    border: 0 none;
    border-radius: 25px;
    cursor: pointer;
    padding: 10px 5px;
    margin: 10px 5px;
}

#msform .action-button:hover, #msform .action-button:focus {
    box-shadow: 0 0 0 2px white, 0 0 0 3px #28a745;
}

#msform .action-button-previous {
    width: 100px;
    background: #017DC7;
    font-weight: bold;
    color: white;
    border: 0 none;
    border-radius: 25px;
    cursor: pointer;
    padding: 10px 5px;
    margin: 10px 5px;
}

#msform .action-button-previous:hover, #msform .action-button-previous:focus {
    box-shadow: 0 0 0 2px white, 0 0 0 3px #C5C5F1;
}

/*headings*/
.fs-title {
    font-size: 18px;
    text-transform: uppercase;
    color: #2C3E50;
    margin-bottom: 0px;
    letter-spacing: 2px;
    font-weight: bold;
}

/*progressbar*/
#progressbar {
    margin-bottom: 10px;
    overflow: hidden;
    /*CSS counters to number the steps*/
    counter-reset: step;
}

#progressbar li {
    list-style-type: none;
    color: #000;
    text-transform: uppercase;
    font-size: 14px;
    width: 33.33%;
    float: left;
    position: relative;
    letter-spacing: 1px;
}

#progressbar li:before {
    content: counter(step);
    counter-increment: step;
    width: 24px;
    height: 24px;
    line-height: 26px;
    display: block;
    font-size: 12px;
    color: #fff;
    background:#017DC7;
    border-radius: 25px;
    margin: 0 auto 10px auto;
}

/*progressbar connectors*/
#progressbar li:after {
    content: '';
    width: 100%;
    height: 2px;
    background: #017DC7;
    position: absolute;
    left: -50%;
    top: 9px;
    z-index: -1; /*put it behind the numbers*/
}

#progressbar li:first-child:after {
    /*connector not needed before the first step*/
    content: none;
}

/*marking active/completed steps green*/
/*The number of the step and the connector before it = green*/
#progressbar li.active:before, #progressbar li.active:after {
    background: #28a745;
    color: #fff;
}


/* Not relevant to this form */
.dme_link {
    margin-top: 30px;
    text-align: center;
}
.dme_link a {
    background: #FFF;
    font-weight: bold;
    color: #28a745;
    border: 0 none;
    border-radius: 25px;
    cursor: pointer;
    padding: 5px 25px;
    font-size: 12px;
}

.dme_link a:hover, .dme_link a:focus {
    background: #C5C5F1;
    text-decoration: none;
}
.margin_btm_offset30{
	margin-bottom:30px;
}

.paddingrlOffset{
	padding-left:20%;
	padding-right:20%;
}


.card {
    margin-top: 1em;
}
label{margin-left: 20px;}
#datepicker{margin: 0 20px 20px 20px;}
#datepicker > span:hover{cursor: pointer;}

/* IMG displaying */
.person-card {
    margin-top: 3em;
    padding-top: 2em;
}
.card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 23px;
    padding-bottom: 0px;
}
.person-card .card-title{
    text-align: center;
}

.margin_bottom_30pxOffset{
	margin-bottom:30px;
}
.card-title{
	border-bottom: 2px solid #5ea4f3;
}
.shopping-cart.dark {
    background-color: #f6f6f6;
    padding-top: 19px;
    padding-bottom: 30px;
}
.form-group{
	margin-bottom: 10px;
}
label.form-group {
  display: block;
  max-width: none;
}
label.col-form-label {
    margin: 0px;
    text-align: left;
}
.datepicker{
	padding:0px;!important;
}

.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width:100%;
}
.icon {
    padding: 6px;
    background: #d1d1d1;
    color: white;
    text-align: center;
    padding-top: 9px;
    height: 38px;
}
.input-field{
	border-radius:0px !important;
}
.form-control{
	border-radius:0px !important;
}

/* The customcheck */
.customcheck {
    display: block;
    position: relative;
    padding-left: 35px;
    margin-bottom: 12px;
    cursor: pointer;
    font-size: 22px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* Hide the browser's default checkbox */
.customcheck input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
}

/* Create a custom checkbox */



.checkmark {
    left: 0;
   position: absolute;
     /* top: 0; */
    height: 25px;
    width: 25px;
    border: 1px solid #d6d6d6;
}

/* On mouse-over, add a grey background color */
.customcheck:hover input ~ .checkmark {
    background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.customcheck input:checked ~ .checkmark {
    background-color: #02cf32;
    border-radius: 5px;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
    content: "";
    position: absolute;
    display: none;
}

/* Show the checkmark when checked */
.customcheck input:checked ~ .checkmark:after {
    display: block;
}

/* Style the checkmark/indicator */
.customcheck .checkmark:after {
    left: 9px;
    top: 5px;
    width: 5px;
    height: 10px;
    border: solid white;
    border-width: 0 3px 3px 0;
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg);
}
</style>


<div class="container-fluid margin_btm_offset30">
<!-- MultiStep Form -->
<div class="row">
    <div class="col-md-12">
        <form id="msform">
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">	Personal Details</li>
                <li>Address Details</li>
                <li>Contact Details</li>
            </ul>
            <!-- fieldsets -->
            <fieldset class="fieldsetCont">
                <h2 class="fs-title">Personal Details</h2>
				<!-- Main Row Div Start -->
<div class="row">
	<div class="col-md-3">
        <div class="card-body">
                        
			<div class="form-group form-inline d-flex justify-content-between required">
				<label for="s_2_1_19_0" class="col-form-label"> Customer Rel. No.:</label>
				<input type="s_2_1_19_0" class="form-control" id="s_2_1_19_0" placeholder="#1234556">
			</div>
			<div class="form-group form-inline d-flex justify-content-between">
				<label for="s_2_1_96_0" class="col-form-label"> Title:</label>
				<select  style="width:100%;" class="form-control" id="s_2_1_96_0" name="s_2_1_96_0">
				<option value="Select Title">Select Title</option>
				</select>
			</div>
			<div class="form-group form-inline d-flex justify-content-between">
				<label for="s_2_1_36_0" class="col-form-label"> Contact Method:</label>
				<select   style="width:100%;" class="form-control" id="s_2_1_36_0" name="s_2_1_36_0">
				<option value="Select Contact Method">Select Contact Method</option>
				</select>
			</div>
			<div class="form-group form-inline d-flex justify-content-between">
				<label for="s_2_1_1_0" class="col-form-label">  Customer Segment:</label>
				<select  style="width:100%;"  class="form-control" id="s_2_1_1_0" name="s_2_1_1_0">
				<option value="Customer Segment">Customer Segment</option>
				</select>
			</div>
			
			<div class="form-group form-inline d-flex justify-content-between required">
				<label for="Pan_card" class="col-form-label"> PAN No.:</label>
				<input type="Pan_card" class="form-control" id="Pan_card" placeholder="PAN Number">
			</div>
			
			

        </div>
              
    </div>
	<!-- First Column End Here -->
	<div class="col-md-3">
        <div class="card-body">
		
			<div class="form-group form-inline d-flex justify-content-between">
			  <label for="s_2_1_38_0" class="col-form-label">  Date:</label>
			<div class="input-container">
			<input class="input-field form-control datepicker" type="text" id="s_2_1_38_0" name="s_2_1_38_0"><i class="fa fa-calendar icon"></i>
			</div>
			</div>
			
			<div class="form-group form-inline d-flex justify-content-between">
				<label for="s_2_1_84_0" class="col-form-label"> Last Name:</label>
				<input type="text" class="form-control" id="s_2_1_84_0" name="s_2_1_84_0">
			  
			</div>
		   
			
			
			
			<div class="form-group form-inline d-flex justify-content-between">
			<label for="s_2_1_103_0" class="col-form-label">Account/Company:</label>
			<input type="text" class="form-control" id="s_2_1_103_0" name="s_2_1_103_0">

			</div>
			<div class="form-group form-inline d-flex justify-content-between">
			<label for="s_2_1_7_0" class="col-form-label">Contact Id:</label>
			<input type="text" class="form-control" id="s_2_1_7_0" name="s_2_1_7_0">

			</div>
			<div class="form-group form-inline d-flex justify-content-between required">
				<label for="GSTIN" class="col-form-label"> GSTIN:</label>
				<input type="GSTIN" class="form-control" id="GSTIN" placeholder="GSTIN">
			</div>

		</div>
	</div>
	<!-- Second Column End Here -->
	
	<div class="col-md-3">
        <div class="card-body">
			<div class="form-group form-inline d-flex justify-content-between">
				<label for="s_2_1_34_0" class="col-form-label">  Category:</label>
				<select  style="width:100%;" class="form-control" id="s_2_1_34_0" name="s_2_1_34_0">
				<option value="Select category">Select category</option>
				</select>
			</div>
			<div class="form-group form-inline d-flex justify-content-between">
				<label for="s_2_1_85_0" class="col-form-label"> First Name:</label>
				<input type="text" class="form-control" id="s_2_1_85_0" name="s_2_1_85_0">
			   
			</div>
			 <div class="form-group form-inline d-flex justify-content-between">
				<label for="s_2_1_40_0" class="col-form-label"> Households:</label>
				<input type="text" class="form-control" id="s_2_1_40_0" name="s_2_1_40_0">
			   
			</div>
			<div class="form-group form-inline d-flex justify-content-between">
				<label for="s_2_1_14_0" class="col-form-label"> Merge With:</label>
				<input type="text" class="form-control" id="s_2_1_14_0" name="s_2_1_14_0">
			   
			</div>
		</div>
	</div>
	<!-- Third Column End Here -->
	

	
	<div class="col-md-3">
        <div class="card-body">
			<div class="form-group form-inline d-flex justify-content-between">
			<label for="s_2_1_39_0" class="col-form-label">  Select Geneder:</label>
			<select  style="width:100%;" class="form-control" id="s_2_1_39_0" name="s_2_1_39_0">
			<option value="Select category">Select category</option>
			<option value="Male">Male</option>
			<option value="Female">Female</option>
			</select>
			</div>
			<div class="form-group form-inline d-flex justify-content-between">
			<label for="s_2_1_94_0" class="col-form-label">  Middle Name:</label>
			<input type="text" class="form-control" id="s_2_1_94_0" name="s_2_1_94_0">

			</div>
		
			<div class="form-group form-inline d-flex justify-content-between">
			  <label for="s_2_1_33_0" class="col-form-label">  Birthdate:</label>
			<div class="input-container">
			<input class="input-field form-control datepicker" type="text" id="s_2_1_33_0" name="s_2_1_33_0"><i class="fa fa-calendar icon"></i>
			</div>
			</div>
			
			<div class="form-group form-inline d-flex justify-content-between">
			<label for="s_2_1_18_0" class="col-form-label"> User Id:</label>
			<input type="text" class="form-control" id="s_2_1_18_0" name="s_2_1_18_0">

			</div>
		</div>
	</div>
	
</div>
			<!-- Main Row Div End -->
           
				
				
				
				
                <input type="button" name="next" class="next action-button" value="Next"/>
            </fieldset>
            <fieldset class="fieldsetCont">
                <h2 class="fs-title">Address Details</h2>
              
		<div class="container">
            <div class="row offset-md-1">
			<div class="col-md-5">
				 <div class="card-body">
					<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_24_0" class="col-form-label"> Address:</label>
                           <textarea class="form-control" name="s_2_1_24_0" id="s_2_1_24_0"></textarea>
                        </div> 
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="ppl" class="col-form-label"> Landmark:</label>
                         <textarea class="form-control" name="s_2_1_24_0" id="s_2_1_24_0"></textarea>
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_0_0" class="col-form-label">  Area:</label>
                           <input class="form-control" type="text" name="s_2_1_0_0" id="s_2_1_0_0">
                        </div>
						
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_78_0" class="col-form-label">City/Town/Village:</label>
                           <input class="form-control" type="text" name="s_2_1_78_0" id="s_2_1_78_0">
                        </div>
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_31_0" class="col-form-label"> Country:</label>
                           <input class="form-control" type="text" name="s_2_1_31_0" id="s_2_1_31_0">
                        </div>
						
                </div>
			</div>
			<div class="col-md-5">
				<div class="card-body">
				<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_81_0" class="col-form-label"> State:</label>
                           <input class="form-control" type="text" name="s_2_1_81_0" id="s_2_1_81_0">
                        </div>
				<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_11_0" class="col-form-label">District:</label>
                           <input class="form-control" type="text" name="s_2_1_11_0" id="s_2_1_11_0">
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_17_0" class="col-form-label"> Tehsil/Taluka:</label>
                           <input class="form-control" type="text" name="s_2_1_17_0" id="s_2_1_17_0">
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_80_0" class="col-form-label"> Pin Code:</label>
                           <input class="form-control" type="text" name="s_2_1_80_0" id="s_2_1_80_0">
                        </div>
						
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_81_0" class="col-form-label">Panchayat:</label>
                           <input class="form-control" type="text" name="s_2_1_81_0" id="s_2_1_81_0">
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_13_0" class="col-form-label">Habitation Type:</label>
                           <input class="form-control" type="text" name="s_2_1_13_0" id="s_2_1_13_0">
                        </div>
					
            </div>
			</div>
			 
					
            </div>
		</div>
			  
			  
                <input type="button" name="previous" class="previous action-button-previous" value="Previous"/>
                <input type="button" name="next" class="next action-button" value="Next"/>
            </fieldset>
            <fieldset class="fieldsetCont">
                <h2 class="fs-title">Contact Details</h2>
               
			   	<div class="container">
            <div class="row">
			<div class="col-md-4">
				 <div class="card-body">
					<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_100_0" class="col-form-label">   Cell Phone No:</label>
                           <input class="form-control" type="text" name="s_2_1_100_0" id="s_2_1_100_0">
                        </div> 
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_43_0" class="col-form-label">  Std Code:</label>
                           <input class="form-control" type="text" name="s_2_1_43_0" id="s_2_1_43_0">
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_98_0" class="col-form-label">   Phone (R):</label>
                           <input class="form-control" type="text" name="s_2_1_98_0" id="s_2_1_98_0">
                        </div>
						
						
						<div class="form-group form-inline d-flex justify-content-between">
						  <label for="s_2_1_111_0" class="col-form-label"> Email:</label>
						
						<input class="form-control" type="email" id="s_2_1_111_0" name="s_2_1_111_0">
					
                        </div>
                </div>
			</div>
			<div class="col-md-4">
				<div class="card-body">
						<div class="form-group form-inline d-flex justify-content-between">
						  <label for="s_2_1_95_0" class="col-form-label"> Designation:</label>
						<input class="form-control" type="text" id="s_2_1_95_0" name="s_2_1_127_0">
                        </div>
						
						<div class="form-group form-inline d-flex justify-content-between">
						  <label for="s_2_1_47_0" class="col-form-label"> Organization:</label>
						<input class="form-control" type="text" id="s_2_1_47_0" name="s_2_1_47_0">
                        </div>
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_20_0" class="col-form-label"> Contact Team:</label>
                           <input class="form-control" type="text" name="s_2_1_20_0" id="s_2_1_20_0">
                        </div>
						
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_97_0" class="col-form-label"> Phone (O):</label>
                           <input class="form-control" type="text" name="s_2_1_97_0" id="s_2_1_97_0">
                        </div>
            </div>
			</div>
			 
			 
			 <div class="col-md-4">
				<div class="card-body">
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_99_0" class="col-form-label">Fax #:</label>
                           <input class="form-control" type="text" name="s_2_1_99_0" id="s_2_1_99_0">
                        </div>
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_37_0" class="col-form-label">Others</label>
                           <textarea class="form-control" name="s_2_1_37_0" id="s_2_1_37_0"></textarea>
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="s_2_1_3_0" class="col-form-label"> Residential Status:</label>
                           <select  style="width:100%;" class="form-control" name="s_2_1_3_0" id="s_2_1_3_0">
						   <option value="Select Residential Status">Select Residential Status</option>
						   </select>
                        </div>
						
					
            </div>
			</div>
					
            </div>
		</div>
				
				
                <input type="button" name="previous" class="previous action-button-previous" value="Previous"/>
                <input type="submit" name="submit" class="submit action-button" value="Submit"/>
            </fieldset>
        </form>
        <!-- link to designify.me code snippets -->
       
        <!-- /.link to designify.me code snippets -->
    </div>
</div>
</div>
<!-- /.MultiStep Form -->
<script>

//jQuery time
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches

$(".next").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	next_fs = $(this).parent().next();
	
	//activate next step on progressbar using the index of next_fs
	$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
	
	//show the next fieldset
	next_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale current_fs down to 80%
			scale = 1 - (1 - now) * 0.2;
			//2. bring next_fs from the right(50%)
			left = (now * 50)+"%";
			//3. increase opacity of next_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({
        'transform': 'scale('+scale+')'
        //'position': 'absolute'
      });
			next_fs.css({'left': left, 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});

$(".previous").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	previous_fs = $(this).parent().prev();
	
	//de-activate current step on progressbar
	$("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
	
	//show the previous fieldset
	previous_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale previous_fs from 80% to 100%
			scale = 0.8 + (1 - now) * 0.2;
			//2. take current_fs to the right(50%) - from 0%
			left = ((1-now) * 50)+"%";
			//3. increase opacity of previous_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({'left': left});
			previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});

$(".submit").click(function(){
	return false;
});
</script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
        $(document).on('focus', '.datepicker',function(){
            $(this).datepicker({
                todayHighlight:true,
                format:'yyyy-mm-dd',
                autoclose:true
            })
        });
    </script>