<!DOCTYPE html>
<html lang="en">  
<head>
<style>
.paddingtopOffset{
	padding-top:20px;
}
</style>
</head>
<body>

<!--    <h2>User Login</h2>
    <?php
    if(!empty($success_msg)){
        echo '<p class="statusMsg">'.$success_msg.'</p>';
    }elseif(!empty($error_msg)){
        echo '<p class="statusMsg">'.$error_msg.'</p>';
    }
    ?>
   
    <p class="footInfo">Don't have an account? <a href="<?php echo base_url(); ?>users/registration">Register here</a></p> -->
	
	<div class="container-fluid h-100">
    <div class="row justify-content-center align-items-center h-100">
        <div class="col col-sm-6 col-md-6 col-lg-4 col-xl-3 text-center paddingtopOffset">
		<img class="img-responsive" src="/img/Default_Profile.png" style="width: 15%;">
<h3 class="text-center">Online AMC Login</h3>
            <form action="" method="post">
        <div class="form-group has-feedback">
            <input type="email" class="form-control" name="email" placeholder="Email" required="" value="">
            <?php echo form_error('email','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
          <input type="password" class="form-control" name="password" placeholder="Password" required="">
          <?php echo form_error('password','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
            <input type="submit" name="loginSubmit" class="btn btn-lg btn-primary" value="Login"/>
            <a href="http://localhost/index.php/registration" class="btn btn-lg btn-primary" >Register</a>
        </div>
    </form>
        </div>
    </div>

	
</div>
</body>
</html>