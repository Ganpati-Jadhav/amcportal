<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
.formOffsetElm{
	background:#fff;
	padding:20px;
}
</style>
<script type="text/javascript">
$(document).ready(function(){
	$("#LoginButtonAC").click(function(){
		$("#LoginForm").css("display","block");
		$("#RegistrationForm").css("display","none");
	});
	$(".LoginButtonAC1").click(function(){
		$("#LoginForm").css("display","block");
		$("#RegistrationForm").css("display","none");
		$("#LoginOTP").css("display","none");
	});
	$("#RegisterBTN").click(function(){
		$("#LoginForm").css("display","none");
		$("#RegistrationForm").css("display","block");
	});
	$("#RegisterBTNL").click(function(){
		$("#LoginForm").css("display","none");
		$("#RegistrationForm").css("display","block");
	});
	$(".DirectLoginForm").click(function(){
		$("#LoginForm").css("display","none");
		$("#RegistrationForm").css("display","none");
		$("#LoginOTP").css("display","block");
	});
	
});
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 
 <script type='text/javascript'>
  $(document).ready(function(){
 
   $('#getVehicleD').click(function(){
    var chassis_number = $("#chassis_number_getD").val();
    var registration_number = $("#registration_numbergetD").val();
	//alert(chassis_number);
    $.ajax({
     url:'<?=base_url()?>index.php/addvehicle/getVehicleDetails',
     method: 'post',
     data: {
		 chassis_number: chassis_number,
		 registration_number: registration_number
		 
	 },
     dataType: 'json',
     success: function(response){
      var len = response.length;

      if(len > 0){
       // Read values
       var ResMobileNumber = response[0].phone;
       //alert(ResMobileNumber);
	   var lastFourDigitsMob = ResMobileNumber.substr(ResMobileNumber.length - 4); // => "Tabs1"
 
       $('#ResMobileNumber').text(lastFourDigitsMob);
       
 
      }else{
       $('#ResMobileNumber').text('');
       
      }
 
     }
   });
  });
 });
 </script>
</head>
<body>


<!-- Form Container start Here -->
<div class="container-fluid top-content">

<div class="row">

<div class="col-md-8 col-sm-12 col-xs-8 col-lg-5 col-xl-8 text-center" style="background:url(/img/sm-background.gif);background-size:contain">
<img style="opacity:0.3;" class="img-responsive" width="100%" src="/img/mainbg.jpg">
</div>


<div id="RegistrationForm" style="display:none;" class="col-md-4 col-sm-12 col-xs-10 col-lg-4 col-xl-4 text-center formOffsetElm">
<img class="img-responsive" src="/img/Default_Profile.png" style="width: 15%;">
<h2 class="text-center">Online AMC Registration</h2>
    <form action="" method="post">
        <div class="form-group">
            <input type="text" class="form-control" name="name" placeholder="Name" required="" value="<?php echo !empty($user['name'])?$user['name']:''; ?>">
          <?php echo form_error('name','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
            <input type="email" class="form-control" name="email" placeholder="Email" required="" value="<?php echo !empty($user['email'])?$user['email']:''; ?>">
          <?php echo form_error('email','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="phone" placeholder="Phone" value="<?php echo !empty($user['phone'])?$user['phone']:''; ?>">
        </div>
        <div class="form-group">
          <input type="password" class="form-control" name="password" placeholder="Password" required="">
          <?php echo form_error('password','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
          <input type="password" class="form-control" name="conf_password" placeholder="Confirm password" required="">
          <?php echo form_error('conf_password','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
			<select name="gender" class="form-control">
			<option value="Male">Male</option>
			<option value="Female">Female</option>
			</select>
        </div>
        <div class="form-group">
		    <input id="LoginButtonAC" type="button" name="cancelbtn" class="btn btn-lg btn-primary " value="Login"/>
            <input id="RegisterBTNL" type="button" name="regisSubmit" class="btn btn-lg btn-primary " value="Register"/>

        </div>
    </form>
    <p class="footInfo">Direct Login Through Mobile <a class="DirectLoginForm" href="javascript:void(0)">Click here</a></p> 
</div>



<div id="LoginForm" class="col-md-4 col-sm-12 col-xs-10 col-lg-4 col-xl-4 text-center formOffsetElm" style="display:none;">
<img class="img-responsive" src="/img/Default_Profile.png" style="width: 15%;">
<h2 class="text-center">Online AMC Login</h2>
    <form action="" method="post">
        
        <div class="form-group">
            <input type="email" class="form-control" name="email" placeholder="User Id/ Email" required="" value="<?php echo !empty($user['email'])?$user['email']:''; ?>">
          <?php echo form_error('email','<span class="help-block">','</span>'); ?>
        </div>
       
        <div class="form-group">
          <input type="password" class="form-control" name="password" placeholder="Password" required="">
          <?php echo form_error('password','<span class="help-block">','</span>'); ?>
        </div>
        
        
        <div class="form-group">
		<input id="RegisterBTN" type="button" name="regisSubmit" class="btn btn-lg btn-primary " value="Register"/>
            <a id="LoginBTN" href="<?php echo base_url(); ?>index.php/amcenquiry" class="btn btn-lg btn-primary ">Login</a>

        </div>
    </form> 
	<p class="footInfo">Direct Login Through Mobile <a class="DirectLoginForm" href="javascript:void(0)">Click here</a></p>
</div>



<div id="LoginOTP" class="col-md-4 col-sm-12 col-xs-10 col-lg-4 col-xl-4 text-center formOffsetElm" >


<div class="row">
			<div class="col-xs-12 tabWrapper container-fluid">
			
						<div class="row justify-content-center align-items-center">
						<form method="POSt" class="col-md-9 col-lg-9 col-xl-9 col-sm-12 offset-md-1">
						<div class="row">
						  <div class="col-md-10 col-lg-10 col-xs-12 col-sm-12">
							<input type="text" class="form-control" id="registration_numbergetD" name="registration_numbergetD" placeholder="Enter Vehicle Registration Number">
						  </div>
						  <div class="col-md-2 col-lg-2 col-xs-12 col-sm-12">
						  </div>
						  </div>
						  
						    <div class="row justify-content-center align-items-center">
							<div class="col-md-10 col-lg-10 col-xs-12 col-sm-12">
							<div class="form-group" style="padding: 7px;margin-bottom:0px!important;">
							<label  style="margin-bottom:0px!important;" for="formGroupExampleInput2" >OR</label>
												  
							</div>
							</div>
							<div class="col-md-2 col-lg-2 col-xs-12 col-sm-12">
						  </div>
						 
						  </div>

							
							<div class="row justify-content-center align-items-center">
							<div class="col-md-10 col-lg-10 col-xl-10 col-xs-12 col-sm-12">
							<div class="form-group">
							<input type="text" class="form-control" name="chassis_number_getD" id="chassis_number_getD" placeholder="Enter Chassis Number">
							</div>
							</div>
							<div class="col-md-2 col-lg-2 col-xl-2 col-xs-12 col-sm-12 d-flex justify-content-start">
							<div class="form-group">
							<button type="button"  id="getVehicleD" class="btn btn-primary">Go</button>
							
							</div>
							</div>
							</div>
						  </div>
						</form>  

						<!-- Vehicle verify Div -->
						<hr>
						<div class="row justify-content-center align-items-center">
						<form class="col-lg-12 col-md-12 col-xl-12 col-sm-12 col-xs-12">
						<div class="row">
						<div class="container text-center justify-content-center">
						<p class="text-success"><strong> Your Vehicle Is Verified </strong></p>
						</div>
						<div class="container">
						<p class="text-center justify-content-center"> Please Enter 10 Digit Mobile Number #(******<span id="ResMobileNumber"> </span>) To Proceed.</p>
						</div>
						<div class="col-md-8 col-lg-8 col-xl-8 col-xs-12 col-sm-12 offset-md-2">
						<div class="form-group">
							<input type="text" class="form-control" name="mobile_number" placeholder="Enter Mobile Number">
							
							</div>
						<div class="form-group text-center">
							<button type="button" class="btn btn-primary">Verify</button>
						</div>
						</div>
						
						</div>
						
						</form>
						</div>  
						
						<!-- Vehicle verify Div END-->
						
						
						
						<!-- Mobile verify Div -->
						<hr>
						<div class="row justify-content-center align-items-center">
						<form class="col-lg-12 col-md-12 col-xl-12 col-sm-12 col-xs-12">
						<div class="row">
						<div class="col-md-12 col-sm-12 col-lg-12 col-xl-12">
						<p class="text-center justify-content-center"> Your Mobile Number Is Verified. We have sent an OPT on your Mobile Number. </p>
						</div>
						<div class="col-md-8 col-lg-8 col-xl-8 offset-md-2 col-sm-12">
						
						
						<div class="form-group">
							<input type="text" class="form-control" name="mobile_number" placeholder="Enter OTP ">
							
							</div>
						<div class="form-group text-center">
							
							<button type="button" class="btn btn-primary my-5">Re-Send OTP</button>
							<a href="<?php echo base_url(); ?>index.php/amcenquiry" class="btn btn-primary my-2">Submit</a>
						</div>
						</div>
						<div class="col-md-2 col-lg-2 col-xl-2 col-xs-12 col-sm-12 ">
						</div>
						</div>
						
						</form>
						<p class="footInfo">Login Through User Id <a class="LoginButtonAC1" href="javascript:void(0)">Click here</a></p>
						</div>  
						
						<!-- Mobile verify Div END-->
						
						</div>  
					
					</div>


</div>


</div>


</div>
<!-- End Of Form container -->
</body>
</html>


<!--<!DOCTYPE html>
<html lang="en">  
<head>
<link href="<?php echo base_url(); ?>assets/css/style.css" rel='stylesheet' type='text/css' />
</head>
<body>
<div class="container">
    <h2>User Registration</h2>
    <form action="" method="post">
        <div class="form-group">
            <input type="text" class="form-control" name="name" placeholder="Name" required="" value="<?php echo !empty($user['name'])?$user['name']:''; ?>">
          <?php echo form_error('name','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
            <input type="email" class="form-control" name="email" placeholder="Email" required="" value="<?php echo !empty($user['email'])?$user['email']:''; ?>">
          <?php echo form_error('email','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="phone" placeholder="Phone" value="<?php echo !empty($user['phone'])?$user['phone']:''; ?>">
        </div>
        <div class="form-group">
          <input type="password" class="form-control" name="password" placeholder="Password" required="">
          <?php echo form_error('password','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
          <input type="password" class="form-control" name="conf_password" placeholder="Confirm password" required="">
          <?php echo form_error('conf_password','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
            <?php
            if(!empty($user['gender']) && $user['gender'] == 'Female'){
                $fcheck = 'checked="checked"';
                $mcheck = '';
            }else{
                $mcheck = 'checked="checked"';
                $fcheck = '';
            }
            ?>
            <div class="radio">
                <label>
                <input type="radio" name="gender" value="Male" <?php echo $mcheck; ?>>
                Male
                </label>
            </div>
            <div class="radio">
                <label>
                  <input type="radio" name="gender" value="Female" <?php echo $fcheck; ?>>
                  Female
                </label>
            </div>
        </div>
        <div class="form-group">
            <input type="submit" name="regisSubmit" class="btn-primary" value="Submit"/>
        </div>
    </form>
    <p class="footInfo">Already have an account? <a href="<?php echo base_url(); ?>users/login">Login here</a></p>              
</div>
</body>
</html>-->
