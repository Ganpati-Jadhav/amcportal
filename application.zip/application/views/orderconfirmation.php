<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
 <link rel="stylesheet" type="text/css" media="screen" href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 	<link rel="stylesheet" href="/css/shopping-cart.css">
<style>
/*custom font*/
@import url(https://fonts.googleapis.com/css?family=Montserrat);

/*basic reset*/
* {
    margin: 0;
    padding: 0;
}


/*form styles*/
#msform {
    text-align: center;
    position: relative;
    margin-top: 15px;
}

#msform fieldset {
    background: white;
    border: 0 none;
    border-radius: 0px;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    padding: 20px 30px;
    box-sizing: border-box;
    width: 100%;
    /*stacking fieldsets above each other*/
    position: relative;
}

/*Hide all except first fieldset*/
#msform fieldset:not(:first-of-type) {
    display: none;
}

/*inputs*/
#msform input, #msform textarea {
    padding: 15px;
    border: 1px solid #ccc;
    border-radius: 0px;
    margin-bottom: 0px;
    box-sizing: border-box;
    font-family: montserrat;
    color: #2C3E50;
    font-size: 13px;
}

#msform input:focus, #msform textarea:focus {
    -moz-box-shadow: none !important;
    -webkit-box-shadow: none !important;
    box-shadow: none !important;
    border: 1px solid #28a745;
    outline-width: 0;
    transition: All 0.5s ease-in;
    -webkit-transition: All 0.5s ease-in;
    -moz-transition: All 0.5s ease-in;
    -o-transition: All 0.5s ease-in;
}

/*buttons*/
#msform .action-button {
    width: 100px;
    background: #007bff;
    font-weight: bold;
    color: white;
    border: 0 none;
    border-radius: 25px;
    cursor: pointer;
    padding: 10px 5px;
    margin: 10px 5px;
}

#msform .action-button:hover, #msform .action-button:focus {
    box-shadow: 0 0 0 2px white, 0 0 0 3px #28a745;
}

#msform .action-button-previous {
    width: 100px;
    background: #017DC7;
    font-weight: bold;
    color: white;
    border: 0 none;
    border-radius: 25px;
    cursor: pointer;
    padding: 10px 5px;
    margin: 10px 5px;
}

#msform .action-button-previous:hover, #msform .action-button-previous:focus {
    box-shadow: 0 0 0 2px white, 0 0 0 3px #C5C5F1;
}

/*headings*/
.fs-title {
    font-size: 18px;
    text-transform: uppercase;
    color: #2C3E50;
    margin-bottom: 0px;
    letter-spacing: 2px;
    font-weight: bold;
}

/*progressbar*/
#progressbar {
    margin-bottom: 10px;
    overflow: hidden;
    /*CSS counters to number the steps*/
    counter-reset: step;
}

#progressbar li {
    list-style-type: none;
    color: #000;
    text-transform: uppercase;
    font-size: 14px;
    width: 33.33%;
    float: left;
    position: relative;
    letter-spacing: 1px;
}

#progressbar li:before {
    content: counter(step);
    counter-increment: step;
    width: 24px;
    height: 24px;
    line-height: 26px;
    display: block;
    font-size: 12px;
    color: #fff;
    background:#017DC7;
    border-radius: 25px;
    margin: 0 auto 10px auto;
}

/*progressbar connectors*/
#progressbar li:after {
    content: '';
    width: 100%;
    height: 2px;
    background: #017DC7;
    position: absolute;
    left: -50%;
    top: 9px;
    z-index: -1; /*put it behind the numbers*/
}

#progressbar li:first-child:after {
    /*connector not needed before the first step*/
    content: none;
}

/*marking active/completed steps green*/
/*The number of the step and the connector before it = green*/
#progressbar li.active:before, #progressbar li.active:after {
    background: #28a745;
    color: #fff;
}


/* Not relevant to this form */
.dme_link {
    margin-top: 30px;
    text-align: center;
}
.dme_link a {
    background: #FFF;
    font-weight: bold;
    color: #28a745;
    border: 0 none;
    border-radius: 25px;
    cursor: pointer;
    padding: 5px 25px;
    font-size: 12px;
}

.dme_link a:hover, .dme_link a:focus {
    background: #C5C5F1;
    text-decoration: none;
}
.margin_btm_offset30{
	margin-bottom:30px;
}

.paddingrlOffset{
	padding-left:20%;
	padding-right:20%;
}


.card {
    margin-top: 1em;
}
label{margin-left: 20px;}
#datepicker{margin: 0 20px 20px 20px;}
#datepicker > span:hover{cursor: pointer;}

/* IMG displaying */
.person-card {
    margin-top: 3em;
    padding-top: 2em;
}
.card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 23px;
    padding-bottom: 0px;
}
.person-card .card-title{
    text-align: center;
}

.margin_bottom_30pxOffset{
	margin-bottom:30px;
}
.card-title{
	border-bottom: 2px solid #5ea4f3;
}
.shopping-cart.dark {
    padding-top: 19px;
    padding-bottom: 30px;
	background:#fff !important;
}
.form-group{
	margin-bottom: 10px;
}
label.form-group {
  display: block;
  max-width: none;
}
label.col-form-label {
    margin: 0px;
    text-align: left;
}
.datepicker{
	padding:0px;!important;
}

.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width:100%;
}
.icon {
    padding: 6px;
    background: #d1d1d1;
    color: white;
    text-align: center;
    padding-top: 9px;
    height: 38px;
}
.input-field{
	border-radius:0px !important;
}
.form-control{
	border-radius:0px !important;
}

/* The customcheck */
.customcheck {
    display: block;
    position: relative;
    padding-left: 35px;
    margin-bottom: 12px;
    cursor: pointer;
    font-size: 22px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* Hide the browser's default checkbox */
.customcheck input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
}

/* Create a custom checkbox */



.checkmark {
    left: 0;
   position: absolute;
     /* top: 0; */
    height: 25px;
    width: 25px;
    border: 1px solid #d6d6d6;
}

/* On mouse-over, add a grey background color */
.customcheck:hover input ~ .checkmark {
    background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.customcheck input:checked ~ .checkmark {
    background-color: #02cf32;
    border-radius: 5px;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
    content: "";
    position: absolute;
    display: none;
}

/* Show the checkmark when checked */
.customcheck input:checked ~ .checkmark:after {
    display: block;
}

/* Style the checkmark/indicator */
.customcheck .checkmark:after {
    left: 9px;
    top: 5px;
    width: 5px;
    height: 10px;
    border: solid white;
    border-width: 0 3px 3px 0;
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg);
}
@media(max-width:320px){
   .longLabelOffset{
	   margin-left:0px;word-break: break-all;word-break: break-word;width: 52%;
   }
}
@media only screen and (min-width : 320px) {
     .longLabelOffset{
	   margin-left:0px;word-break: break-all;word-break: break-word;width: 52%;
   }
}
/* Extra Small Devices, Phones */ 
@media only screen and (min-width : 480px) {
     .longLabelOffset{
	   margin-left:0px;word-break: break-all;word-break: break-word;width: 52%;
   }
}
/* Small Devices, Tablets */
@media only screen and (min-width : 768px) {
     .longLabelOffset{
	   margin-left:0px;word-break: break-all;word-break: break-word;width: 66%;
   }
}
/* Medium Devices, Desktops */
@media only screen and (min-width : 992px) {
     .longLabelOffset{
	   margin-left:0px;word-break: break-all;word-break: break-word;width: 66%;
   }
}
/* Large Devices, Wide Screens */
@media only screen and (min-width : 1200px) {
      .longLabelOffset{
	   margin-left:0px;word-break: break-all;word-break: break-word;width: 66%;
   }
}
.paddingOffsetcl{
	padding:30px;
}
.margintboffset{
	margin-top: 30px;
    margin-bottom: 30px;
}
</style>


<div class="container-fluid margin_btm_offset30">
<!-- MultiStep Form -->
<div class="row">
    <div class="col-md-12">
        <form id="msform">
           
           
            <!-- fieldsets -->
         
            <fieldset class="fieldsetCont">
                <h2 class="fs-title">Order Confirmation</h2>
               
			 <main class="page">
	 	<section class="shopping-cart dark">
	 		<div class="container-fluid">
		       
		        <div class="content">
	 				<div class="row">
	 					<div class="col-md-12 col-lg-8">

<div class="col-md-8 offset-md-2 pt-4 pb-4">
<dl class="d-flex justify-content-between">
<dt>Chassis Number<span></span></dt>
<dd>MAT612274EKBo47565</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>Vehicle Purchase Date<span></span></dt>
<dd>20/12/2017</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>AMC Product Description<span></span></dt>
<dd>Platinum plus AMC</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>AMC Purchase Date<span></span></dt>
<dd>10/11/2018</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>AMC End Date<span></span></dt>
<dd>10/11/2019</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>AMC Contract Number<span></span></dt>
<dd>#1234567890</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>Contract KMS<span></span></dt>
<dd>100,000</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>Contract Start Date<span></span></dt>
<dd>10/11/2016</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>Contract End Date<span></span></dt>
<dd>10/11/2019</dd>
</dl>
</div>
						</div>
         
						
	 					
			 			<div class="col-md-12 col-lg-4">
			 				<div class="summary">
			 					<h3>Payment Details</h3>
			 					<!--<div class="summary-item"><span class="text">Price</span><span class="price"><i class="fa fa-inr" aria-hidden="true"></i>5000.00</span></div>
			 					<div class="summary-item"><span class="text">Discount</span><span class="price"><i class="fa fa-inr" aria-hidden="true"></i>200.00</span></div>
			 					<div class="summary-item"><span class="text">CGST</span><span class="price"><i class="fa fa-inr" aria-hidden="true"></i>432.00</span></div>
			 					<div class="summary-item"><span class="text">SGST</span><span class="price"><i class="fa fa-inr" aria-hidden="true"></i>432.00</span></div>
			 					<div class="summary-item"><span class="text">Total</span><span class="price"><i class="fa fa-inr" aria-hidden="true"></i>5664.00</span></div>
			 					<a href="<?php echo base_url(); ?>index.php/transactionamc" class="btn btn-primary btn-lg btn-block">Proceed To Pay</a>
				 			-->
							
							<div class="col-md-12">
<dl class="d-flex justify-content-between">
<dt>Price<span></span></dt>
<dd>5000.00</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>Discount<span></span></dt>
<dd>200.00</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>CGST<span></span></dt>
<dd>432.00</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>SGST<span></span></dt>
<dd>432.00</dd>
</dl>
<dl class="d-flex justify-content-between">
<dt>Total<span></span></dt>
<dd>5664.00</dd>
</dl>
<a href="<?php echo base_url(); ?>index.php/transactionamc" class="btn btn-primary btn-lg btn-block">Proceed To Pay</a>

</div>
							</div>
			 			</div>
		 			</div> 
		 		</div>
	 		</div>
		</section>
	</main>
				
</fieldset>
        </form>
        <!-- link to designify.me code snippets -->
       
        <!-- /.link to designify.me code snippets -->
    </div>
</div>
</div>
<!-- /.MultiStep Form -->
<script>

//jQuery time
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches

$(".next").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	next_fs = $(this).parent().next();
	
	//activate next step on progressbar using the index of next_fs
	$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
	
	//show the next fieldset
	next_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale current_fs down to 80%
			scale = 1 - (1 - now) * 0.2;
			//2. bring next_fs from the right(50%)
			left = (now * 50)+"%";
			//3. increase opacity of next_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({
        'transform': 'scale('+scale+')'
        //'position': 'absolute'
      });
			next_fs.css({'left': left, 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});

$(".previous").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	previous_fs = $(this).parent().prev();
	
	//de-activate current step on progressbar
	$("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
	
	//show the previous fieldset
	previous_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale previous_fs from 80% to 100%
			scale = 0.8 + (1 - now) * 0.2;
			//2. take current_fs to the right(50%) - from 0%
			left = ((1-now) * 50)+"%";
			//3. increase opacity of previous_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({'left': left});
			previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});

$(".submit").click(function(){
	return false;
});
</script>
