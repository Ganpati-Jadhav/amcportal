<?php  
//print_r($particularvehicleDetails->result());
foreach ($particularvehicleDetails->result() as $vehicledetails)  
{
?>
       <div class="row">
            <div class="col-md-5 offset-md-1 rowdivop" >
               
                    <div class="card-body bgoffsettocardbody pl-lg-5 pr-lg-5 pl-md-5 pr-md-5 pl-xl-5 pr-xl-5 pl-sm-2 pr-sm-2 ">
                        <h5 class="card-title">Order Details <?php echo $vehicledetails->id; ?></h5>
                        <div class="form-group form-inline d-flex justify-content-between">
                            <label for="enquiry_number" class="col-form-label">Enquiry Ref. No:</label>
                            <input type="enquiry_number" class="form-control" id="enquiry_number" placeholder="#1234556" disabled>
                           
                        </div>
                        <div class="form-group form-inline d-flex justify-content-between">
                            <label for="quote" class="col-form-label">Quote #:</label>
                            <input type="text" class="form-control" id="quote" name="quote" >
                            
                        </div>
						
						 <div class="form-group form-inline d-flex justify-content-between">
                            <label for="enquiry_status" class="col-form-label">Enquiry Status:</label>
                           <input name="enquiry_status" class="form-control" id="enquiry_status" value="New" disabled>
						   
                        </div>
						
					    <div class="form-group form-inline d-flex justify-content-between">
                            <label for="enquiry_creation_date" class="col-form-label">Enquiry Creation Date:</label>
                            <input type="text" class="form-control" id="enquiry_creation_date" name="enquiry_creation_date" >
                          
                        </div>
					    <div class="form-group form-inline d-flex justify-content-between">
                            <label for="application_location" class="col-form-label">Application Location:</label>
                            <input type="text" class="form-control" id="application_location" name="application_location" >
                           
                        </div>
					    <div class="form-group form-inline d-flex justify-content-between">
                            <label for="team" class="col-form-label">Team:</label>
                            <input type="text" class="form-control" id="team" name="team" >
                            
                        </div>
					   
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="pan_number" class="col-form-label">Pan Number:</label>
                            <input type="text" class="form-control" id="pan_number" name="pan_number" >
                           
                        </div>
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="remarks" class="col-form-label">Remarks:</label>
                            <input type="text" class="form-control" id="remarks" name="remarks" >
                           
                        </div>
						
                    </div>
              
            </div>
			
			
			
			 <div class="col-md-5  rowdivop">
			   <div class="card-body bgoffsettocardbody pl-lg-5 pr-lg-5 pl-md-5 pr-md-5 pl-xl-5 pr-xl-5 pl-sm-2 pr-sm-2 ">
                        <h5 class="card-title">	Pricing Details</h5>
                         <div class="form-group form-inline d-flex justify-content-between">
                            <label for="es_amc_price" class="col-form-label">Estimated AMC Price:</label>
                            <input type="text" class="form-control" id="es_amc_price" name="es_amc_price">
                        </div> 
						
						
					    <div class="form-group form-inline d-flex justify-content-between">
                            <label for="price_list" class="col-form-label"> Price List:</label>
                            <input type="text" class="form-control" id="price_list" name="price_list" >
                          
                        </div>
					    <div class="form-group form-inline d-flex justify-content-between">
                            <label for="productapplication" class="col-form-label">Application:</label>
                            <input type="text" class="form-control" id="productapplication" name="productapplication" >
                           
                        </div>
					    <div class="form-group form-inline d-flex justify-content-between">
                            <label for="customer_type" class="col-form-label">Customer Type:</label>
                            <input type="text" class="form-control" id="customer_type" name="customer_type" >
                            
                        </div>
					    <div class="form-group form-inline d-flex justify-content-between">
                            <label for="contract_type" class="col-form-label">Contract Type:</label>
                            <input type="text" class="form-control" id="contract_type" name="contract_type" >
                           
                        </div>
						 <div class="form-group form-inline d-flex justify-content-between">
                            <label for="add_2" class="col-form-label">Address Line 2:</label>
                            <input type="text" class="form-control" id="add_2" name="add_2" >
                           
                        </div>
						
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="state" class="col-form-label">State:</label>
                            <input type="text" class="form-control" id="state" name="state" >
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="order_category" class="col-form-label">Order Category:</label>
                            <input type="text" class="form-control" id="order_category" name="order_category" >
                        </div>
                    </div>
            </div>
        </div>
		
		<div class="row" style="margin-bottom:30px;">
            <div class="col-md-5 offset-md-1 rowdivop" >
			 <div class="card-body bgoffsettocardbody pl-lg-5 pr-lg-5 pl-md-5 pr-md-5 pl-xl-5 pr-xl-5 pl-sm-2 pr-sm-2 ">
                        <h5 class="card-title">Product Details</h5>
                       
                        <div class="form-group form-inline d-flex justify-content-between">
                            <label for="ppl" class="col-form-label"> Parent Product Line:</label>
                            <select  class="form-control" id="amc_price_line" name="amc_price_line" >
							<option value="Select Product Line"> Select Product Line </option>
                           </select>
                        </div>
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="product_line" class="col-form-label"> Product Line:</label>
                            <select   class="form-control" id="product_list" name="product_line" >
							<option value="Select Product Line"> Select Product List </option>
                           </select>
                        </div>
						 
                        <div class="form-group form-inline d-flex justify-content-between">
                            <label for="amc_product" class="col-form-label"> *AMC Product:</label>
                           
							<select  class="form-control" id="amc_product" name="amc_product" >
							<option value="Select Product Line"> Select Product List </option>
                           </select>
                           
                        </div> 
						<div class="form-group form-inline d-flex justify-content-between">
                            <label for="amc_product_des" class="col-form-label">  AMC Description:</label>
                            
                           <textarea class="form-control" id="amc_product_des"></textarea>
                        </div>
						
						
						
                    </div>
               
                   
                </div>
           
		   
				<div class="col-md-5 align-self-center rowdivop">
				<div class="card-body bgoffsettocardbody pl-lg-5 pr-lg-5 pl-md-5 pr-md-5 pl-xl-5 pr-xl-5 pl-sm-2 pr-sm-2 ">
					<div class="margin_bottom_30pxOffset d-flex justify-content-center">
					<button type="button" class="btn btn-success btn-lg mr-2">Get Price</button>
					<button type="button" class="btn btn-primary btn-lg">Buy Now</button>
					</div>
				<h5>
				STEP 1: Lorem Lipsome</h5>
				<p>Lorem Lipsome Lorem Lipsome Lorem Lipsome, Lorem Lipsome Lorem Lipsome Lorem Lipsome Lorem Lipsome Lorem Lipsome Lorem Lipsome.</p>
				<p>Lorem Lipsome Lorem Lipsome Lorem Lipsome, Lorem Lipsome Lorem Lipsome Lorem Lipsome Lorem Lipsome Lorem Lipsome Lorem Lipsome.</p>
				<p>Lorem Lipsome Lorem Lipsome Lorem Lipsome, Lorem Lipsome Lorem .</p>
				
				</div>
				   
				</div>
		   
        </div>
<?php
}
?>	