<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
	<title> Active AMC List </title>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/b-1.5.4/b-colvis-1.5.4/b-html5-1.5.4/r-2.2.2/sc-1.5.0/sl-1.2.6/datatables.min.css"/>
 
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/b-1.5.4/b-colvis-1.5.4/b-html5-1.5.4/r-2.2.2/sc-1.5.0/sl-1.2.6/datatables.min.js"></script>

<script>
$(document).ready(function(){
 $('#example').DataTable();
});

</script>
<style>
#sidebar ul.components {
    padding: 20px 0;
    border-bottom: 1px solid #47748b;
}
#sidebar {
   
    color: #fff;
    transition: all 0.3s;
}
#sidebar ul li.active>a, a[aria-expanded="true"] {
    color: #47748b;
    background: #fff;
}
#sidebar ul li a {
    padding: 10px;
    font-size: 18px;
    display: block;
}
#sidebar ul li a {
    text-align: left;
}
#sidebar ul li a:hover {
    color: #7386D5;
    background: #fff;
}
#sidebar ul li a {
    padding: 10px;
    font-size: 1.1em;
    display: block;
}
#sidebar ul li a {
    text-align: left;
	color:#fff;
	text-decoration:none;
}
.amcTableListOuter{
	padding:20px;
}
.modal-dialog{
	min-width:900px;
}

</style>
  </head>

  <body>
  <div class="container-fluid">
  
  

<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
             <h4 class="modal-title text-center justify-content-center">Vehicle Details</h4>
			 <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
            </div>
        </div>
      
    </div>
</div>
  <div class="row">
  <div class="col-md-3 col-lg-3 col-xl-3 col-sm-12 col-xs-12" style="background:#6d7fcc;">
  <div class="wrapper">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
          
        </div>

        <ul class="list-unstyled components">
            <p>Dummy Heading</p>
            <li class="active">
                <a href="<?php echo base_url();?>index.php/activeamclist"  class="active">Active AMC</a>
             </li>
			 <li class="">
                <a href="<?php echo  base_url();?>index.php/terminatedamc">Terminated AMC</a>
             </li> 
			 <li>         
			 <a href="<?php echo base_url();?>index.php/blockedamc">Blocked AMC</a>
             </li>
			 <li>         
			  <a href="<?php echo base_url();?>index.php/inactiveamc" >Inactive AMC</a>
             </li>
			  <li>         
			 <a href="<?php echo base_url(); ?>index.php/transactions">Payment details</a>
             </li>
			 <li>         
			 <a href="<?php echo base_url();?>index.php/amcenquiry">New AMC Enquiry</a>
             </li>
			  <li>         
			 <a href="#homeSubmenu">Renewal Reminders</a>
             </li>
			 <li>         
			 <a href="#homeSubmenu">Profile Update</a>
             </li>
			 <li>         
			 <a href="#homeSubmenu">Logout</a>
             </li>
           
        </ul>
    </nav>

</div>
  </div>
  <div class="col-md-9 col-lg-9 col-xl-9 col-sm-12 col-xs-12 amcTableListOuter">
    <table id="example" class="table table-striped table-bordered nowrap" cellspacing="0" width="100%">
      <thead>
        <tr>
          <th>Chassis Number</th>
          <th>Registration Number</th>
          <th>Engine Number</th>
          <th>Fuel Type</th>
          <th>Model</th>
          <th>Variant</th>
          <th>Phone</th>
        </tr>
      </thead>
      <tbody>
	  <tr> 
         <?php  
         foreach ($allvehicles->result() as $vehicledetails)  
         {  ?> 
            <td><a href="javascript:void(0);" data-id="<?php echo $vehicledetails->id; ?>" class="openPopup"><?php echo $vehicledetails->chassis_number;?></a></td>  
            <td><?php echo $vehicledetails->registration_number;?></td>  
            <td><?php echo $vehicledetails->engine_number;?></td>  
            <td><?php echo $vehicledetails->fuel_type;?></td>  
            <td><?php echo $vehicledetails->model;?></td>  
            <td><?php echo $vehicledetails->variant;?></td>  
            <td><?php echo $vehicledetails->phone;?></td>  
            </tr>  
			<script>
 $('.openPopup').click(function(){
   var vehicleid = $(this).attr("data-id");
   // AJAX request
   $.ajax({
    url: '<?php echo base_url();?>index.php/allmodelspop/vehicledetailspopup',
    type: 'post',
    data: {vehicleid: vehicleid},
    success: function(response){ 
      // Add response in Modal body
      $('.modal-body').html(response);

      // Display Modal
      $('#myModal').modal('show'); 
    }
  });
 });
 

</script>
			
         <?php }  
         ?>  
    </tbody>
    </table>
	
	</div>
	</div>
	<!-- Table and Side Bar Row End -->
	
	</div>

  </body>

</html>
