<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
	<title> Transaction History</title>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/b-1.5.4/b-colvis-1.5.4/b-html5-1.5.4/r-2.2.2/sc-1.5.0/sl-1.2.6/datatables.min.css"/>
 
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/b-1.5.4/b-colvis-1.5.4/b-html5-1.5.4/r-2.2.2/sc-1.5.0/sl-1.2.6/datatables.min.js"></script>

<script>
$(document).ready(function(){
	
$("#customRadio").click(function(){
	$("#AmcHistory").css("display","block");
	$("#jcpHistory").css("display","none");
});
$("#customRadio2").click(function(){
		$("#AmcHistory").css("display","none");
	$("#jcpHistory").css("display","block");
});

$('#examplePayment').DataTable();

//$('#example').DataTable();
var table =  $('#example').DataTable();

 $('#dropdown1').on('change', function () {
                    table.columns(7).search( this.value ).draw();
                } );
 
/*   $("#example thead th").each( function ( i ) {
        var select = $('<select name="status"><option value="All"></option></select>')
            .appendTo( $(this).empty() )
            .on( 'change', function () {
                table.column( i )
                    .search( $(this).val() )
                    .draw();
            } );
 
        table.column( i ).data().unique().sort().each( function ( d, j ) {
            select.append( '<option value="'+d+'">'+d+'</option>' )
        } );
    } ); */
 
});


/*$(document).ready( function () { 
    // Setup - add a text input to each header cell
    $('#example thead tr:eq(1) th').each( function () {
        var title = $('#example thead tr:eq(0) th').eq( $(this).index() ).text();
        $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
    } ); 
  
    var table = $('#example').DataTable({
        orderCellsTop: true
    });
  
    // Apply the search
    table.columns().every(function (index) {
        $('#example thead tr:eq(1) th:eq(' + index + ') input').on('keyup change', function () {
            table.column($(this).parent().index() + ':visible')
                .search(this.value)
                .draw();
        });
    });
});*/

</script>
<style>
#sidebar ul.components {
    padding: 20px 0;
    border-bottom: 1px solid #47748b;
}
#sidebar {
   
    color: #fff;
    transition: all 0.3s;
}
#sidebar ul li.active>a, a[aria-expanded="true"] {
    color: #47748b;
    background: #fff;
}
#sidebar ul li a {
    padding: 10px;
    font-size: 18px;
    display: block;
}
#sidebar ul li a {
    text-align: left;
}
#sidebar ul li a:hover {
    color: #7386D5;
    background: #fff;
}
#sidebar ul li a {
    padding: 10px;
    font-size: 1.1em;
    display: block;
}
#sidebar ul li a {
    text-align: left;
	color:#fff;
	text-decoration:none;
}
.amcTableListOuter{
	padding:20px;
}
.modal-dialog{
	min-width:900px;
}
.table-responsive {
    display: table;
}
.row.m1-h {
    background: white;
    border: 0 none;
    border-radius: 0px;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    box-sizing: border-box;
    width: 100%;
    position: relative;
    margin-top: 20px;
    margin-bottom: 20px;
    margin-left: 0px;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.current, .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
    color: #FFF !important;
    border: 1px solid #d6d6d6 !important;
       padding-top: 8px!important;
    padding-bottom: 8px!important;
    /* background-color: transparent!important; */
    border: 1px solid #007bff!important;
    color: #fff!important;
    margin-top: 2%!important;
    font-weight: 400!important;
    font-size: 14px!important;
    background: #007bff!important;
}

</style>
  </head>

  <body>
  <div class="container-fluid">
  
  

<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
             <h4 class="modal-title text-center justify-content-center">Vehicle Details</h4>
			 <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" data-dismiss="modal">Request For Renewal</button>
            </div>
        </div>
      
    </div>
</div>
<div class="row m1-h">
  <div class="col-md-12 col-lg-12 col-xl-12 col-sm-12 col-xs-12" style="padding-left: 0px;padding-right: 0px;">
<nav class="navbar navbar-light bg-light justify-content-center" style="padding-left: 15px !important;padding-right: 15px !important;padding: 15px;">
<form>
  <div class="custom-control custom-radio custom-control-inline">
    <input type="radio" class="custom-control-input" id="customRadio" name="example" value="customEx" checked>
    <label class="custom-control-label" for="customRadio">AMC Transactions</label>
  </div>
  <div class="custom-control custom-radio custom-control-inline">
    <input type="radio" class="custom-control-input" id="customRadio2" name="example" value="customEx">
    <label class="custom-control-label" for="customRadio2">Job Card Payments</label>
  </div> 
</form>
</nav>
</div>

  <div id="AmcHistory" class="col-md-12 col-lg-12 col-xl-12 col-sm-12 col-xs-12 amcTableListOuter">
  <div class="col-md-2 offset-2" style="margin-top: -7px;position: absolute;z-index: 900;">
<div class="form-group">
  <select id="dropdown1" class="form-control">
 <option value="">AMC Status</option>
  <option value="Active">Active</option>
  <option value="Inactive">Inactive</option>
  <option value="Terminated">Terminated</option>
  <option value="Blocked">Blocked</option>
</select>
</div>
</div>
    <table id="example" class="table table-responsive w-100 d-block d-md-table"  cellspacing="0" width="100%" style="border-left: 1px solid rgb(222, 226, 230); border-right: 1px solid rgb(222, 226, 230);">
      <thead>
        <tr>
          <th id="status">Chassis Number</th>
		  <th>AMC Type</th>
          <th>Invoice Number</th>
          <th>Contract Number</th>
          <th>Contract KMS</th>
          <th>Start Date</th>
          <th>End Date</th>
          <th>Status</th>
          <th>Downlod</th>
          
        </tr>
		
      </thead>
      <tbody>
	  <tr> 
            <td>MAT612274EKBo47565</td>  
            <td>Platinum plus AMC</td>  
            <td>#100223331</td>  
            <td>#MAT612274EKBo47565</td>  
            <td>100,000</td>  
            <td>10-11-2016</td>  
            <td>10-11-2018</td>  
            <td>Active</td>  
            <td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td>  
       </tr>  
	   
	   <tr> 
            <td>MAT612274EKBo47564</td>  
            <td>Gold AMC</td>  
            <td>#100223332</td>  
            <td>#MAT612274EKBo47565</td>  
			<td>100,000</td>  
            <td>10-11-2016</td>  
            <td>10-11-2018</td>  
			 <td>Active</td> 
			<td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td> 
       </tr>    
	   <tr> 
            <td>MAT612274EKB123456</td>  
            <td>Free AMC</td>  
            <td>#100223333</td>  
            <td>#MAT612274EKBo47565</td>  
			<td>100,000</td>  
            <td>10-11-2016</td>  
            <td>10-11-2018</td>  
			 <td>Active</td>  
			<td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td> 
       </tr>
	   <tr> 
            <td>MAT611274EKB123456</td>  
            <td>Platinum plus AMC</td>  
            <td>#100223444</td>  
            <td>#MAT63456774EKBo47565</td>
<td>100,000</td>  			
            <td>10-11-2016</td>  
            <td>10-11-2019</td>  
			 <td>Terminated</td> 
			<td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td> 
       </tr> 
 <tr> 
            <td>MAT611234EKB123456</td>  
            <td>Platinum plus AMC</td>  
            <td>#1002234565</td>  
            <td>#MAT634566784EKBo47565</td> 
<td>100,000</td>  			
            <td>10-11-2016</td>  
            <td>10-11-2019</td> 
			<td>Terminated</td> 
<td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td> 			
       </tr> 
	   <tr> 
            <td>MAT63334EKB123456</td>  
            <td>silver AMC</td>  
            <td>#1002234566</td>  
            <td>#MAT3336784EKBo47565</td>  
			<td>100,000</td>  
            <td>10-11-2016</td>  
            <td>10-11-2019</td> 
<td>Blocked</td> 			
			<td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td> 
       </tr>
	   <tr> 
            <td>MAT68884EKB123456</td>  
            <td>Platinum plus AMC</td>  
            <td>#1002234567</td>  
            <td>#MAT8886784EKBo47565</td>  
			<td>100,000</td>  
            <td>10-11-2016</td>  
            <td>10-11-2019</td>  
			<td>Blocked</td> 
			<td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td> 
       </tr> 
	   <tr> 
            <td>MAT68884EKB123456</td>  
            <td>Gold AMC</td>  
            <td>#1002234568</td>  
            <td>#MAT8886784EKBo47565</td>  
			<td>100,000</td>  
            <td>10-11-2016</td>  
            <td>10-11-2019</td>  
			<td>Active</td> 
			<td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td> 
       </tr> 
	   <tr> 
            <td>MAT688564EKB123456</td>  
            <td>Free AMC</td>  
            <td>#1002234569</td>  
            <td>#MAT88566784EKBo47565</td>  
			<td>100,000</td>  
            <td>10-11-2016</td>  
            <td>10-11-2019</td>
			<td>Inactive</td> 
<td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td> 			
       </tr> 
	   <tr> 
            <td>MAT681114EKB123456</td>  
            <td>Silver AMC</td>  
            <td>#1002234561</td>  
            <td>#MAT88561114EKBo47565</td>  
			<td>100,000</td>  
            <td>10-11-2016</td>  
            <td>10-11-2019</td> 
			<td>Inactive</td> 
<td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td> 			
       </tr> 
	   <tr> 
            <td>MAT681114EKB123456</td>  
            <td>Silver AMC</td>  
            <td>#1002234562</td>  
            <td>#MAT88561114EKBo47565</td>  
			<td>100,000</td>  
            <td>10-11-2016</td>  
            <td>10-11-2019</td>  
			<td>Active</td> 
			<td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td> 
       </tr> 
	   <tr> 
            <td>MAT681114EKB123456</td>  
            <td>Gold AMC</td>  
            <td>#1002234564</td>  
            <td>#MAT88561114EKBo47565</td> 
<td>100,000</td>  			
            <td>10-11-2016</td>  
            <td>10-11-2019</td>  
			<td>Inactive</td> 
			<td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td> 
       </tr>  	   
			<script>
 $('.openPopup').click(function(){
   var vehicleid = $(this).attr("data-id");
   // AJAX request
   $.ajax({
    url: '<?php echo base_url();?>index.php/allmodelspop/vehicledetailspopup',
    type: 'post',
    data: {vehicleid: vehicleid},
    success: function(response){ 
      // Add response in Modal body
      $('.modal-body').html(response);

      // Display Modal
      $('#myModal').modal('show'); 
    }
  });
 });
 

</script>
			
         
    </tbody>
    </table>
	
	</div>
	
	
	 <div id="jcpHistory" class="col-md-12 col-lg-12 col-xl-12 col-sm-12 col-xs-12 amcTableListOuter" style="display:none;">
	
	
	    <table id="examplePayment" class="table table-responsive-sm  table-responsive-md  table-responsive-lg table-responsive-xl w-100"  cellspacing="0" width="100%" style="border-left: 1px solid rgb(222, 226, 230);border-right: 1px solid rgb(222, 226, 230);">
      <thead>
          <tr>
          <th>Select</th>
          <th>Type</th>
          <th>Invoice No.</th>
          <th>Invoice Date</th>
          <th>Status</th>
          <th>Invoice Amount</th>
          <th>Settled Amount</th>
          <th>Invoice Balanced Amt</th>
		  <th>Dealer</th>
		  <th>SR No</th>
		  <th>Job Card Number</th>
		  <th>Pay</th>
        </tr>
      </thead>
      <tbody>
	  <tr> 
        
  <td>		 
<div class="radio">
 <label><input  type="radio" class="openDetailPage" name="optradio"></label>
</div>
</td>
<td>Gold AMC </td>
          <td>SR-ShreeS/SE</td>
          <td>01/21/2018</td>
          <td>New</td>
          <td>564.345</td>
          <td>655</td>
          <td>0</td>
		  <td>289609</td>
		  <td>SR-ShreeS/SE</td>
		  <td>JC-ShreeS/SE</td>
		  <!--<td><a class="btn btn-primary" href="<?php echo base_url();?>index.php/orderconfirmation" >Make Payment</a></td>-->
		   <td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td>  

            </tr>
<tr> 
  <td>		 
<div class="radio">
 <label><input  type="radio" class="openDetailPage" name="optradio"></label>
</div>
</td>
<td>Silver AMC </td>
          <td>SR-Dem0/SE</td>
          <td>01/21/2018</td>
          <td>New</td>
          <td>804.345</td>
          <td>655</td>
          <td>0</td>
		  <td>289609</td>
		  <td>SR-ShreeS/SE</td>
		  <td>JC-ShreeS/SE</td>
		   <td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td>  

            </tr>   
			
<tr> 
  <td>		 
<div class="radio">
 <label><input  type="radio" class="openDetailPage" name="optradio"></label>
</div>
</td>
<td>P2P AMC </td>
<td>SR-Dem0/SE</td>
<td>01/21/2018</td>
<td>New</td>
<td>804.345</td>
<td>655</td>
<td>0</td>
<td>289609</td>
<td>SR-ShreeS/SE</td>
<td>JC-ShreeS/SE</td>
 <td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td>  
</tr>  
			
<tr> 
  <td>		 
<div class="radio">
 <label><input  type="radio" class="openDetailPage" name="optradio"></label>
</div>
</td>
<td>Protect plus AMC </td>
<td>SR-Dem0/SE</td>
<td>01/21/2018</td>
<td>New</td>
<td>804.345</td>
<td>655</td>
<td>0</td>
<td>289609</td>
<td>SR-ShreeS/SE</td>
<td>JC-ShreeS/SE</td>
 <td><a href="http://localhost/pdf.php?file=sample.pdf"><img width="25%" src="/img/download.svg"></a></td>  
</tr>  
			
        
    </tbody>
    </table>  
		</div>
	
	
	</div>
	<!-- Table and Side Bar Row End -->
	
	</div>
  </body>

</html>
