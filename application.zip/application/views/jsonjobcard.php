<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
<style type="text/css">
.card.person-card{
	margin-bottom:10px;
}
.card {
	border:0px !important;
}
label{margin-left: 20px;}
#datepicker{margin: 0 20px 20px 20px;}
#datepicker > span:hover{cursor: pointer;}

/* IMG displaying */

.card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 23px;
    padding-bottom: 0px;
}
.person-card .card-title{
    text-align: center;
}
.table-responsive {
    display: table;
}
.person-card .person-img {
    width: 6em;
    position: absolute;
    top: -3em;
    left: 50%;
    margin-left: -5em;
    border-radius: 100%;
    overflow: hidden;
    background-color: white;
}

.margin_bottom_30pxOffset{
	margin-bottom:30px;
}
.card-title{
	border-bottom: 2px solid #5ea4f3;
	padding-bottom:10px;
}
.shopping-cart.dark {
    background-color: #f6f6f6;
	padding:10px;
}
.datepicker{
	padding:0px;!important;
}

.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width:100%;
}
.icon {
    padding: 6px;
    background: dodgerblue;
    color: white;
    text-align: center;
    padding-top: 9px;
    height: 38px;
}
.input-field{
	border-radius:0px !important;
}
.form-control{
	border-radius:0px !important;
}
main.page {
	background: white;
    border: 0 none;
    border-radius: 0px;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    box-sizing: border-box;
    width: 100%;
    position: relative;
    margin-top: 20px;
    margin-bottom: 20px;
    margin-left: 0px;
}
</style>

    <link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/b-1.5.4/b-colvis-1.5.4/b-html5-1.5.4/r-2.2.2/sc-1.5.0/sl-1.2.6/datatables.min.css"/>
 
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/b-1.5.4/b-colvis-1.5.4/b-html5-1.5.4/r-2.2.2/sc-1.5.0/sl-1.2.6/datatables.min.js"></script>

<script type="text/javascript" language="javascript" >
$(document).ready(function() {
	
    $('#example').DataTable( {
        "ajax": {
            "url": "/ajaxcalls/jsondata.php",
            "dataSrc": "employees",
processing: true
        }
    } );
} );
		</script>
	 
	 </head>
<body>
<div class="container-fluid" >
<main class="page">
	 	<section class="shopping-cart dark">

    <!-- Sign up form -->
    <form id="enquiryForm" name="enquiryForm" method="POST" action="">
        <!-- Sign up card -->
        <div class="card person-card">
            <div class="card-body">
                <!-- Sex image -->
                <h5 id="who_message" class="d-flex justify-content-start">Job Card Payment</h5>
                <!-- First row (on medium screen) -->
                <div class="row">
				<div class="form-group col-md-2">
                        <input id="chassis_number" type="text" class="form-control" placeholder="Job Card Number">
                </div>
				
				<div class="form-group col-md-2">
					<input id="registration_number" type="text" class="form-control" placeholder="Registration Number">
				</div>
				<div class="form-group col-md-2">
					<input id="dealer_name" type="text" class="form-control" placeholder="Dealer Name">
				</div>
				
				
				
				<div class="form-group form-inline d-flex justify-content-between col-md-2">
			<div class="input-container col-md-12">
			<input class="input-field col-md-12 form-control datepicker" type="text" id="creation_date" name="creation_date"><i class="fa fa-calendar icon"></i>
			</div>
			</div>
			<div class="form-group form-inline d-flex justify-content-between col-md-2">
			<div class="input-container col-md-12">
			<input class="input-field col-md-12 form-control datepicker" type="text" id="closure_date" name="closure_date"><i class="fa fa-calendar icon"></i>
			</div>
			</div>
				<div class="form-group col-md-2 d-flex justify-content-center">
				 <button name="Go" class="btn btn-primary">Go</button>
				</div>
					
                </div>
            </div>
        </div>
          <div class="card person-card">
            <div class="card-body">
                <!-- Sex image -->
                <h5 id="who_message" class="d-flex justify-content-start">Job Card Payment</h5>
                <!-- First row (on medium screen) -->
                <div class="col-md-12 col-xl-12 col-lg-12 col-sm-12 ">
				  <table id="example" class="table table-responsive w-100 d-block d-md-table"  cellspacing="0" width="100%">
				
						<thead>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Extn.</th>
                <th>Start date</th>
                <th>Salary</th>
            </tr>
        </thead>
					
				  </table>
        </div>
        </div>
        </div>
		
        </form>
		</div>

</section>
</main>
</div>



</body>


  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
        $(document).on('focus', '.datepicker',function(){
            $(this).datepicker({
                todayHighlight:true,
                format:'yyyy-mm-dd',
                autoclose:true
            })
        });
    </script>
</body>
</html>
