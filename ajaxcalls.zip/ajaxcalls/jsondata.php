<?php
$stuff = array(
    'employees' => array(
        array('name' => 'John1', 'position' => 'Doe' , 'office' => 'Pune', 'ext' => '5407', 'startdate' => '2008-11-28', 'salary' => '10000'),
        array('name' => 'John2', 'position' => 'Doe' , 'office' => 'Pune', 'ext' => '5407', 'startdate' => '2008-11-28', 'salary' => '10000'),
        array('name' => 'John3', 'position' => 'Doe' , 'office' => 'Pune', 'ext' => '5407', 'startdate' => '2008-11-28', 'salary' => '10000'),
        array('name' => 'John4', 'position' => 'Doe' , 'office' => 'Pune', 'ext' => '5407', 'startdate' => '2008-11-28', 'salary' => '10000'),
        array('name' => 'John5', 'position' => 'Doe' , 'office' => 'Pune', 'ext' => '5407', 'startdate' => '2008-11-28', 'salary' => '10000'),
        array('name' => 'John6', 'position' => 'Doe' , 'office' => 'Pune', 'ext' => '5407', 'startdate' => '2008-11-28', 'salary' => '10000'),
        array('name' => 'John7', 'position' => 'Doe' , 'office' => 'Pune', 'ext' => '5407', 'startdate' => '2008-11-28', 'salary' => '10000'),
        array('name' => 'John8', 'position' => 'Doe' , 'office' => 'Pune', 'ext' => '5407', 'startdate' => '2008-11-28', 'salary' => '10000'),
        array('name' => 'John9', 'position' => 'Doe' , 'office' => 'Pune', 'ext' => '5407', 'startdate' => '2008-11-28', 'salary' => '10000'),
        array('name' => 'John10', 'position' => 'Doe' , 'office' => 'Pune', 'ext' => '5407', 'startdate' => '2008-11-28', 'salary' => '10000'),
        array('name' => 'John11', 'position' => 'Doe' , 'office' => 'Pune', 'ext' => '5407', 'startdate' => '2008-11-28', 'salary' => '10000'),
        array('name' => 'John12', 'position' => 'Doe' , 'office' => 'Pune', 'ext' => '5407', 'startdate' => '2008-11-28', 'salary' => '10000'),
        array('name' => 'John13', 'position' => 'Doe' , 'office' => 'Pune', 'ext' => '5407', 'startdate' => '2008-11-28', 'salary' => '10000'),
        array('name' => 'John1', 'position' => 'Doe' , 'office' => 'Pune', 'ext' => '5407', 'startdate' => '2008-11-28', 'salary' => '10000'),
       
    )
);
 $myJSON = json_encode($stuff);

echo $myJSON;
?>